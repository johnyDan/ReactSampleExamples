import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSetRecoilState } from 'recoil';
import {
  Box,
  Typography,
  IconButton,
  List,
  ListItem,
  Divider,
  useTheme,
  Grid,
  Dialog,
  DialogContent,
} from '@mui/material';
import { getAllSwitches, getSwitchDetails, performSwitchAction } from '../../services/methods/switch';
import { hasExistingSwitchesState, switchCreationState } from '../../state/atoms';
import CustomButton from '@/validations/material/customButton';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import { getActionItems, SwitchItem } from './utils/switchDashboardUtils';
import SwitchActionDialog from './utils/switchActionDialog';
import ArrowCircleRightOutlinedIcon from '@mui/icons-material/ArrowCircleRightOutlined';
import AssignmentTurnedInOutlinedIcon from '@mui/icons-material/AssignmentTurnedInOutlined';
import PdfViewerDialog from '@/components/common/pdfViewer';

const SwitchDashboard: React.FC = () => {
  const [switches, setSwitches] = useState<SwitchItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogAction, setDialogAction] = useState<'delete' | 'submit' | 'complete' | null>(null);
  const [selectedSwitch, setSelectedSwitch] = useState<SwitchItem | null>(null);
  const navigate = useNavigate();
  const theme = useTheme();
  const setSwitchCreation = useSetRecoilState(switchCreationState);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();
  const setHasExistingSwitches = useSetRecoilState(hasExistingSwitchesState);

  const [openPdfDialog, setOpenPdfDialog] = useState(false);
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);

  const getSplitTypeDisplay = (splitType: string, splitAmount: string) => {
    const BoldAmount = () => (
      <Box component="span" fontWeight="bold">
        {splitAmount}
      </Box>
    );

    switch (splitType?.toLowerCase()) {
      case 'currency':
        return (
          <>
            $<BoldAmount /> of each check
          </>
        );
      case 'percentage':
        return (
          <>
            <BoldAmount />% of each check
          </>
        );
      case 'remainder':
        return 'Remainder of each check';
      default:
        return <BoldAmount />;
    }
  };

  const getAccountLabel = (accountIndex: string, switchData: any) => {
    const account = switchData.ux.accounts.choices.find(
      (choice: any) => choice.index.toString() === accountIndex.toString()
    );
    return account ? account.label : 'Unknown Account';
  };

  useEffect(() => {
    fetchSwitches();
  }, []);

  const fetchSwitches = async () => {
    try {
      showLoadingSpinner('Fetching existing direct deposits');
      const response = await getAllSwitches({ context: 'testing' });
      const switchItems = response.data.items;
      setHasExistingSwitches(switchItems.length > 0);

      if (switchItems.length === 0) {
        hideLoadingSpinner(true);
        navigate('/company-search');
        return;
      }

      // Fetch details for each switch
      const switchDetailsPromises = switchItems.map(async (switchItem: SwitchItem) => {
        const switchIndex = switchItem.index;
        try {
          const switchDetailsResponse = await getSwitchDetails(switchIndex, {
            context: 'testing',
            contentType: 'application/json',
          });
          // The detailed switch data is assumed to be in switchDetailsResponse.data.item
          return switchDetailsResponse.data.item;
        } catch (err) {
          console.error(`Failed to fetch details for switch index ${switchIndex}`, err);
          return null; // or you can decide to handle this differently
        }
      });

      // Wait for all promises to resolve
      const detailedSwitches = await Promise.all(switchDetailsPromises);

      // Filter out any null responses due to errors
      const validSwitches = detailedSwitches.filter((switchItem) => switchItem !== null);

      hideLoadingSpinner();
      setSwitches(validSwitches as SwitchItem[]);
      setLoading(false);
    } catch (err) {
      hideLoadingSpinner(true);
      setError('Failed to fetch switches. Please try again.');
      setLoading(false);
    }
  };

  const handleEdit = (switchIndex: number) => {
    setSwitchCreation((prev) => ({ ...prev, isEditing: true, switchId: switchIndex }));
    navigate('/switch-management/create');
  };

  const handleDelete = (switchItem: SwitchItem) => {
    setSelectedSwitch(switchItem);
    setDialogAction('delete');
    setOpenDialog(true);
  };

  const handleSubmit = (switchItem: SwitchItem) => {
    setSelectedSwitch(switchItem);
    setDialogAction('submit');
    setOpenDialog(true);
  };

  const handleComplete = (switchItem: SwitchItem) => {
    setSelectedSwitch(switchItem);
    setDialogAction('complete');
    setOpenDialog(true);
  };

  const handleConfirmAction = async () => {
    if (!selectedSwitch) return;

    try {
      if (dialogAction === 'delete') {
        showLoadingSpinner('Deleting selected switch');
        await performSwitchAction(
          selectedSwitch.index,
          { index: selectedSwitch.index, action: 'Cancel' },
          { context: 'testing' }
        );
        await performSwitchAction(
          selectedSwitch.index,
          { index: selectedSwitch.index, action: 'HTTP-DELETE' },
          { context: 'testing' }
        );
        hideLoadingSpinner();
      } else if (dialogAction === 'submit') {
        showLoadingSpinner('Submitting selected switch');
        await performSwitchAction(
          selectedSwitch.index,
          { index: selectedSwitch.index, action: 'Submit' },
          { context: 'testing' }
        );
        hideLoadingSpinner();
      } else if (dialogAction === 'complete') {
        showLoadingSpinner('Completing selected switch');
        await performSwitchAction(
          selectedSwitch.index,
          { index: selectedSwitch.index, action: 'Complete' },
          { context: 'testing' }
        );
        hideLoadingSpinner();
      }
      fetchSwitches();
      setOpenDialog(false);
    } catch (err) {
      hideLoadingSpinner(true);
      setError(`Failed to ${dialogAction} switch. Please try again.`);
    }
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedSwitch(null);
    setDialogAction(null);
  };

  const handlePdfView = async (switchIndex: number) => {
    try {
      const arrayBufferData = await getSwitchDetails(switchIndex, {
        context: 'testing',
        contentType: 'application/pdf',
      });
      const blob = new Blob([arrayBufferData], { type: 'application/pdf' });
      setPdfBlob(blob);
      setOpenPdfDialog(true);
    } catch (error) {
      console.error('Error fetching PDF:', error);
    }
  };

  if (loading) return <Typography></Typography>;
  if (error) return <Typography color="error">{error}</Typography>;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', boxSizing: 'border-box' }}>
      <Grid container spacing={4} sx={{ flexGrow: 1, p: { xs: 2, sm: 4 }, justifyContent: 'center' }}>
        {switches && switches.length > 0 && (
          <Grid item xs={12} md={6} sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <Box sx={{ p: 1, gap: 2, display: 'flex', flexDirection: 'column' }}>
              <Typography variant="h2">Your direct deposits</Typography>
              <Typography variant="body2" gutterBottom>
                The following direct deposits were completed in the past 2 weeks or are currently in progress.
              </Typography>
              <Typography variant="body2" gutterBottom>
                To see direct deposits configured before that time, login to your employer's payroll system.
              </Typography>
            </Box>
            <List
              sx={{
                height: '50vh',
                overflowY: 'auto',
                '&::-webkit-scrollbar': {
                  width: '8px',
                },
                '&::-webkit-scrollbar-track': {
                  background: theme.palette.grey[300],
                  borderRadius: '4px',
                },
                '&::-webkit-scrollbar-thumb': {
                  backgroundColor: theme.palette.primary.main,
                  borderRadius: '4px',
                  border: '2px solid transparent',
                  backgroundClip: 'padding-box',
                  transition: 'background-color 0.3s ease',
                },
                '&::-webkit-scrollbar-thumb:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },

                scrollbarWidth: 'thin',
                scrollBehavior: 'smooth',
                scrollbarColor: `${theme.palette.primary.main} ${theme.palette.grey[300]}`,
              }}>
              {switches.map((switchItem: SwitchItem, index) => (
                <React.Fragment key={index}>
                  <Divider sx={{ ml: 2, mr: 2 }} />
                  <ListItem
                    key={index}
                    sx={{
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      padding: 2,
                    }}>
                    <Grid container display="flex" justifyContent="space-between" width="100%" mb={1}>
                      <Grid item xs={8}>
                        <Typography variant="body2" component="h2" fontWeight={'bold'} color="primary">
                          {switchItem.name ? switchItem.name : 'Manual Entry'}
                        </Typography>
                      </Grid>

                      <Grid item xs={4} display="flex" justifyContent="flex-end" alignItems="flex-start">
                        {(() => {
                          const actionItems = getActionItems(switchItem);

                          return (
                            <>
                              {actionItems.edit && (
                                <IconButton size="small" onClick={() => handleEdit(switchItem.index)}>
                                  <EditOutlinedIcon />
                                </IconButton>
                              )}
                              {actionItems.view && (
                                <IconButton size="small" onClick={() => handlePdfView(switchItem.index)}>
                                  <VisibilityOutlinedIcon />
                                </IconButton>
                              )}
                              {actionItems.delete && (
                                <IconButton size="small" onClick={() => handleDelete(switchItem)}>
                                  <DeleteOutlineOutlinedIcon />
                                </IconButton>
                              )}
                              {actionItems.submit && (
                                <IconButton size="small" onClick={() => handleSubmit(switchItem)}>
                                  <ArrowCircleRightOutlinedIcon />
                                </IconButton>
                              )}
                              {actionItems.complete && (
                                <IconButton size="small" onClick={() => handleComplete(switchItem)}>
                                  <AssignmentTurnedInOutlinedIcon />
                                </IconButton>
                              )}
                            </>
                          );
                        })()}
                      </Grid>
                    </Grid>

                    {switchItem.values &&
                      switchItem.values.accounts &&
                      switchItem.values.accounts.length > 0 &&
                      switchItem.values.accounts.map((account: any, index: number) => (
                        <Box key={index + 'test'} mb={2}>
                          <Typography variant="body2" gutterBottom>
                            {getSplitTypeDisplay(account.fields?.splitType, account.fields?.splitAmount)}
                          </Typography>
                          <Typography variant="body2" gutterBottom>
                            Deposited into: {getAccountLabel(account.index, switchItem)}
                          </Typography>
                        </Box>
                      ))}

                    <Typography variant="body2" fontWeight={'bold'} color="primary">
                      Status
                    </Typography>
                    <Typography variant="body2">{switchItem.state.status}</Typography>
                  </ListItem>
                  {index == switches.length - 1 && <Divider sx={{ ml: 2, mr: 2 }} />}
                </React.Fragment>
              ))}
            </List>
            <Box p={2}>
              <CustomButton variant="primary" onClick={() => navigate('/company-search')}>
                Add another direct deposit
              </CustomButton>
            </Box>

            <SwitchActionDialog
              open={openDialog}
              dialogAction={dialogAction}
              onClose={handleCloseDialog}
              onConfirm={handleConfirmAction}
            />
            <PdfViewerDialog
              open={openPdfDialog}
              onClose={() => {
                setOpenPdfDialog(false);
                setPdfBlob(null);
              }}
              pdfBlob={pdfBlob}
            />
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

export default SwitchDashboard;
