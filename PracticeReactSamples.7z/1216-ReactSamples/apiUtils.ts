import api from './api';

export const apiRequest = async <T>(
  method: 'get' | 'post' | 'put' | 'delete',
  url: string,
  data?: T | null,
  params?: Record<string, any>,
  options?: {
    headers?: Record<string, string>;
    responseType?: 'arraybuffer' | 'json' | 'blob' | 'text';
  }
): Promise<any> => {
  try {
    const config: any = {
      headers: options?.headers || {},
      responseType: options?.responseType || 'json',
    };

    if (method === 'get' || method === 'delete') {
      config.params = params;
      config.data = data;
    } else {
      //Todo: check this,for POST/PUT, data usually goes as the second argument
      // after the URL in the axios call.
    }

    const response = await api[method](url, method === 'get' || method === 'delete' ? config : data, config);
    return response.data;
  } catch (error) {
    console.error(`API ${method.toUpperCase()} request failed:`, error);
    throw error;
  }
};
