import React, { useState } from 'react';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { switchCreationState, currentStepState, selectedCompanyState } from '../../state/atoms';
import { useNavigate } from 'react-router-dom';
import { Box, Grid, Typography } from '@mui/material';
import { getSwitchDetails, performSwitchAction, updateSwitch } from '../../services/methods/switch';
import SwitchDetailsDisplay from './components/switchDetailsDisplay';
import NavigationButtons from '@/components/layout/navigationButtons';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';
import PdfViewerDialog from '@/components/common/pdfViewer';

const VerifySwitch: React.FC = () => {
  const [switchCreation, setSwitchCreation] = useRecoilState(switchCreationState);
  const setCurrentStep = useSetRecoilState(currentStepState);
  const setSelectedCompany = useSetRecoilState(selectedCompanyState);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();
  const [openPdfDialog, setOpenPdfDialog] = useState(false);
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);

  const navigate = useNavigate();

  const handleBack = () => {
    setCurrentStep(2);
    navigate('/switch-management/create');
  };

  const handleSubmit = async () => {
    if (switchCreation.switchData) {
      try {
        showLoadingSpinner('Updating Switch');
        const updateResponse = await updateSwitch(switchCreation.switchData.index, switchCreation.switchData, {
          context: 'testing',
        });
        hideLoadingSpinner();

        setSwitchCreation((prev) => ({
          ...prev,
          switchData: updateResponse.data.item,
          switchKind: updateResponse.data.item.state.actions.indexOf('Print') > -1 ? 'PRINT_ONLY' : 'SUBMITTABLE',
        }));

        if (switchCreation.switchKind === 'SUBMITTABLE') {
          showLoadingSpinner('Submitting Switch');
          await performSwitchAction(
            switchCreation.switchData.index,
            { index: switchCreation.switchData.index, action: 'Submit' },
            { context: 'testing' },
            switchCreation.switchData
          );
          hideLoadingSpinner();
          navigate('/switch-management/confirm');
        } else if (switchCreation.switchKind === 'PRINT_ONLY') {
          showLoadingSpinner('Submitting Switch');
          await performSwitchAction(
            switchCreation.switchData.index,
            { index: switchCreation.switchData.index, action: 'Print' },
            { context: 'testing' },
            switchCreation.switchData
          );

          const arrayBufferData = await getSwitchDetails(switchCreation.switchData.index, {
            context: 'testing',
            contentType: 'application/pdf',
          });
          const blob = new Blob([arrayBufferData], { type: 'application/pdf' });
          setPdfBlob(blob);
          setOpenPdfDialog(true);
          hideLoadingSpinner(true);
        }
      } catch (error) {
        hideLoadingSpinner(true);
        console.error('Error submitting switch:', error);
      }
    }
  };

  const onPdfDialogClose = () => {
    setOpenPdfDialog(false);
    navigate('/switch-management/confirm');
  };

  const handleEditAccounts = () => {
    setCurrentStep(1);
    navigate('/switch-management/create');
  };

  const handleEditAdditionalDetails = () => {
    setCurrentStep(2);
    navigate('/switch-management/create');
  };

  const handleSaveAndContinueLater = async () => {
    if (switchCreation.switchData) {
      try {
        showLoadingSpinner('Updating Switch');
        await updateSwitch(switchCreation.switchData.index, switchCreation.switchData, {
          context: 'testing',
        });
        hideLoadingSpinner();
        setSwitchCreation({
          switchId: null,
          switchData: null,
          step: 'create',
          isEditing: false,
          workflowEmbedUrl: null,
          error: null,
          switchKind: null,
        });
        setSelectedCompany({
          name: '',
          address: '',
          targetId: null,
          locationId: null,
          manualSetup: false,
        });

        setCurrentStep(1);

        navigate('/');
      } catch (error) {
        hideLoadingSpinner(true);
        console.error('Error saving switch:', error);
      }
    }
  };

  if (!switchCreation.switchData) {
    return <div>Loading...</div>;
  }

  const pageText = {
    pageInfo: {
      title: 'Please verify your direct deposit information below',
      description:
        switchCreation.switchKind == 'PRINT_ONLY'
          ? 'To proceed select print, and take this form to your Humans Resources or Payroll office.'
          : 'To proceed, select submit; to make changes, select back or any of edit options provided below.',
    },
    stepInfo: {
      title: 'Setup your direct deposit',
      description: switchCreation.switchKind == 'PRINT_ONLY' ? 'Verify & Print' : 'Verify & Submit',
      instruction:
        switchCreation.switchKind == 'PRINT_ONLY'
          ? 'Verify your details and print your switch request.'
          : 'Verify your details and submit your switch request.',
      step: 'Step 3 of 3',
    },
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
      <Grid container spacing={4} sx={{ p: { xs: 2, sm: 4 }, justifyContent: 'space-between' }}>
        <Grid item xs={12} md={5} sx={{ display: 'flex', gap: 2, flexDirection: 'column' }}>
          <Typography variant="h2">{pageText.stepInfo.title}</Typography>
          <Typography variant="h2">{pageText.stepInfo.description}</Typography>
          <Typography variant="body2">{pageText.stepInfo.instruction}</Typography>
          <Typography variant="body2">{pageText.stepInfo.step}</Typography>
        </Grid>
        <Grid item xs={12} md={6} sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <SwitchDetailsDisplay
            pageTextInfo={pageText.pageInfo}
            switchData={switchCreation.switchData}
            isConfirmation={switchCreation.step === 'confirm'}
            onEditAccounts={handleEditAccounts}
            onEditAdditionalDetails={handleEditAdditionalDetails}
          />
        </Grid>
        <PdfViewerDialog
          open={openPdfDialog}
          onClose={() => {
            setOpenPdfDialog(false);
            setPdfBlob(null);
            onPdfDialogClose();
          }}
          pdfBlob={pdfBlob}
        />
      </Grid>

      <NavigationButtons
        items={[
          {
            type: 'button',
            label: 'Back',
            onClick: handleBack,
            variant: 'secondary',
            index: 1,
            mobileIndex: 2,
            buttonPosition: 'left',
          },
          {
            type: 'link',
            label: 'Save & Continue Later',
            onClick: handleSaveAndContinueLater,
            index: 2,
            mobileIndex: 3,
            buttonPosition: 'right',
          },
          {
            type: 'button',
            label: switchCreation.switchKind === 'SUBMITTABLE' ? 'Submit' : 'Print',
            onClick: handleSubmit,
            variant: 'primary',
            index: 3,
            mobileIndex: 1,
            buttonPosition: 'right',
          },
        ]}
      />
    </Box>
  );
};

export default VerifySwitch;
