import React, { useState, useMemo, useCallback } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, IconButton, Typography } from '@mui/material';
import { Document, Page, pdfjs } from 'react-pdf';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DownloadIcon from '@mui/icons-material/Download';
import CustomButton from '@/validations/material/customButton';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import 'react-pdf/dist/esm/Page/TextLayer.css';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

interface PdfViewerDialogProps {
  open: boolean;
  onClose: () => void;
  pdfBlob: Blob | null;
}

const PdfViewerDialog: React.FC<PdfViewerDialogProps> = ({ open, onClose, pdfBlob }) => {
  const [numPages, setNumPages] = useState(0);
  const fileProp = useMemo(() => {
    return pdfBlob || null;
  }, [pdfBlob]);

  const onDocumentLoadSuccess = (pdf: any) => {
    setNumPages(pdf.numPages);
  };

  const handleDownload = useCallback(() => {
    if (!pdfBlob) return;
    const blobUrl = URL.createObjectURL(pdfBlob);

    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = 'document.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(blobUrl);
  }, [pdfBlob]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center' }}>
        <IconButton onClick={onClose} sx={{ mr: 1 }}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          PDF Viewer
        </Typography>

        <IconButton onClick={handleDownload} disabled={!pdfBlob}>
          <DownloadIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers style={{ minHeight: 600 }}>
        {fileProp ? (
          <Document
            file={fileProp}
            onLoadSuccess={onDocumentLoadSuccess}
            loading={<div>Loading PDF...</div>}
            error={<div>Failed to load PDF</div>}>
            {Array.from({ length: numPages }, (_, i) => (
              <Page key={`page_${i}`} pageNumber={i + 1} width={800} />
            ))}
          </Document>
        ) : (
          <div>No PDF data</div>
        )}
      </DialogContent>
      <DialogActions>
        <CustomButton variant="secondary" onClick={onClose}>
          Close
        </CustomButton>
      </DialogActions>
    </Dialog>
  );
};

export default PdfViewerDialog;
