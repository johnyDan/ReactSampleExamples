import { apiRequest } from '../apiUtils';
import { API_ENDPOINTS } from '../apiEndpoints';
import { ApiResponse, CustomerKey } from '../apiTypes';
import { createSwitchMock } from './mock-data/createSwitchMock';
import { getSwitchMock } from './mock-data/getSwitchMock';
import { getAllSwitchesMock } from './mock-data/getAllSwitchesMock';
import { apiContext } from '../apiContext';

interface Switch {
  index: number;
  type: string;
  targetId: string;
  accountholderIndex: number;
  values: {
    accounts: Array<{ index: number }>;
    fields: Record<string, string>;
  };
  metadata?: Record<string, string>;
}

interface SwitchAction {
  index: number;
  action: string;
}

interface CreateSwitchParams {
  type: string;
  accountholderIndex: string;
  targetId: number;
  locationId?: any;
}

export const getCustomerSwitches = (customerKey: CustomerKey, context?: String): Promise<ApiResponse<Switch[]>> =>
  apiRequest('get', `${API_ENDPOINTS.CUSTOMER.BASE}/${customerKey}${API_ENDPOINTS.SWITCH.BASE}`, null, context);

export const createSwitch = (params: CreateSwitchParams, switchData?: Omit<Switch, 'index'>): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    let id = params.targetId ? params.targetId : params.locationId;

    let createSwitchData = createSwitchMock[id ? id : 'manual'];
    let reponseData = createSwitchData ? createSwitchData : createSwitchMock[0];

    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(reponseData);
        // resolve({
        //   data: {
        //     item: {
        //       index: 161,
        //       type: "Deposit",
        //       targetId: 4788,
        //       name: "San Antonio Independent School District (SAISD)",
        //       accountHolderIndex: 0,
        //       values: {
        //         accounts: [],
        //         fields: {
        //           Custom_EmployeeID: null,
        //           Custom_SocialSecurityNumber: null,
        //           Custom_SchoolName: null,
        //           Custom_LOC: null,
        //           Custom_IsMonthly: "False",
        //           Custom_IsBiWeekly: "False",
        //         },
        //       },
        //       ux: {
        //         accounts: {
        //           limit: 1,
        //           maxChecking: 1,
        //           maxSavings: 1,
        //           choices: [
        //             {
        //               index: 0,
        //               label: "Free Checking *7890",
        //             },
        //           ],
        //           fields: [],
        //         },
        //         fields: [
        //           {
        //             key: "Custom_EmployeeID",
        //             label: "Employee ID #",
        //             type: "textbox",
        //             required: false,
        //           },
        //           {
        //             key: "Custom_SocialSecurityNumber",
        //             label: "OR Social Security Number",
        //             type: "textbox",
        //             required: false,
        //           },
        //           {
        //             key: "Custom_SchoolName",
        //             label: "School Name",
        //             type: "textbox",
        //             required: true,
        //           },
        //           {
        //             key: "Custom_LOC",
        //             label: "LOC #",
        //             type: "textbox",
        //             required: true,
        //           },
        //           {
        //             key: "Custom_IsMonthly",
        //             label: "Payroll Type is Monthly?",
        //             type: "checkbox",
        //             required: false,
        //           },
        //           {
        //             key: "Custom_IsBiWeekly",
        //             label: "Or Payroll Type is Bi-Weekly?",
        //             type: "checkbox",
        //             required: false,
        //           },
        //         ],
        //       },
        //       state: {
        //         status: "Incomplete",
        //         actions: ["HTTP-PUT", "Cancel"],
        //         validation: {
        //           accounts: [],
        //           fields: {
        //             Custom_SchoolName: "This field is required",
        //             Custom_LOC: "This field is required",
        //           },
        //           overall: ["At least one account must be selected"],
        //         },
        //       },
        //       metadata: {},
        //     },
        //     kind: "switch",
        //     lang: "en-US",
        //   },
        //   apiVersion: "3.0.0",
        //   context: "testing",
        //   id: "0d73839b208d4dff80200612c97b48e3",
        // });
      }, 1000);
    });
  } else {
    return apiRequest<CreateSwitchParams>(
      'post',
      `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${API_ENDPOINTS.SWITCH.BASE}?context=testing`,
      params,
      switchData ? { switchData } : undefined
    );
  }
};

export const getSwitch = (switchIndex: number, params: any): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    let getSwitchData = getSwitchMock[switchIndex];
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(getSwitchData);
      }, 1000);
    });
  } else {
    return apiRequest(
      'get',
      `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${API_ENDPOINTS.SWITCH.BASE}/${switchIndex}`,
      null,
      params
    );
  }
};

export const updateSwitch = (switchIndex: number, switchData: any, params: any): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          data: {
            item: switchData,
            kind: 'switch',
            lang: 'en-US',
          },
          apiVersion: '3.0.0',
          context: 'testing',
          id: 'afc494297fb14ba29471951d6ab01a0a',
        });
      }, 1000);
    });
  } else {
    return apiRequest(
      'put',
      `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${
        API_ENDPOINTS.SWITCH.BASE
      }/${switchIndex}?context=testing`,
      switchData,
      params
    );
  }
};

export const deleteSwitch = (switchIndex: number): Promise<void> =>
  apiRequest(
    'delete',
    `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${
      API_ENDPOINTS.SWITCH.BASE
    }/${switchIndex}?context=testing`
  );

export const performSwitchAction = (
  switchIndex: number,
  actionData: SwitchAction,
  params: any,
  switchData?: any
): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          data: {
            item: switchData,
            kind: 'switch',
            lang: 'en-US',
          },
          apiVersion: '3.0.0',
          context: 'testing',
          id: 'afc494297fb14ba29471951d6ab01a0a',
        });
      }, 1000);
    });
  } else {
    return apiRequest(
      'post',
      `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${API_ENDPOINTS.SWITCH.BASE}/${switchIndex}${
        API_ENDPOINTS.SWITCH.ACTION
      }`,
      actionData,
      params
    );
  }
};

export const getAllSwitches = async (options: { context: string }) => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(getAllSwitchesMock);
      }, 1000);
    });
  } else {
    return apiRequest(
      'get',
      `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${API_ENDPOINTS.SWITCH.BASE}`,
      null,
      options
    );
  }
};

export const getSwitchDetails = (
  switchIndex: number,
  options: {
    context: string;
    contentType: 'application/json' | 'application/pdf';
  }
): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    let getSwitchData = getSwitchMock[switchIndex];
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(getSwitchData);
      }, 1000);
    });
  } else {
    return apiRequest(
      'get',
      `${API_ENDPOINTS.CUSTOMER.BASE}/${apiContext.getCustomerKey()}${API_ENDPOINTS.SWITCH.BASE}/${switchIndex}`,
      null,
      { context: options.context },
      {
        headers: { 'Content-Type': options.contentType },
        responseType: options.contentType === 'application/pdf' ? 'arraybuffer' : 'json',
      }
    );
  }
};
