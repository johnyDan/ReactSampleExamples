export class ApiContext {
  private static instance: ApiContext;
  private customerKey: string = '';

  private constructor() {}

  static getInstance(): ApiContext {
    if (!ApiContext.instance) {
      ApiContext.instance = new ApiContext();
    }
    return ApiContext.instance;
  }

  setCustomerKey(key: string) {
    this.customerKey = key;
  }

  getCustomerKey(): string {
    return this.customerKey;
  }
}

export const apiContext = ApiContext.getInstance();
