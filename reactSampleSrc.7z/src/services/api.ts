import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

// Base URL for the ClickSwitch API
// const BASE_URL = 'https://uat.api.clickswitch.com/v3/';
// const BASE_URL = "https://dynamic-pentagonal-apartment.glitch.me";
const BASE_URL = 'api';

// configuration object for axios
const config: AxiosRequestConfig = {
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'api-key':
      'AAeyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpbnN0aXR1dGlvbklkIjoyOTUzLCJjcmVhdGVEYXRlIjoiMjAyMy0wNS0xNlQxNDoxNjozMi44NDA5MzA0WiIsImVudmlyb25tZW50IjoiVXNVYXQiLCJ2ZXJzaW9uIjoiMS4wLjAiLCJhcHBNb2RlIjoxLCJyb2xlcyI6WyJFbmRVc2VyIiwiSW5zdGl0dXRpb25BZG1pbmlzdHJhdG9yIiwiSW5zdGl0dXRpb25NYW5hZ2VyIiwiSW5zdGl0dXRpb25Vc2VyIl0sImp0aSI6IjZiZDFhMGQwLWVmYTQtNGZkYS1hOTg1LWZlZGI0Y2M1NzdhMyJ9.KsvwI5wXiQZ656I9wU2fGbleEFxwRUro8_UbF5yC_Ow',
  },
};

const api: AxiosInstance = axios.create(config);

// Request interceptor
api.interceptors.request.use(
  (config: any) => {
    // Todo: add additional headers or modify the request here if needed
    return config;
  },
  (error: any) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response: AxiosResponse) => {
    // Todo: handle successful responses if needed
    return response;
  },
  (error: any) => {
    if (error.response) {
      switch (error.response.status) {
        case 401:
          console.error('Unauthorized access');
          break;
        case 404:
          console.error('Resource not found');
          break;
        default:
          console.error('An error occurred:', error.response.status);
      }
    } else if (error.request) {
      // The request was made but no response was received
      console.error('No response received:', error.request);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error('Error:', error.message);
    }
    return Promise.reject(error);
  }
);

export default api;
