import { apiRequest } from '../apiUtils';
import { API_ENDPOINTS } from '../apiEndpoints';

export const createOrUpdateEmployee = (employeeKey: string, employeeData: any, context: any) =>
  apiRequest('put', `${API_ENDPOINTS.EMPLOYEE.BASE}/${employeeKey}`, employeeData, { context });

export const getEmployee = (employeeKey: string, context: any) =>
  apiRequest('get', `${API_ENDPOINTS.EMPLOYEE.BASE}/${employeeKey}`, null, { context });

export const getEmployeeAuthUrl = (employeeKey: string, context: any, customer: any) =>
  apiRequest('get', `${API_ENDPOINTS.EMPLOYEE.BASE}/${employeeKey}${API_ENDPOINTS.EMPLOYEE.AUTH}`, null, {
    context,
    customer,
  });
