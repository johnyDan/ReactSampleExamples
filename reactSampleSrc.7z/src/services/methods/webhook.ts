import { ApiResponse, Webhook } from '../apiTypes';
import { apiRequest } from '../apiUtils';
import { API_ENDPOINTS } from '../apiEndpoints';

export const getWebhooks = (context?: string): Promise<ApiResponse<Webhook[]>> =>
  apiRequest('get', API_ENDPOINTS.WEBHOOK, null, { context });

export const createWebhook = (webhookData: Omit<Webhook, 'id'>, context?: string): Promise<ApiResponse<Webhook>> =>
  apiRequest<Omit<Webhook, 'id'>>('post', API_ENDPOINTS.WEBHOOK, webhookData, { context });

export const deleteWebhook = (id: string, context?: string): Promise<ApiResponse<void>> =>
  apiRequest('delete', `${API_ENDPOINTS.WEBHOOK}/${id}`, null, { context });
