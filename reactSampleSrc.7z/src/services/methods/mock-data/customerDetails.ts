export const customerFound = {
  data: {
    item: {
      email: 'testcustomer@fc.com',
      phoneNumber: '9848022338',
      accountHolders: [
        {
          firstName: 'testCustomer',
          middleInitial: 't',
          lastName: 'test',
          ssnTin: '678975778',
        },
      ],
      accounts: [
        {
          number: '126789',
          type: 'Checking',
          name: 'Checking',
          routingNumber: '124084834',
          index: 0,
          metadata: {},
        },
        {
          number: '126785',
          type: 'Checking',
          name: 'Checking',
          routingNumber: '124084834',
          index: 1,
          metadata: {},
        },
      ],
      addresses: [
        {
          line1: 'line 1 ',
          line2: 'line 2',
          line3: 'line 3',
          city: 'test city',
          zip: '77427',
          state: 'FL',
          country: 'US',
        },
      ],
      metadata: {
        minim_2: '<string>',
      },
    },
    kind: 'Customer',
    lang: 'en-US',
  },
  apiVersion: '3.0.0',
  context: 'testing',
  id: '7be496c4042e49fa9c36c004108f864a',
};

export const customerNotFound = {
  error: {
    code: 404,
    message: 'Customer not found. This user has either not been enrolled or has been disabled due to inactivity.',
    errors: [
      {
        message: 'Customer not found. This user has either not been enrolled or has been disabled due to inactivity.',
      },
    ],
  },
  apiVersion: '3.0.0',
  id: '029359346b5d4cdd8357faf1c172f63b',
};
