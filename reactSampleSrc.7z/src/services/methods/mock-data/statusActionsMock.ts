export const statusesMock = {
  data: {
    currentItemCount: 10,
    items: [
      {
        id: 'Ready',
        label: 'Ready',
        help: 'The switch is ready to submit for processing.',
      },
      {
        id: 'Incomplete',
        label: 'Incomplete',
        help: 'The switch is missing information required for processing.',
      },
      {
        id: 'Canceled',
        label: 'Canceled',
        help: 'The switch has been canceled.',
      },
      {
        id: 'Submitted',
        label: 'Submitted',
        help: 'The switch has been submitted for processing.',
      },
      {
        id: 'Printed',
        label: 'Printed',
        help: 'The switch has been printed for signature and/or in-person delivery.',
      },
      {
        id: 'Processing',
        label: 'In Process',
        help: 'The switch is currently being processed by our fulfillment team.',
      },
      {
        id: 'Sent',
        label: 'Sent',
        help: 'The switch has been sent to the company or govt. agency for action.',
      },
      {
        id: 'Complete',
        label: 'Complete',
        help: 'The company or govt. agency has acknowledged that the change has been completed.',
      },
      {
        id: 'UnableToProcess',
        label: 'Unable To Process',
        help: 'The switch is unable to be processed.',
      },
      {
        id: 'Deleted',
        label: 'Deleted',
        help: 'The switch is deleted',
      },
    ],
    kind: 'types#switch#statuses',
    lang: 'en-US',
  },
  apiVersion: '3.0.0',
  id: 'bfb3765df0ee4867b56a2537480967c8',
};

export const actionsMock = {
  data: {
    currentItemCount: 12,
    items: [
      {
        id: 'HTTP-PUT',
        label: 'Save',
        help: 'Saves a switch',
      },
      {
        id: 'Submit',
        label: 'Submit',
        help: 'Submit the switch for processing.',
      },
      {
        id: 'Cancel',
        label: 'Cancel',
        help: 'Cancel the switch.',
      },
      {
        id: 'Complete',
        label: 'Complete',
        help: "You've taken the steps to make this change online or in person, so mark it complete.",
      },
      {
        id: 'PrintForMailing',
        label: 'Print For Mailing',
        help: 'Print this switch for mailing',
      },
      {
        id: 'Print',
        label: 'Print',
        help: 'Print the switch to sign or deliver in person.',
      },
      {
        id: 'Uncancel',
        label: 'Un-Cancel',
        help: 'Returns a canceled switch back to a state where it can be edited.',
      },
      {
        id: 'HTTP-DELETE',
        label: 'Delete',
        help: 'Deletes a switch that has been canceled.',
      },
      {
        id: 'StartProcessing',
        label: 'Start Processing',
        help: 'Start the processing of the switch',
      },
      {
        id: 'Reassign',
        label: 'Reassign',
        help: 'Reassign the switch',
      },
      {
        id: 'MailReturned',
        label: 'Mail Returned',
        help: 'Mail the returned switch.',
      },
      {
        id: 'Reject',
        label: 'Reject',
        help: 'Reject the switch.',
      },
    ],
    kind: 'types#switch#actions',
    lang: 'en-US',
  },
  apiVersion: '3.0.0',
  id: 'd6cea6a8b43d419699b36463e8094fb5',
};
