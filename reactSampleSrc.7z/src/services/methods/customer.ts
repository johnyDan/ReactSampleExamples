import { ApiResponse, Customer, CustomerKey } from '../apiTypes';
import { apiRequest } from '../apiUtils';
import { API_ENDPOINTS } from '../apiEndpoints';
import { customerFound, customerNotFound } from './mock-data/customerDetails';
import { createOrUpdateCustomerSuccess, createUpdateUserMockFailed } from './mock-data/createUpdateUserMock';

export const createOrUpdateCustomer = (
  customerKey: CustomerKey,
  customerData: Partial<Customer>,
  context?: string
): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(createOrUpdateCustomerSuccess);
      }, 1000);
    });
  } else {
    return apiRequest<Partial<Customer>>('put', `${API_ENDPOINTS.CUSTOMER.BASE}/${customerKey}`, customerData, {
      context,
    });
  }
};

export const getCustomer = (customerKey: CustomerKey, context?: string): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(customerNotFound);
      }, 1000);
    });
  } else {
    return apiRequest('get', `${API_ENDPOINTS.CUSTOMER.BASE}/${customerKey}`, null, { context });
  }
};

export const getCustomerAuthUrl = (customerKey: CustomerKey, context?: string): Promise<ApiResponse<string>> =>
  apiRequest('get', `${API_ENDPOINTS.CUSTOMER.BASE}/${customerKey}${API_ENDPOINTS.CUSTOMER.AUTH}`, null, { context });
