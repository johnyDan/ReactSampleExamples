import React, { forwardRef, useState } from 'react';
import { TextField, InputAdornment, Typography, Box } from '@mui/material';
import { styled, Theme } from '@mui/material/styles';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import getTheme from '../../styles/themeSelector';

type FieldType = 'text' | 'phone' | 'amount' | 'number' | string;
type IconPosition = 'start' | 'end';

const theme = getTheme();
interface CustomInputProps {
  label: string;
  name: string;
  placeholder?: string;
  helperText?: string;
  error?: boolean;
  errorMessage?: string;
  fieldType: FieldType;
  icon?: React.ReactNode;
  iconPosition?: IconPosition;
  value: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  fullWidth?: boolean;
  multiline?: boolean;
  rows?: number;
}

const StyledTextField = styled(TextField, {
  shouldForwardProp: (prop) => prop !== 'fieldType',
})<{ fieldType: FieldType }>(({ theme, error, fieldType }) => ({
  width: '100%',
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px',
    '& fieldset': {
      borderColor: theme.palette.custom.outline,
      borderWidth: '2px',
    },
    '&:hover fieldset': {
      borderColor: theme.palette.custom.outline,
    },
    '&.Mui-focused fieldset': {
      borderColor: theme.palette.custom.outline,
      borderWidth: '2px',
    },
    '&.Mui-error': {
      '& fieldset': {
        borderColor: theme.palette.custom.outline,
        borderWidth: '2px',
        // borderBottomColor: theme.palette.error.main,
        // borderBottomWidth: '4px',
      },
    },
    ...(fieldType === 'amount' && {
      paddingLeft: 0,
      '& input': {
        paddingLeft: '40px',
      },
    }),
  },
  '& .MuiInputLabel-root': {
    fontFamily: theme.typography.fontFamily,
    fontWeight: 600,
    fontSize: '18px',
    color: error ? theme.palette.error.main : theme.palette.primary.main,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    maxWidth: 'calc(100% - 24px)',
    '&.MuiInputLabel-shrink': {
      transform: 'translate(14px, -9px) scale(0.75)',
      maxWidth: 'calc(133% - 30px)',
      textTransform: 'uppercase',
      fontWeight: 600,
      fontSize: 'calc(133% - 2px)',
      letterSpacing: '0.1em',
      backgroundColor: 'white',
      color: error ? theme.palette.error.main : theme.palette.custom.paragraphText,
    },
    ...(fieldType === 'amount' && {
      transform: 'translate(40px, 16px) scale(1)',
      '&.MuiInputLabel-shrink': {
        transform: 'translate(14px, -9px) scale(0.75)',
        maxWidth: 'calc(133% - 24px)',
        textTransform: 'uppercase',
        fontWeight: 600,
        fontSize: 'calc(133% - 2px)',
        letterSpacing: '0.1em',
        backgroundColor: 'white',
        color: error ? theme.palette.error.main : theme.palette.custom.paragraphText,
      },
    }),
  },

  '& .MuiInputBase-input': {
    fontFamily: theme.typography.fontFamily,
    fontWeight: 600,
    fontSize: '18px',
    color: theme.palette.primary.main,
  },
  '& .MuiFormHelperText-root': {
    fontFamily: theme.typography.fontFamily,
    fontWeight: 400,
    fontSize: '16px',
    color: error ? theme.palette.error.main : theme.palette.custom.paragraphText,
    marginTop: '4px',
  },
}));

const AmountAdornment = styled(InputAdornment)(({ theme }) => ({
  position: 'absolute',
  left: 0,
  top: 0,
  bottom: 0,
  width: '40px',
  backgroundColor: '#F0F0F0',
  borderTopLeftRadius: '6px',
  borderBottomLeftRadius: '6px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  pointerEvents: 'none',
  '& p': {
    fontFamily: theme.typography.fontFamily,
    fontWeight: 600,
    fontSize: '18px',
    color: theme.palette.custom.paragraphText,
    lineHeight: 1,
    marginTop: theme.spacing(7.5),
  },
}));

const HelperText = styled(Typography)(({ theme }) => ({
  fontFamily: theme.typography.fontFamily,
  fontWeight: 400,
  fontSize: '16px',
  color: theme.palette.custom.paragraphText,
  marginTop: '4px',
}));

const ErrorText = styled(Typography)(({ theme }) => ({
  fontFamily: theme.typography.fontFamily,
  fontWeight: 600,
  fontSize: '16px',
  color: theme.palette.error.main,
  display: 'flex',
  alignItems: 'center',
  marginTop: '4px',
}));

const CustomInput = forwardRef<HTMLInputElement, CustomInputProps>(
  (
    {
      label,
      name,
      placeholder,
      helperText,
      error = false,
      errorMessage,
      fieldType,
      icon,
      iconPosition = 'end',
      value,
      onChange,
      fullWidth = false,
      multiline = false,
      rows,
    },
    ref
  ) => {
    const [isFocused, setIsFocused] = useState(false);

    const handleFocus = () => setIsFocused(true);
    const handleBlur = (event: React.FocusEvent<HTMLInputElement>) => {
      setIsFocused(false);
      if (fieldType === 'phone') {
        formatPhoneNumber(event);
      }
    };

    const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      if (fieldType === 'phone') {
        // Allow only numeric input
        const numericValue = event.target.value.replace(/\D/g, '');
        onChange({
          ...event,
          target: { ...event.target, name, value: numericValue },
        });
      } else {
        onChange(event);
      }
    };

    const renderInputAdornment = (theme: Theme) => {
      if (fieldType === 'amount') {
        return {
          startAdornment: (
            <AmountAdornment position="start">
              <Typography component="p">$</Typography>
            </AmountAdornment>
          ),
        };
      }
      if (icon) {
        return {
          [`${iconPosition}Adornment`]: (
            <InputAdornment position={iconPosition}>
              {React.cloneElement(icon as React.ReactElement, {
                style: { color: theme.palette.primary.main, fontSize: 24 },
              })}
            </InputAdornment>
          ),
        };
      }
      return {};
    };

    const inputProps: any = {
      ...renderInputAdornment(theme),
    };

    if (fieldType === 'amount') {
      inputProps.inputProps = {
        step: fieldType === 'amount' ? '0.01' : '1',
        min: '0',
      };
    }

    if (fieldType === 'number') {
      inputProps.inputProps = {
        pattern: '[0-9]*',
        inputMode: 'numeric',
        step: '1',
        min: '0',
        max: '100',
      };
    }

    if (fieldType === 'phone') {
      inputProps.inputProps = {
        pattern: '[0-9]*',
        inputMode: 'numeric',
      };
    }

    const formatPhoneNumber = (event: React.FocusEvent<HTMLInputElement>) => {
      const input = event.target.value.replace(/\D/g, '');
      const formattedNumber = input.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
      onChange({
        ...event,
        target: { ...event.target, name, value: formattedNumber },
      });
    };

    const inputType = fieldType === 'amount' || fieldType === 'number' ? 'number' : 'text';

    return (
      <Box>
        <StyledTextField
          label={label}
          name={name}
          placeholder={placeholder}
          error={error}
          value={value}
          onChange={handleInputChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          fullWidth={fullWidth}
          InputProps={inputProps}
          type={inputType}
          InputLabelProps={{
            shrink: fieldType === 'amount' ? value !== '' || isFocused : undefined,
            title: label,
          }}
          fieldType={fieldType}
          multiline={multiline}
          rows={rows}
          inputRef={ref}
        />
        {helperText && !error && <HelperText>{helperText}</HelperText>}
        {error && errorMessage && (
          <ErrorText>
            <HighlightOffIcon style={{ marginRight: '4px', fontSize: 16 }} />
            {errorMessage}
          </ErrorText>
        )}
      </Box>
    );
  }
);

export default CustomInput;
