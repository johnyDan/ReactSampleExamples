import React from 'react';
import { Select, MenuItem, FormControl, SelectChangeEvent, FormHelperText, Typography } from '@mui/material';
import { SelectProps } from '@mui/material/Select';
import { styled } from '@mui/material/styles';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

interface CustomDropdownProps {
  options: { value: string; label: string }[];
  placeholder: string;
  fullWidth?: boolean;
  value?: unknown;
  name?: string;
  error?: boolean;
  helperText?: string;
  errorMessage?: string;
}

type CustomDropdownComponentProps = CustomDropdownProps &
  Omit<SelectProps<unknown>, 'onChange'> & {
    onChange?: (event: SelectChangeEvent<unknown>, child: React.ReactNode) => void;
  };

const StyledFormControl = styled(FormControl)<{ fullWidth?: boolean }>(({ fullWidth }) => ({
  width: fullWidth ? '100%' : '498px',
}));

const StyledSelect = styled(Select)<{ error?: boolean }>(({ theme, error }) => ({
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: error ? theme.palette.error.main : theme.palette.custom.outline,
    borderWidth: '2px',
    borderRadius: '8px',
  },
  '&:hover .MuiOutlinedInput-notchedOutline': {
    borderColor: error ? theme.palette.error.main : theme.palette.custom.outline,
  },
  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
    borderColor: error ? theme.palette.error.main : theme.palette.custom.outline,
    borderWidth: '2px',
  },
  '& .MuiSelect-select': {
    padding: '16px 18px',
    fontFamily: theme.typography.fontFamily,
    fontWeight: 600,
    fontSize: '18px',
    color: theme.palette.custom.paragraphText,
  },
  '& .MuiSelect-icon': {
    color: error ? theme.palette.error.main : theme.palette.custom.paragraphText,
    width: '18px',
    height: '18px',
    right: '14px',
  },
  '& .MuiOutlinedInput-input': {
    color: theme.palette.custom.headingsUI,
  },
}));

const StyledMenuItem = styled(MenuItem)(() => ({
  whiteSpace: 'normal',
  wordBreak: 'break-word',
}));

const Placeholder = styled('div')<{ error?: boolean }>(({ theme, error }) => ({
  fontFamily: theme.typography.fontFamily,
  fontWeight: 600,
  fontSize: 'calc(100% - 1px)',
  color: error ? theme.palette.error.main : theme.palette.primary.main,
  whiteSpace: 'wrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
}));

const FieldHint = styled('div')(({ theme }) => ({
  position: 'absolute',
  top: '-10px',
  left: '10px',
  padding: '0 4px',
  backgroundColor: 'white',
  fontFamily: theme.typography.fontFamily,
  fontWeight: 600,
  fontSize: 'calc(100% - 3px)',
  color: theme.palette.custom.paragraphText,
  letterSpacing: '0.1em',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  maxWidth: 'calc(100% - 24px)',
}));

const ErrorText = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
  fontSize: '16px',
  color: theme.palette.error.main,
  display: 'flex',
  alignItems: 'center',
  marginTop: '4px',
}));

const CustomDropdown: React.FC<CustomDropdownComponentProps> = ({
  options,
  placeholder,
  onChange,
  fullWidth = false,
  value,
  name,
  error = false,
  errorMessage,
  helperText,
  ...props
}) => {
  const handleChange = (event: SelectChangeEvent<unknown>, child: React.ReactNode) => {
    if (onChange) {
      onChange(event, child);
    }
  };

  const getOptionLabel = (value: string): string => {
    const option = options.find((opt) => opt.value === value);
    return option ? option.label : '';
  };

  return (
    <StyledFormControl variant="outlined" fullWidth={fullWidth} error={error}>
      <StyledSelect
        value={value || ''}
        onChange={handleChange}
        displayEmpty
        IconComponent={ExpandMoreIcon}
        error={error}
        renderValue={(selected) => {
          if (selected === '') {
            return <Placeholder error={error}>{placeholder}</Placeholder>;
          }
          return getOptionLabel(selected as string);
        }}
        {...props}>
        {options.map((option) => (
          <StyledMenuItem key={option.value} value={option.value}>
            {option.label}
          </StyledMenuItem>
        ))}
      </StyledSelect>
      {value !== '' && <FieldHint>{placeholder.toUpperCase()}</FieldHint>}
      {helperText && <FormHelperText>{helperText}</FormHelperText>}
      {error && errorMessage && (
        <ErrorText>
          <HighlightOffIcon style={{ marginRight: '4px', fontSize: 16 }} />
          {errorMessage}
        </ErrorText>
      )}
    </StyledFormControl>
  );
};

export default CustomDropdown;
