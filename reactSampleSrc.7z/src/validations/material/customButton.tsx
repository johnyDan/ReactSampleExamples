import React from 'react';
import { Button, ButtonProps } from '@mui/material';
import { styled } from '@mui/material/styles';

interface CustomButtonProps extends Omit<ButtonProps, 'variant'> {
  variant?: 'primary' | 'secondary' | 'tertiary';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
}

const StyledButton = styled(Button, {
  shouldForwardProp: (prop) => prop !== 'variant' && prop !== 'iconPosition',
})<CustomButtonProps>(({ theme, variant }) => ({
  fontSize: '18px',
  height: '66px',
  borderRadius: '8px',
  padding: theme.spacing(0, 3),
  textTransform: 'none',
  whiteSpace: 'nowrap',
  minWidth: 'auto',
  ...(variant === 'primary' && {
    backgroundColor: theme.palette.custom.primaryButtonUI,
    color: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: theme.palette.custom.primaryButtonHover,
    },
  }),
  ...(variant === 'secondary' && {
    border: theme.palette.custom.secondaryButtonBorder
      ? `2px solid ${theme.palette.custom.secondaryButtonBorder}`
      : 'none',
    backgroundColor: theme.palette.custom.secondaryButtonUI,
    color: theme.palette.primary.main,
    '&:hover': {
      backgroundColor: theme.palette.custom.secondaryButtonHover,
    },
  }),
  [theme.breakpoints.down('md')]: {
    fontSize: '18px',
    height: '48px',
    width: '100%',
  },
}));

const CustomButton: React.FC<CustomButtonProps> = ({
  variant = 'primary',
  icon,
  iconPosition = 'right',
  children,
  ...props
}) => {
  return (
    <StyledButton
      variant={variant as any}
      startIcon={iconPosition === 'left' ? icon : undefined}
      endIcon={iconPosition === 'right' ? icon : undefined}
      {...props}>
      {children}
    </StyledButton>
  );
};

export default CustomButton;
