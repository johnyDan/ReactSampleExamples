import React from 'react';
import { Typography, TypographyProps } from '@mui/material';
import { useMessages } from '../../utils/messageContext';

interface CustomTypographyProps extends Omit<TypographyProps, 'children'> {
  textKey: string;
}

export const CustomTypography: React.FC<CustomTypographyProps> = ({ textKey, ...props }) => {
  const { messages } = useMessages();
  return <Typography {...props}>{messages[textKey as keyof typeof messages] || textKey}</Typography>;
};
