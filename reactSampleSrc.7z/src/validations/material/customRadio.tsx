import React from 'react';
import { Radio, RadioProps, FormControlLabel, Typography, Box } from '@mui/material';
import { styled } from '@mui/material/styles';

interface CustomRadioProps extends Omit<RadioProps, 'fullWidth'> {
  label: string;
  helperText?: string;
  helperTextPosition?: 'inside' | 'outside';
  fullWidth?: boolean;
  orientation?: 'horizontal' | 'vertical';
}

const StyledFormControlLabel = styled(FormControlLabel, {
  shouldForwardProp: (prop) => prop !== 'fullWidth' && prop !== 'checked',
})<{ fullWidth?: boolean; disabled?: boolean; checked: boolean }>(({ theme, fullWidth, disabled, checked }) => ({
  margin: 0,
  width: fullWidth ? '100%' : 'auto',
  border: `2px solid ${
    checked ? theme.palette.custom.selectedElements : disabled ? theme.palette.custom.outline : '#DADCE1'
  }`,
  borderRadius: '8px',
  padding: '4px',
  marginTop: '16px',
  '& .MuiTypography-root': {
    color: disabled ? theme.palette.custom.disabled : theme.palette.custom.headingsUI,
  },
  '& .Mui-checked': {
    color: theme.palette.custom.selectedElements,
  },
}));

const CustomRadio: React.FC<CustomRadioProps> = ({
  label,
  helperText,
  helperTextPosition = 'outside',
  fullWidth = false,
  checked,
  orientation = 'vertical',
  ...props
}) => {
  return (
    <Box
      sx={{
        width: fullWidth ? '100%' : 'auto',
        display: orientation === 'horizontal' ? 'inline-flex' : 'block',
        alignItems: 'center',
        mr: orientation === 'horizontal' ? 2 : 0,
      }}>
      <StyledFormControlLabel
        control={<Radio checked={checked} {...props} />}
        label={
          <Box>
            <Typography variant="body2">{label}</Typography>
            {helperText && helperTextPosition === 'inside' && <Typography variant="body1">{helperText}</Typography>}
          </Box>
        }
        fullWidth={fullWidth}
        disabled={props.disabled}
        checked={checked || false}
      />
      {helperText && helperTextPosition === 'outside' && <Typography variant="body2">{helperText}</Typography>}
    </Box>
  );
};

export default CustomRadio;
