import React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { Box, FormControl, FormHelperText, Typography } from '@mui/material';
import { FieldConfig } from '../types/formsConfigTypes';
import dayjs, { Dayjs } from 'dayjs';
import CustomInput from '../material/customInput';
import CustomDropdown from '../material/customDropdown';
import CustomRadio from '../material/customRadio';
import CustomCheckbox from '../material/customCheckbox';
import CustomDatePicker from '../material/customDatePicker';
import { createDisableDateFunction, parseDateValue } from '../utils/dateUtility';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

interface FormFieldProps {
  fieldName: string;
  fieldConfig: FieldConfig;
}

const FormField: React.FC<FormFieldProps> = ({ fieldName, fieldConfig }) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();

  const fieldError = getNestedValue(errors, fieldName);

  const { label, inputType, validations, options, orientation } = fieldConfig;

  // Map inputType to fieldType for CustomInput
  const fieldTypeMap: { [key: string]: string } = {
    text: 'text',
    phone: 'phone',
    amount: 'amount',
    number: 'number',
    // Add more mappings if needed
  };

  switch (inputType) {
    case 'text':
    case 'phone':
    case 'amount':
    case 'number':
      return (
        <Controller
          name={fieldName}
          control={control}
          rules={validations}
          render={({ field }) => (
            <CustomInput
              {...field}
              value={field.value ?? ''}
              label={label}
              fieldType={fieldTypeMap[inputType]}
              error={!!fieldError}
              errorMessage={fieldError?.message as string}
              fullWidth
            />
          )}
        />
      );

    case 'textarea':
      return (
        <Controller
          name={fieldName}
          control={control}
          rules={validations}
          render={({ field }) => (
            <CustomInput
              {...field}
              label={label}
              value={field.value ?? ''}
              fieldType="text"
              error={!!fieldError}
              errorMessage={fieldError?.message as string}
              fullWidth
              multiline
              rows={4}
            />
          )}
        />
      );

    case 'select':
      return (
        <Controller
          name={fieldName}
          control={control}
          rules={validations}
          render={({ field }) => (
            <CustomDropdown
              name={field.name}
              value={field.value || ''}
              onChange={(event) => {
                field.onChange(event.target.value);
              }}
              options={options || []}
              placeholder={label}
              fullWidth
              error={!!fieldError}
              errorMessage={fieldError?.message as string}
            />
          )}
        />
      );

    case 'radio':
      return (
        <Controller
          name={fieldName}
          control={control}
          rules={validations}
          render={({ field }) => (
            <>
              {label && (
                <Typography variant="h5" gutterBottom>
                  {label}
                </Typography>
              )}
              {fieldError && (
                <Typography
                  color="error"
                  sx={{ fontSize: '16px', fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                  <HighlightOffIcon style={{ marginRight: '4px', fontSize: 16 }} />
                  {fieldError.message}
                </Typography>
              )}
              <Box
                sx={{
                  display: 'flex',
                  flexDirection: orientation === 'horizontal' ? 'row' : 'column',
                  gap: orientation === 'horizontal' ? 2 : 0,
                }}>
                {options &&
                  options.map((option: any) => (
                    <CustomRadio
                      key={option.value}
                      value={option.value}
                      label={option.label}
                      helperText={option.helperText}
                      helperTextPosition="inside"
                      checked={field.value === option.value}
                      onChange={() => field.onChange(option.value)}
                      fullWidth
                      orientation={option.orientation || 'vertical'}
                    />
                  ))}
              </Box>
            </>
          )}
        />
      );

    case 'checkbox':
      return (
        <FormControl error={!!fieldError}>
          <Controller
            name={fieldName}
            control={control}
            rules={validations}
            render={({ field }) => (
              <CustomCheckbox {...field} checked={!!field.value} label={label} subLabel={fieldConfig.subLabel} />
            )}
          />
          {fieldError && <FormHelperText>{fieldError.message as string}</FormHelperText>}
        </FormControl>
      );

    case 'date':
      return (
        <Controller
          name={fieldName}
          control={control}
          rules={validations}
          render={({ field }) => {
            const selectedDate = field.value ? dayjs(field.value) : null;

            const maxDate = fieldConfig.additionalProps?.maxDate
              ? parseDateValue(fieldConfig.additionalProps.maxDate)
              : undefined;

            const minDate = fieldConfig.additionalProps?.minDate
              ? parseDateValue(fieldConfig.additionalProps.minDate)
              : undefined;

            const shouldDisableDate = fieldConfig.additionalProps?.shouldDisableDate
              ? createDisableDateFunction(fieldConfig.additionalProps.shouldDisableDate, fieldConfig)
              : undefined;

            return (
              <CustomDatePicker
                name={field.name}
                value={selectedDate}
                onChange={(date: Dayjs | null) => {
                  field.onChange(date ? date.toISOString() : '');
                }}
                label={label}
                error={!!fieldError}
                // helperText={fieldConfig.helpe as string}
                errorMessage={fieldError?.message as string}
                disablePast={fieldConfig.additionalProps?.disablePast}
                maxDate={maxDate}
                minDate={minDate}
                shouldDisableDate={shouldDisableDate}
              />
            );
          }}
        />
      );

    case 'composite':
      return (
        <Box sx={{ mb: 2 }}>
          <Typography variant="h6">{label}</Typography>
          {Object.entries(fieldConfig.fields!).map(([subKey, subFieldConfig]) => (
            <Box sx={{ mt: 2, mb: 2 }} key={subKey}>
              <FormField key={subKey} fieldName={`${fieldName}.${subKey}`} fieldConfig={subFieldConfig} />
            </Box>
          ))}
        </Box>
      );

    default:
      return null;
  }
};

const getNestedValue = (obj: any, path: string) => {
  return path.split('.').reduce((acc, part) => acc && acc[part], obj);
};

export default FormField;
