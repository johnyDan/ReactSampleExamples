import FormsConfig from '../../config/app/app-config.json';

export { FormsConfig };
