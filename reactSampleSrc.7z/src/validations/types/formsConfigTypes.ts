import { RegisterOptions } from 'react-hook-form';
import { CustomValidationNames } from '../validators/customValidationRules';

export interface CustomValidationConfig {
  name: CustomValidationNames;
  message: string;
  params?: { [key: string]: any };
}

export type FieldValidations = RegisterOptions;

export interface FieldConfig {
  label: string;
  inputType: string;
  options?: Array<{ label: string; value: string; helperText?: string }>;
  orientation?: 'horizontal' | 'vertical';
  validations?: FieldValidations;
  additionalProps?: { [key: string]: any };
  fields?: { [key: string]: FieldConfig };
  subLabel?: string;
}

export interface FormFields {
  [fieldName: string]: FieldConfig;
}

export interface FormConfig {
  fields: FormFields | { [key: string]: FieldConfig };
}

export interface PageForms {
  [formName: string]: FormConfig;
}

export interface FormsConfig {
  [pageName: string]: PageForms;
}
