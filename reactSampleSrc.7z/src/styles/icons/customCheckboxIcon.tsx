import React from 'react';
import { SvgIcon, SvgIconProps } from '@mui/material';

interface CustomCheckboxIconProps extends SvgIconProps {
  isChecked?: boolean;
}

const CustomCheckboxIcon: React.FC<CustomCheckboxIconProps> = ({ isChecked, ...props }) => (
  <SvgIcon {...props}>
    <rect width="24" height="24" rx="8" fill="currentColor" />
    {isChecked && (
      <path
        d="M14.9998 8.8L10.7998 13.1L8.9998 11.2C8.5998 10.8 7.9998 10.8 7.5998 11.2C7.1998 11.6 7.1998 12.2 7.5998 12.6L10.1998 15.2C10.3998 15.4 10.5998 15.5 10.8998 15.5C11.1998 15.5 11.3998 15.4 11.5998 15.2L16.4998 10.2C16.8998 9.8 16.8998 9.2 16.4998 8.8C16.0998 8.4 15.3998 8.4 14.9998 8.8Z"
        fill="#00505C"
      />
    )}
  </SvgIcon>
);

export default CustomCheckboxIcon;
