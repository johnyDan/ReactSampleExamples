import { createTheme } from '@mui/material/styles';

const ABCTheme = createTheme({
  typography: {
    fontFamily: '"Sofia Pro", sans-serif',
    h1: {
      fontWeight: 600,
      fontSize: '30px',
      lineHeight: '38px',
      color: '#00505C',
    },
    h2: {
      fontWeight: 600,
      fontSize: '22px',
      lineHeight: '28px',
      color: '#00505C',
    },
    h3: {
      fontWeight: 400,
      fontSize: '22px',
      lineHeight: '28px',
      color: '#00505C',
    },
    h4: {
      fontWeight: 600,
      fontSize: '18px',
      lineHeight: '20px',
      color: '#00505C',
    },
    h5: {
      fontWeight: 600,
      fontSize: '14px',
      lineHeight: '18px',
      color: '#00505C',
    },
    body1: {
      fontWeight: 400,
      fontSize: '13px',
      lineHeight: '18px',
      color: '#555555',
    },
    body2: {
      fontWeight: 400,
      fontSize: '16px',
      lineHeight: '20px',
      color: '#555555',
    },
  },
  palette: {
    primary: {
      main: '#00505C',
      light: '#00838E',
      dark: '#00505C',
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#A5D867',
      light: '#8FD063',
      dark: '#A5D867',
      contrastText: '#00505C',
    },
    error: {
      main: '#950000',
      contrastText: '#FFFFFF',
    },
    warning: {
      main: '#FFA000',
      contrastText: '#FFFFFF',
    },
    info: {
      main: '#00505C',
      contrastText: '#FFFFFF',
    },
    success: {
      main: '#00838A',
      contrastText: '#FFFFFF',
    },
    text: {
      primary: '#555555',
      secondary: '#555555',
    },
    background: {
      default: '#FFFFFF',
      paper: '#FFFFFF',
    },
    action: {
      active: '#00505C',
      hover: '#8FD063',
    },
    custom: {
      headingsUI: '#00505C',
      selectedElements: '#00505C',
      uiElements: '#00838A',
      outline: '#D5D5D5',
      contentBackground: '#DFF6F7',
      primaryButtonUI: '#A5D867',
      primaryButtonHover: '#9FD063',
      secondaryButtonUI: '#D5D5D5',
      secondaryButtonHover: '#F0F0F0',
      paragraphText: '#555555',
      disabled: '#D5D5D5',
      disabledText: '#FFFFFF',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          fontFamily: '"Sofia Pro", Arial, sans-serif',
          fontWeight: 'bold',
          fontSize: '18px',
          borderRadius: '8px',
          textTransform: 'none',
          padding: '16px 24px',
          '&.MuiButton-sizeMedium': {
            height: '56px',
          },
          '@media (max-width: 768px)': {
            height: '48px',
            width: '100%',
          },
        },
        containedPrimary: {
          backgroundColor: '#A5D867',
          color: '#00505C',
          '&:hover': {
            backgroundColor: '#9FD063',
          },
        },
        containedSecondary: {
          backgroundColor: '#F0F0F0',
          color: '#00505C',
          '&:hover': {
            backgroundColor: '#EAEAEA',
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          boxShadow: 'none',
        },
      },
    },
    MuiRadio: {
      styleOverrides: {
        root: {
          color: '#DADCE1',
          '&.Mui-checked': {
            color: '#007255',
          },
        },
      },
    },
    MuiCheckbox: {
      styleOverrides: {
        root: {
          color: '#D5D5D5',
          '&.Mui-checked': {
            color: '#00505C',
          },
          '&.Mui-disabled': {
            color: '#D5D5D5',
          },
          width: '24px',
          height: '24px',
        },
      },
    },
  },
});

export default ABCTheme;
