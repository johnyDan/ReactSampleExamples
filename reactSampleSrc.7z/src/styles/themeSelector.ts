import ABCTheme from './themes/ABC-theme';
import DEFTheme from './themes/DEF-theme';

declare global {
  interface Window {
    brandTheme?: string;
  }
}

const getTheme = () => {
  if (window.brandTheme === 'DEF') {
    return DEFTheme;
  }
  return ABCTheme;
};

export default getTheme;
