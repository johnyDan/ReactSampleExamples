import { useState, useEffect } from 'react';

export function useUserData() {
  const [userData, setUserData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    console.log('useUserData hook mounted');

    // Check for existing data
    if (window.initialUserData) {
      // console.log('Initial user data found:', window.initialUserData);
      setUserData(window.initialUserData);
      setIsLoading(false);
      return;
    }

    const handleUserDataReceived = (event: CustomEvent) => {
      // console.log('User data received from event:', event.detail);
      setUserData(event.detail);
      setIsLoading(false);
    };

    window.addEventListener('userDataReceived', handleUserDataReceived as EventListener);

    const timeoutId = setTimeout(() => {
      if (!userData) {
        console.log('Timeout: No user data received');
        setError('Timeout: Failed to receive user data');
        setIsLoading(false);
      }
    }, 5000);

    return () => {
      window.removeEventListener('userDataReceived', handleUserDataReceived as EventListener);
      clearTimeout(timeoutId);
    };
  }, []);

  return { userData, isLoading, error };
}
