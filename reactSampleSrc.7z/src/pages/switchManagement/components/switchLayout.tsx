import React from 'react';
import { Box, Grid, Typography } from '@mui/material';

interface SwitchLayoutProps {
  staticInfo: {
    title: string;
    subtitle: string;
    description: string;
    stepInfo: string;
  };
  leftContent?: React.ReactNode;
  rightContent: React.ReactNode;
  navigationButtons: React.ReactNode;
}

const SwitchLayout: React.FC<SwitchLayoutProps> = ({ staticInfo, leftContent, rightContent, navigationButtons }) => {
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        minHeight: '90vh',
        width: '100%',
        boxSizing: 'border-box',
      }}>
      {/* Main Content Grid */}
      <Grid
        container
        spacing={4}
        sx={{
          p: { xs: 2, sm: 4 },
          justifyContent: 'space-between',
          flexGrow: 1, // Allows Grid to take up available space
          overflowY: 'auto', // Adds scroll if content overflows
        }}>
        {/* Left Side */}
        <Grid
          item
          xs={12}
          md={5}
          sx={{
            display: 'flex',
            gap: 2,
            flexDirection: 'column',
          }}>
          <Typography variant="h2">{staticInfo?.title}</Typography>
          <Typography variant="h4">{staticInfo?.subtitle}</Typography>
          <Typography variant="body2">{staticInfo?.description}</Typography>
          <Typography variant="body2">{staticInfo?.stepInfo}</Typography>
          {leftContent}
        </Grid>

        {/* Right Side */}
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            flexDirection: 'column',
          }}>
          {rightContent}
        </Grid>
      </Grid>

      {/* Navigation Buttons */}
      <Box
        sx={{
          position: 'sticky',
          bottom: 0,
          backgroundColor: 'background.paper',
          p: 2,
          zIndex: 1000,
        }}>
        {navigationButtons}
      </Box>
    </Box>
  );
};

export default SwitchLayout;
