import React from 'react';
import { Box, Typography, Link, Divider } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import InstructionsBox from '@/components/common/instructionsBox';
import { useRecoilValue } from 'recoil';
import { selectedCompanyState } from '@/state/atoms';
import { validateAndFormatDate } from '@/utils/formatUtils';

interface SwitchDetailsDisplayProps {
  switchData: any;
  isConfirmation: boolean;
  pageTextInfo: {
    title: string;
    description: string;
  };
  onEditAccounts?: () => void;
  onEditAdditionalDetails?: () => void;
}

interface CompanyNameDisplayProps {
  companyName: string;
  isConfirmation: boolean;
  onEditAccounts?: () => void;
  onEditAdditionalDetails?: () => void;
}

const SwitchDetailsDisplay: React.FC<SwitchDetailsDisplayProps> = ({
  switchData,
  isConfirmation,
  pageTextInfo,
  onEditAccounts,
  onEditAdditionalDetails,
}) => {
  const selectedCompany = useRecoilValue(selectedCompanyState);

  const getAccountLabel = (accountIndex: string) => {
    const account = switchData.ux.accounts.choices.find(
      (choice: any) => choice.index.toString() === accountIndex.toString()
    );
    return account ? account.label : 'Unknown Account';
  };

  const getSplitTypeDisplay = (splitType: string, splitAmount: string) => {
    switch (splitType) {
      case 'currency':
        return `$${splitAmount} of each check`;
      case 'percentage':
        return `${splitAmount}% of each check`;
      case 'remainder':
        return 'Remainder of each check';
      default:
        return splitAmount;
    }
  };

  const getFieldValue = (field: any, value: any) => {
    if (field && field.type == 'select') {
      return field.selections.find((selection: any) => selection.key == value)?.label || 'Not Provided';
    } else if (field && field.label.toLowerCase().indexOf('date') > -1) {
      return value ? validateAndFormatDate(value) : 'Not provided';
    } else {
      return value ? (value as string) : 'Not provided';
    }
  };

  const { values, ux } = switchData;

  if (!values || !ux) {
    return <div>No data available to display.</div>;
  }

  return (
    <Box mb={2} mt={2}>
      <Typography variant="h4" color="primary" gutterBottom>
        {pageTextInfo.title}
      </Typography>

      <Typography variant="body2" gutterBottom>
        {pageTextInfo.description}
      </Typography>

      <Divider sx={{ my: 2, ml: 1, mr: 1 }} />

      {/* Display Company Name */}
      <CompanyNameDetail
        companyName={switchData.name}
        isConfirmation={isConfirmation}
        onEditAdditionalDetails={onEditAdditionalDetails}
      />

      {/* Display Additional Fields */}
      {values.fields && Object.keys(values.fields).length > 0 && (
        <Box mb={2}>
          {Object.entries(values.fields).map(([key, value]: [string, any]) => {
            const field = ux.fields.find((field: any) => field.key === key);
            return selectedCompany.manualSetup && field.key == 'name' ? (
              <CompanyNameDetail
                key={key}
                companyName={value}
                isConfirmation={isConfirmation}
                onEditAdditionalDetails={onEditAdditionalDetails}
              />
            ) : (
              <Box key={key} mb={2}>
                <Typography variant="h5" gutterBottom>
                  {field?.label || key}
                </Typography>
                <div>
                  {typeof value === 'object' && value !== null ? (
                    Object.entries(value).map(([subKey, subValue]) => (
                      <Typography variant="body2" sx={{ mb: 0.5 }} key={subKey}>
                        {subKey}: {subValue ? (subValue as string) : 'Not provided'}
                      </Typography>
                    ))
                  ) : (
                    <Typography variant="body2" gutterBottom>
                      {getFieldValue(field, value)}
                    </Typography>
                  )}
                </div>
              </Box>
            );
          })}
        </Box>
      )}
      <Divider sx={{ my: 2, ml: 1, mr: 1 }} />
      {/* Display Account Details */}
      {values.accounts && values.accounts.length > 0 ? (
        values.accounts.map((account: any, index: number) => (
          <Box key={index} mb={2}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography variant="h5">Account {index > 0 ? index + 1 : null}</Typography>
              {!isConfirmation && index == 0 && onEditAccounts && (
                <Link
                  sx={{ display: 'flex', flexDirection: 'row', gap: 1, p: 1, alignItems: 'center' }}
                  onClick={onEditAccounts}>
                  <EditIcon />
                  <Typography variant="body2" color="primary.main">
                    Edit Deposit
                  </Typography>
                </Link>
              )}
            </Box>
            <Typography variant="body2" gutterBottom>
              {getSplitTypeDisplay(account.fields?.splitType, account.fields?.splitAmount)}
            </Typography>
            <Typography variant="body2" gutterBottom>
              Deposited into: {getAccountLabel(account.index)}
            </Typography>
            {/* Display additional account fields if any */}
            {account.fields &&
              Object.entries(account.fields).map(([fieldKey, fieldValue]: [string, any]) => {
                if (fieldKey !== 'splitType' && fieldKey !== 'splitAmount') {
                  return (
                    <Typography variant="body2" sx={{ mb: 0.5 }} key={fieldKey}>
                      {fieldKey}: {fieldValue}
                    </Typography>
                  );
                }
                return null;
              })}
          </Box>
        ))
      ) : (
        <Typography>No account information available.</Typography>
      )}
      <InstructionsBox text="New deposit instructions may take a few pay cycles to reflect on your account." />
    </Box>
  );
};

const CompanyNameDetail: React.FC<CompanyNameDisplayProps> = ({
  companyName,
  isConfirmation,
  onEditAdditionalDetails,
}) => {
  if (!companyName) return null;

  return (
    <Box mb={2}>
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Typography variant="h5">Who pays you</Typography>
        {!isConfirmation && onEditAdditionalDetails && (
          <Link
            sx={{
              display: 'flex',
              flexDirection: 'row',
              gap: 1,
              p: 1,
              alignItems: 'center',
            }}
            onClick={onEditAdditionalDetails}>
            <EditIcon />
            <Typography variant="body2" color="primary.main">
              Edit Switch
            </Typography>
          </Link>
        )}
      </Box>
      <Typography variant="body2">{companyName}</Typography>
    </Box>
  );
};

export default SwitchDetailsDisplay;
