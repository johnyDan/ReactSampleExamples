import React from 'react';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { switchCreationState, currentStepState } from '../../state/atoms';
import { useNavigate } from 'react-router-dom';
import { Box, Grid, Typography } from '@mui/material';
import { performSwitchAction, updateSwitch } from '../../services/methods/switch';
import SwitchDetailsDisplay from './components/switchDetailsDisplay';
import NavigationButtons from '@/components/layout/navigationButtons';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';

const VerifySwitch: React.FC = () => {
  const [switchCreation, setSwitchCreation] = useRecoilState(switchCreationState);
  const setCurrentStep = useSetRecoilState(currentStepState);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();

  const navigate = useNavigate();

  const handleBack = () => {
    setCurrentStep(2);
    navigate('/switch-management/create');
  };

  const handleSubmit = async () => {
    if (switchCreation.switchData) {
      try {
        showLoadingSpinner('Updating Switch');
        const updateResponse = await updateSwitch(switchCreation.switchData.index, switchCreation.switchData, {
          context: 'testing',
        });
        hideLoadingSpinner();

        setSwitchCreation((prev) => ({
          ...prev,
          switchData: updateResponse.data.item,
          switchKind: updateResponse.data.item.state.actions.indexOf('Print') > -1 ? 'PRINT_ONLY' : 'SUBMITTABLE',
        }));

        if (switchCreation.switchKind === 'SUBMITTABLE') {
          showLoadingSpinner('Submitting Switch');
          await performSwitchAction(
            switchCreation.switchData.index,
            { index: switchCreation.switchData.index, action: 'Submit' },
            { context: 'testing' },
            switchCreation.switchData
          );
          hideLoadingSpinner();
        }
        navigate('/switch-management/confirm');
      } catch (error) {
        hideLoadingSpinner(true);
        console.error('Error submitting switch:', error);
      }
    }
  };

  const handleEditAccounts = () => {
    setCurrentStep(1);
    navigate('/switch-management/create');
  };

  const handleEditAdditionalDetails = () => {
    setCurrentStep(2);
    navigate('/switch-management/create');
  };

  const handleSaveAndContinueLater = async () => {
    if (switchCreation.switchData) {
      try {
        showLoadingSpinner('Updating Switch');
        const response = await updateSwitch(switchCreation.switchData.index, switchCreation.switchData, {
          context: 'testing',
        });
        hideLoadingSpinner();
        setSwitchCreation((prev) => ({
          ...prev,
          switchData: response.data.item,
        }));
        navigate('/');
      } catch (error) {
        hideLoadingSpinner(true);
        console.error('Error saving switch:', error);
      }
    }
  };

  if (!switchCreation.switchData) {
    return <div>Loading...</div>;
  }

  const pageTextInfo = {
    title: 'Please verify your direct deposit information below',
    description: 'To proceed, select submit; to make changes, select back or any of edit options provided below.',
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
      <Grid container spacing={4} sx={{ p: { xs: 2, sm: 4 }, justifyContent: 'space-between' }}>
        <Grid item xs={12} md={5} sx={{ display: 'flex', gap: 2, flexDirection: 'column' }}>
          <Typography variant="h2">Setup your direct deposit</Typography>
          <Typography variant="h2">Verify & Submit</Typography>
          <Typography variant="body2">Verify your details and submit your switch request.</Typography>
          <Typography variant="body2">Step 3 of 3</Typography>
        </Grid>
        <Grid item xs={12} md={6} sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <SwitchDetailsDisplay
            pageTextInfo={pageTextInfo}
            switchData={switchCreation.switchData}
            isConfirmation={switchCreation.step === 'confirm'}
            onEditAccounts={handleEditAccounts}
            onEditAdditionalDetails={handleEditAdditionalDetails}
          />
        </Grid>
      </Grid>

      <NavigationButtons
        items={[
          {
            type: 'button',
            label: 'Back',
            onClick: handleBack,
            variant: 'secondary',
            index: 1,
            mobileIndex: 2,
            buttonPosition: 'left',
          },
          {
            type: 'link',
            label: 'Save & Continue Later',
            onClick: handleSaveAndContinueLater,
            index: 2,
            mobileIndex: 3,
            buttonPosition: 'right',
          },
          {
            type: 'button',
            label: 'Submit',
            onClick: handleSubmit,
            variant: 'primary',
            index: 3,
            mobileIndex: 1,
            buttonPosition: 'right',
          },
        ]}
      />
    </Box>
  );
};

export default VerifySwitch;
