import React, { useEffect } from 'react';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { currentStepState, hasExistingSwitchesState, switchCreationState } from '../../state/atoms';
import SwitchDetailsDisplay from './components/switchDetailsDisplay';
import { Box, Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import NavigationButtons from '@/components/layout/navigationButtons';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';
import { performSwitchAction } from '@/services/methods/switch';

const ConfirmSwitch: React.FC = () => {
  const [switchCreation, setSwitchCreation] = useRecoilState(switchCreationState);
  const setHasExistingSwitches = useSetRecoilState(hasExistingSwitchesState);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();
  const [primarySwitchAction, setPrimarySwitchAction] = React.useState<{
    label: string;
    onClick: () => void;
    variant: 'primary' | 'secondary';
  }>({
    label: 'Close',
    onClick: () => {},
    variant: 'secondary',
  });

  const setCurrentStep = useRecoilState(currentStepState)[1];
  const navigate = useNavigate();

  const handleClose = (newSearch?: boolean) => {
    // Reset the Recoil states
    setSwitchCreation({
      switchId: null,
      switchData: null,
      step: 'create',
      isEditing: false,
      workflowEmbedUrl: null,
      error: null,
      switchKind: null,
    });
    setHasExistingSwitches(true);
    setCurrentStep(1);
    navigate(newSearch ? '/company-search' : '/');
  };

  const handlePrint = async () => {
    showLoadingSpinner('Submitting Switch');
    await performSwitchAction(
      switchCreation.switchData.index,
      { index: switchCreation.switchData.index, action: 'Print' },
      { context: 'testing' },
      switchCreation.switchData
    );
    hideLoadingSpinner(true);
    // TODO: Handle the print action
    setPrimarySwitchAction({
      label: 'Close',
      onClick: handleClose,
      variant: 'secondary',
    });
  };

  useEffect(() => {
    setPrimarySwitchAction({
      label: switchCreation.switchKind == 'PRINT_ONLY' ? 'Print' : 'Close',
      onClick: switchCreation.switchKind == 'PRINT_ONLY' ? handlePrint : handleClose,
      variant: switchCreation.switchKind == 'PRINT_ONLY' ? 'primary' : 'secondary',
    });
  }, [switchCreation.switchKind]);

  const switchLayoutInfo = {
    title: 'Setup your direct deposit',
    subtitle:
      switchCreation.switchKind == 'PRINT_ONLY'
        ? 'Deliver your printed Direct Deposit instructions to complete the switch!'
        : "Your direct deposit is on it's way!",
    description:
      switchCreation.switchKind == 'PRINT_ONLY'
        ? 'The provided info can be printed for your records'
        : 'The submitted direct deposit switch details are provided for your records.',
  };

  const pageTextInfo = {
    title: switchCreation.switchKind == 'PRINT_ONLY' ? 'Direct deposit Information' : 'Direct deposit confirmation',
    description:
      switchCreation.switchKind == 'PRINT_ONLY'
        ? 'Please PRINT and take in to your Human Resources department. Log in to your workday intranet account to switch your direct deposit'
        : 'You have successfully updated your direct deposit. You will receive a confirmation email once your information is processed.',
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
      <Grid container spacing={4} sx={{ flexGrow: 1, p: { xs: 2, sm: 4 }, justifyContent: 'space-between' }}>
        <Grid item xs={12} md={5} sx={{ display: 'flex', gap: 2, flexDirection: 'column' }}>
          <Typography variant="h2">{switchLayoutInfo.title}</Typography>
          <Typography variant="h4">{switchLayoutInfo.subtitle}</Typography>
          <Typography variant="body2">{switchLayoutInfo.description}</Typography>
          <Box sx={{ mt: 2, flexGrow: 1, overflow: 'auto' }}></Box>
        </Grid>
        <Grid item xs={12} md={6} sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <SwitchDetailsDisplay
            pageTextInfo={pageTextInfo}
            switchData={switchCreation.switchData}
            isConfirmation={true}
          />
        </Grid>
      </Grid>

      <NavigationButtons
        items={[
          {
            type: 'button',
            label: primarySwitchAction.label,
            onClick: primarySwitchAction.onClick,
            variant: primarySwitchAction.variant,
            index: 1,
            mobileIndex: 1,
            icon: <></>,
            buttonPosition: 'right',
          },
          {
            type: 'link',
            label: 'Add another Direct Deposit',
            onClick: () => handleClose(true),
            index: 2,
            mobileIndex: 2,
            buttonPosition: 'right',
          },
        ]}
      />
    </Box>
  );
};

export default ConfirmSwitch;
