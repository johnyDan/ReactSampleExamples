export interface FieldConfig {
  label: string;
  inputType: string;
  validations?: any;
  options?: any[];
  fields?: { [key: string]: FieldConfig };
}

export interface FormConfig {
  fields: { [key: string]: FieldConfig };
}

export interface Overrides {
  [key: string]: {
    label?: string;
    inputType?: string;
    validations?: any;
    options?: any[];
  };
}

export const convertApiResponseToFormConfig = (apiResponse: any, overrides: Overrides = {}): FormConfig => {
  const formConfig: FormConfig = { fields: {} };

  // Process ux.fields
  apiResponse.ux.fields.forEach((field: any) => {
    formConfig.fields[field.key] = convertField(field, apiResponse.state.validation.fields, overrides);
  });

  // Process accounts if limit > 0
  if (apiResponse.ux.accounts.limit > 0) {
    formConfig.fields['accounts'] = convertAccounts(apiResponse, overrides);
  }

  return formConfig;
};

const convertField = (field: any, validationMessages: any, overrides: Overrides): FieldConfig => {
  let fieldConfig: FieldConfig = {
    label: field.label,
    inputType: field.label.toLowerCase().indexOf('date') !== -1 ? 'date' : mapFieldType(field.type),
    validations: {},
  };

  // Handle required validation
  if (field.required) {
    fieldConfig.validations.required = validationMessages[field.key] || 'This field is required';
  }

  // Handle regex validation
  if (field.regex) {
    fieldConfig.validations.pattern = {
      value: new RegExp(unescapeRegex(field.regex)),
      message: field.validationMessage || 'Invalid format',
    };
  }

  // Handle options from 'selections' or 'choices'
  if (field.selections) {
    fieldConfig.options = field.selections.map((selection: any) => ({
      value: selection.key,
      label: selection.label,
    }));
  } else if (field.choices) {
    fieldConfig.options = field.choices.map((choice: any) => ({
      value: choice.index.toString(),
      label: choice.label,
    }));
  }

  // Handle composite fields
  if (field.type === 'composite') {
    fieldConfig.fields = {};
    field.fields.forEach((subField: any) => {
      fieldConfig.fields![subField.key] = convertField(subField, validationMessages, overrides);
    });
  }

  // Apply overrides if present
  if (overrides && overrides[field.key]) {
    const override = overrides[field.key];

    // Override label and inputType
    if (override.label) {
      fieldConfig.label = override.label;
    }
    if (override.inputType) {
      fieldConfig.inputType = override.inputType;
    }

    // Override options if provided
    if (override.options) {
      fieldConfig.options = override.options;
    }

    // Merge validations
    if (override.validations) {
      fieldConfig.validations = {
        ...fieldConfig.validations,
        ...override.validations,
      };
    }
  }

  return fieldConfig;
};

const convertAccounts = (apiResponse: any, overrides: Overrides): FieldConfig => {
  const accountsConfig: FieldConfig = {
    label: 'Accounts',
    inputType: 'array',
    validations: {
      validate: (value: any) => {
        if (value && value.length > 0) {
          return true;
        }
        return apiResponse.state.validation.overall[0] || 'At least one account must be selected';
      },
    },
    fields: {
      index: {
        label: 'Account',
        inputType: 'select',
        options: apiResponse.ux.accounts.choices.map((choice: any) => ({
          value: choice.index.toString(), // Ensure value is a string
          label: choice.label,
        })),
        validations: {
          required: 'Please select an account',
        },
      },
    },
  };

  // Process accounts fields if they exist
  if (apiResponse.ux.accounts.fields && apiResponse.ux.accounts.fields.length > 0) {
    apiResponse.ux.accounts.fields.forEach((field: any) => {
      const fieldConfig = convertField(field, {}, overrides);
      accountsConfig.fields![field.key] = fieldConfig;
    });
  }

  return accountsConfig;
};

const mapFieldType = (type: string): string => {
  switch (type) {
    case 'textbox':
      return 'text';
    case 'select':
      return 'select';
    case 'composite':
      return 'composite';
    case 'checkbox':
      return 'checkbox';
    default:
      return 'text';
  }
};

const unescapeRegex = (regexStr: string): string => {
  return regexStr.replace(/\\\\/g, '\\');
};
