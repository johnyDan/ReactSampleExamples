import { sanitizeUrl } from '@/utils/sanitizeUtils';
import { switchConfigOverrides } from '@/config/app/switch-config-overrides';
import { convertApiResponseToFormConfig, FormConfig } from './convertApiResponseToFormConfig';
import { createSwitch, getSwitch } from '@/services/methods/switch';

export const processSwitchResponse = (
  responseData: any,
  setSwitchCreation: React.Dispatch<React.SetStateAction<any>>,
  methods: any,
  setFormConfig: React.Dispatch<React.SetStateAction<FormConfig | null>>
) => {
  if (responseData.workflowEmbedUrl) {
    // Handle workflowEmbedUrl
    setSwitchCreation((prev: any) => ({
      ...prev,
      switchData: responseData,
      workflowEmbedUrl: sanitizeUrl(responseData.workflowEmbedUrl),
    }));
  } else if (
    responseData.ux &&
    responseData.ux.fields &&
    responseData.ux.fields.some((field: any) => field.type === 'html')
  ) {
    // Handle HTML content
    setSwitchCreation((prev: any) => ({
      ...prev,
      switchData: responseData,
    }));
  } else if (responseData.ux && responseData.ux.accounts) {
    // Proceed with form configuration
    setSwitchCreation((prev: any) => ({
      ...prev,
      switchId: responseData.index,
      switchData: responseData,
      step: prev.step || 'create',
    }));
    const config = convertApiResponseToFormConfig(responseData, switchConfigOverrides);
    setFormConfig(config);
    // Set default values, ensuring accounts have at least one entry
    const defaultValues = {
      ...responseData.values,
      accounts:
        responseData.values.accounts && responseData.values.accounts.length > 0
          ? responseData.values.accounts
          : [{ index: '', fields: {} }],
    };
    methods.reset(defaultValues);
  } else {
    // Handle case where neither workflowEmbedUrl nor ux.accounts is present
    setSwitchCreation((prev: any) => ({
      ...prev,
      switchData: responseData,
    }));
  }
};

export const fetchSwitchDataForEditMode = async (
  switchCreation: any,
  setSwitchCreation: React.Dispatch<React.SetStateAction<any>>,
  methods: any,
  setFormConfig: React.Dispatch<React.SetStateAction<FormConfig | null>>,
  showLoadingSpinner: (message: string) => void,
  hideLoadingSpinner: (error?: boolean) => void
) => {
  try {
    let responseData: any = {};
    if (switchCreation.switchData && switchCreation.switchData.values) {
      responseData = switchCreation.switchData;
    } else {
      showLoadingSpinner('Fetching existing switch');
      const response: any = await getSwitch(switchCreation.switchId, {});
      responseData = response.data.item;
      hideLoadingSpinner(true);
    }

    processSwitchResponse(responseData, setSwitchCreation, methods, setFormConfig);
  } catch (error) {
    hideLoadingSpinner(true);
    console.error('Error fetching switch:', error);
    setSwitchCreation((prev: any) => ({
      ...prev,
      error: 'Failed to fetch switch data. Please try again.',
    }));
  }
};

export const fetchSwitchDataForCreateMode = async (
  selectedCompany: any,
  setSwitchCreation: React.Dispatch<React.SetStateAction<any>>,
  methods: any,
  setFormConfig: React.Dispatch<React.SetStateAction<FormConfig | null>>,
  showLoadingSpinner: (message: string) => void,
  hideLoadingSpinner: (error?: boolean) => void
) => {
  try {
    showLoadingSpinner('Creating Switch');
    const requestData: any = {
      type: 'deposit',
      accountHolderIndex: '0',
    };
    if (selectedCompany.targetId) {
      requestData.targetId = selectedCompany.targetId;
    } else if (selectedCompany.locationId) {
      requestData.locationId = selectedCompany.locationId;
    } else if (selectedCompany.manualSetup) {
      requestData.targetName = selectedCompany.name || 'Manual Deposit Setup';
    }
    const response: any = await createSwitch(requestData);
    hideLoadingSpinner(true);

    const responseData = response.data.item;

    processSwitchResponse(responseData, setSwitchCreation, methods, setFormConfig);
  } catch (error) {
    hideLoadingSpinner(true);
    console.error('Error creating switch:', error);
    setSwitchCreation((prev: any) => ({
      ...prev,
      error: 'Failed to create switch. Please try again.',
    }));
  }
};

export const getHtmlField = (switchData: any) => {
  if (switchData && switchData.ux && switchData.ux.fields && switchData.ux.fields.length > 0) {
    return switchData.ux.fields.find((field: any) => field.type === 'html');
  }
  return null;
};
