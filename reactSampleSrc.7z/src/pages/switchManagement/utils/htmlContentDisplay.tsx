import React from 'react';
import parse, { domToReact, HTMLReactParserOptions, DOMNode, Element } from 'html-react-parser';
import { Typography, Link as MuiLink } from '@mui/material';
import DOMPurify from 'dompurify';

const isElement = (domNode: DOMNode): domNode is Element => {
  const isTag = domNode.type === 'tag' || domNode.type === 'script' || domNode.type === 'style';
  const hasAttributes = (domNode as Element).attribs !== undefined;

  return isTag && hasAttributes;
};

const HtmlContentDisplay: React.FC<{ htmlString: string }> = ({ htmlString }) => {
  const sanitizedHtmlString = DOMPurify.sanitize(htmlString);

  const options: HTMLReactParserOptions = {
    replace: (domNode) => {
      if (isElement(domNode)) {
        const { name, attribs, children } = domNode;

        switch (name) {
          case 'p':
            return (
              <Typography variant="body2" paragraph>
                {domToReact(children as DOMNode[], options)}
              </Typography>
            );
          case 'a':
            return (
              <MuiLink href={attribs.href || '#'} target="_blank" rel="noopener noreferrer" underline="always">
                {domToReact(children as DOMNode[], options)}
              </MuiLink>
            );
          case 'strong':
            return (
              <Typography component="span" variant="body2" fontWeight="bold">
                {domToReact(children as DOMNode[], options)}
              </Typography>
            );
          case 'em':
            return (
              <Typography component="span" variant="body2" fontStyle="italic">
                {domToReact(children as DOMNode[], options)}
              </Typography>
            );
          case 'br':
            return <br />;
          default:
            return domNode; // Render other tags as is : Todo : verify once
        }
      }
      return domNode; // Return other nodes without modification
    },
  };

  return <>{parse(sanitizedHtmlString, options)}</>;
};

export default HtmlContentDisplay;
