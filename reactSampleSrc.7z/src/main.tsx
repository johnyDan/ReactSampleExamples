import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/index.css';
import { RecoilRoot } from 'recoil';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import App from './App';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import getTheme from './styles/themeSelector';
import { MessageProvider } from './utils/messageContext';

const theme = getTheme();

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <RecoilRoot>
      <ThemeProvider theme={theme}>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <CssBaseline />
          <MessageProvider>
            <App />
          </MessageProvider>
        </LocalizationProvider>
      </ThemeProvider>
    </RecoilRoot>
  </React.StrictMode>
);
