import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Layout from '@/components/layout/layout.tsx';
import CompanySearch from '@/pages/companySearch/companySearch.tsx';
import ConfirmSwitch from './pages/switchManagement/confirmSwitch';
import CreateSwitch from './pages/switchManagement/createSwitch';
import VerifySwitch from './pages/switchManagement/verifySwitch';
import SwitchDashboard from './pages/switchDashboard/switchDashboard';
import LoadingSpinner from './components/common/loadingSpinner';
import { InitialDataLoad } from './pages/initialDataHandler/initialDataLoad';
import { apiContext } from './services/apiContext';

function App() {
  apiContext.setCustomerKey('11223301');
  return (
    <Router>
      <Layout>
        {/* <InitialDataLoad> */}
        <Routes>
          <Route path="/" element={<SwitchDashboard />} />
          <Route path="/company-search" element={<CompanySearch />} />
          <Route path="/switch-management/create" element={<CreateSwitch />} />
          <Route path="/switch-management/verify" element={<VerifySwitch />} />
          <Route path="/switch-management/confirm" element={<ConfirmSwitch />} />
        </Routes>
        {/* </InitialDataLoad> */}
      </Layout>
      <LoadingSpinner />
    </Router>
  );
}

export default App;
