interface ImportMetaEnv {
  VITE_REACT_APP_CLICKSWITCH_API_KEY: string;
  VITE_MOCK_API_MODE: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
