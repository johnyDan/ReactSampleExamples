export interface Overrides {
  [key: string]: {
    label?: string;
    inputType?: string;
    validations?: any;
    options?: any[];
  };
}

export const switchConfigOverrides: Overrides = {
  Custom_SSN4: {
    label: 'SSN (Last 4 Digits)',
    validations: {
      pattern: {
        value: /^\d{4}$/,
        message: 'SSN must be 4 digits',
      },
    },
  },
  'Custom_Last 4 of SSN': {
    label: 'Last 4 of SSN',
    validations: {
      pattern: {
        value: /^\d{4}$/,
        message: 'SSN must be 4 digits',
      },
    },
  },
  customOption: {
    label: 'Amount Type',
    inputType: 'radio',
    validations: {
      required: 'Please select an amount type',
    },
  },
  'Custom_Amount (in dollars)': {
    label: 'Fixed Amount',
    validations: {
      required: 'Please enter the amount',
      pattern: {
        value: /^\d+(\.\d{1,2})?$/,
        message: 'Must be a valid amount with up to two decimal places',
      },
    },
  },
  'Custom_or Percentage of Pay (1 - 100)': {
    label: 'Percentage of Pay',
    validations: {
      required: 'Please enter the percentage',
      pattern: {
        value: /^(100|[1-9]?\d)$/,
        message: 'Must be a number between 1 and 100',
      },
    },
  },
  splitType: {
    inputType: 'select',
    label: 'Split Type',
    validations: {
      required: 'Please select a Split Type',
    },
  },
  splitAmount: {
    label: 'Amount',
    validations: {
      pattern: {
        value: /^\d+(\.\d{1,2})?$/,
        message: 'Must be a valid amount with up to two decimal places',
      },
    },
  },
};
