interface Window {
  initialUserData?: any;
  brandTheme?: string;
}
