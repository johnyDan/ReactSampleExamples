export const formatCurrency = (amount: any) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

export const validateAndFormatDate = (dateString: string): string | null => {
  const date = new Date(dateString);

  // Check if the date is valid
  if (isNaN(date.getTime())) {
    return 'Invalid date';
  }

  // Extract month, day, and year
  const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based, Todo: verify this later
  const day = date.getDate().toString().padStart(2, '0');
  const year = date.getFullYear();

  // Format to "MM-DD-YYYY", Todo: verify this later
  return `${month}-${day}-${year}`;
};
