import DOMPurify from 'dompurify';

export const sanitizeUrl = (url: string): string => {
  try {
    new URL(url);
    return DOMPurify.sanitize(url, {
      ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp|xxx):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
    });
  } catch (_) {
    console.error('Invalid URL:', url);
    return '';
  }
};

export const sanitizeHtml = (html: string): string => {
  return DOMPurify.sanitize(html);
};
