import { Button, ButtonGroup } from '@mui/material';
import { useMessages } from './messageContext';

const LanguageSwitcher = () => {
  const { language, changeLanguage } = useMessages();

  return (
    <ButtonGroup variant="contained" aria-label="language switcher">
      <Button onClick={() => changeLanguage('en')} color={language === 'en' ? 'primary' : 'secondary'}>
        English
      </Button>
      <Button onClick={() => changeLanguage('es')} color={language === 'es' ? 'primary' : 'secondary'}>
        Español
      </Button>
    </ButtonGroup>
  );
};

export default LanguageSwitcher;
