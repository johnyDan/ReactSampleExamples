import { Paper, Box, Typography } from '@mui/material';
import InfoIcon from '@mui/icons-material/InfoOutlined';
import { SxProps, Theme } from '@mui/material/styles';

interface InstructionsBoxProps {
  text: string;
  backgroundColor?: string;
  paperSx?: SxProps<Theme>;
  iconColor?: string;
}

const InstructionsBox = ({
  text,
  backgroundColor = '#e0f7fa',
  paperSx,
  iconColor = 'primary.main',
}: InstructionsBoxProps) => {
  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor,
        padding: 2,
        display: 'flex',
        alignItems: 'flex-start',
        borderLeft: (theme) => `6px solid ${theme.palette.primary.main}`,
        maxWidth: '500px',
        ...paperSx,
      }}>
      <InfoIcon
        sx={{
          color: iconColor,
          marginRight: 2,
          marginTop: 0.5,
        }}
      />
      <Box>
        <Typography variant="body2" color="primary.main" gutterBottom>
          {text}
        </Typography>
      </Box>
    </Paper>
  );
};

export default InstructionsBox;
