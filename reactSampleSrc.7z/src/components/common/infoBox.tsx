import { Paper, Box, Typography } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';

interface InfoBoxProps {
  title: string;
  bodyText: string[];
  backgroundColor?: string;
  paperSx?: object;
  iconColor?: string;
  maxWidth?: string | number;
}

const InfoBox = ({
  title,
  bodyText,
  backgroundColor = '#e0f7fa',
  paperSx,
  iconColor = 'primary.main',
  maxWidth = '400px',
}: InfoBoxProps) => {
  return (
    <Paper
      elevation={0}
      sx={(theme) => ({
        backgroundColor,
        padding: 2,
        display: 'flex',
        alignItems: 'flex-start',
        maxWidth,
        borderLeft: `6px solid ${theme.palette.primary.main}`,
        ...paperSx,
      })}>
      <InfoIcon
        sx={{
          color: iconColor,
          marginRight: 2,
          marginTop: 0.5,
        }}
      />
      <Box>
        <Typography variant="h4" color="primary.main" gutterBottom>
          {title}
        </Typography>
        {bodyText.map((text, index) => (
          <Typography key={index} variant="body2" color="primary.main" gutterBottom>
            {text}
          </Typography>
        ))}
      </Box>
    </Paper>
  );
};

export default InfoBox;
