import React from 'react';
import { useRecoilValue } from 'recoil';
import { Backdrop, CircularProgress, Typography } from '@mui/material';
import { loadingCountState } from '@/state/atoms';

const LoadingSpinner: React.FC = () => {
  const { count, message } = useRecoilValue(loadingCountState);
  const loading = count > 0;

  return (
    <Backdrop
      aria-labelledby="loading-spinner"
      aria-describedby="loading-content"
      open={loading}
      sx={(theme) => ({
        color: '#fff',
        zIndex: theme.zIndex.modal + 1,
        transition: 'opacity 0.3s ease-in-out',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
      })}>
      <CircularProgress
        size={60}
        thickness={4}
        color="inherit"
        sx={{
          mb: 3,
        }}
      />
      <Typography variant="h4" gutterBottom color="white">
        Loading, please wait...
      </Typography>
      <Typography variant="h4" color="white">
        {message}
      </Typography>
    </Backdrop>
  );
};

export default LoadingSpinner;
