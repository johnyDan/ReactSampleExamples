import React from 'react';
import { Grid, Typography } from '@mui/material';

const Header: React.FC = () => {
  return (
    <Grid
      item
      xs={12}
      sx={{
        bgcolor: 'custom.uiElements',
        color: 'white',
        maxHeight: '50px',
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      }}>
      <Typography variant="h6" sx={{ p: 1, fontSize: { xs: '1rem', sm: '1.25rem' } }}>
        Direct Deposit
      </Typography>
    </Grid>
  );
};

export default Header;
