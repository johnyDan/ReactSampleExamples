import { atom } from 'recoil';

type SwitchCreationState = {
  switchId?: number | null;
  step?: string;
  switchData: any | null;
  isEditing?: boolean;
  workflowEmbedUrl?: string | null;
  error?: string | null;
  switchKind?: 'PRINT_ONLY' | 'SUBMITTABLE' | 'ONLINE_ONLY' | 'INSTANT' | null;
};

type SelectedCompanyState = {
  name: string;
  targetId?: number | null;
  locationId?: string | null;
  manualSetup?: boolean;
};

export const loadingCountState = atom({
  key: 'loadingCountState',
  default: {
    count: 0,
    message: '',
  },
});

export const userState = atom<any>({
  key: 'userState',
  default: {},
});

export const switchStatusesState = atom({
  key: 'switchStatusesState',
  default: [],
});

export const switchActionsState = atom({
  key: 'switchActionsState',
  default: [],
});

export const selectedCompanyState = atom<SelectedCompanyState>({
  key: 'selectedCompanyState',
  default: {
    name: '',
    targetId: null,
    locationId: null,
    manualSetup: false,
  },
});

export const switchCreationState = atom<SwitchCreationState>({
  key: 'switchCreationState',
  default: {
    switchId: null,
    step: 'create',
    switchData: null,
    isEditing: false,
    error: null,
    workflowEmbedUrl: null,
    switchKind: null,
  },
});

export const currentStepState = atom<number>({
  key: 'currentStepState',
  default: 1,
});

export const hasExistingSwitchesState = atom({
  key: 'hasExistingSwitchesState',
  default: false,
});
