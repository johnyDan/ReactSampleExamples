module.exports = {
  singleQuote: true,
  jsxSingleQuote: false,
  bracketSameLine: true,
  printWidth: 120,
  singleAttributePerLine : true,
  endOfLine: 'auto',
};