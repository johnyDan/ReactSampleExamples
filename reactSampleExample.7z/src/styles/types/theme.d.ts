import '@mui/material/styles';

declare module '@mui/material/styles' {
  interface TypographyVariants {
    body3: React.CSSProperties;
  }

  interface TypographyVariantsOptions {
    body3?: React.CSSProperties;
  }

  interface Palette {
    custom: {
      headingsUI: string;
      uiElements: string;
      outline: string;
      contentBackground: string;
      primaryButtonUI: string;
      primaryButtonHover: string;
      secondaryButtonUI: string;
      secondaryButtonHover: string;
      secondaryButtonBorder: string;
      paragraphText: string;
      disabled: string;
      disabledText: string;
      highlightTextUI: string;
      formModuleUI: string;
      selectedElements: string;
      links: string;
      followedLinks: string;
      uiAccent: string;
      surface: string;
      surfaceContrastText: string;
    };
  }

  interface PaletteOptions {
    custom?: {
      headingsUI?: string;
      uiElements?: string;
      outline?: string;
      contentBackground?: string;
      primaryButtonUI?: string;
      primaryButtonHover?: string;
      secondaryButtonUI?: string;
      secondaryButtonHover?: string;
      secondaryButtonBorder?: string;
      paragraphText?: string;
      disabled?: string;
      disabledText?: string;
      highlightTextUI?: string;
      formModuleUI?: string;
      selectedElements?: string;
      links?: string;
      followedLinks?: string;
      uiAccent?: string;
      surface?: string;
      surfaceContrastText?: string;
    };
  }
}

declare module '@mui/material/Typography' {
  interface TypographyPropsVariantOverrides {
    body3: true;
  }
}
