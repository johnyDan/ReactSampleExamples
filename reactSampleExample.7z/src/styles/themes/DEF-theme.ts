import { createTheme } from '@mui/material/styles';

const DEFTheme = createTheme({
  typography: {
    fontFamily: '"Open Sans", sans-serif',
    h1: {
      fontWeight: 700,
      fontSize: '30px',
      lineHeight: '38px',
      color: '#153145',
    },
    h2: {
      fontWeight: 700,
      fontSize: '22px',
      lineHeight: '28px',
      color: '#153145',
    },
    h3: {
      fontWeight: 700,
      fontSize: '22px',
      lineHeight: '28px',
      color: '#006BA6',
    },
    h4: {
      fontWeight: 700,
      fontSize: '18px',
      lineHeight: '28px',
      color: '#153145',
    },
    h5: {
      fontWeight: 700,
      fontSize: '16px',
      lineHeight: '24px',
      color: '#153145',
    },
    h6: {
      fontWeight: 700,
      fontSize: '14px',
      lineHeight: '22px',
      color: '#6A6F81',
    },
    body1: {
      fontWeight: 400,
      fontSize: '16px',
      lineHeight: '24px',
      color: '#153145',
    },
    body2: {
      fontWeight: 700,
      fontSize: '16px',
      lineHeight: '24px',
      color: '#153145',
    },
    body3: {
      fontWeight: 400,
      fontSize: '14px',
      lineHeight: '22px',
      color: '#153145',
    },
  },
  palette: {
    primary: {
      main: '#153145',
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#007255',
      contrastText: '#FFFFFF',
    },
    error: {
      main: '#D8000C',
      contrastText: '#FFFFFF',
    },
    warning: {
      main: '#D29F13',
      contrastText: '#FFFFFF',
    },
    info: {
      main: '#006BA6',
      contrastText: '#FFFFFF',
    },
    success: {
      main: '#007255',
      contrastText: '#FFFFFF',
    },
    text: {
      primary: '#153145',
      secondary: '#6A6F81',
    },
    background: {
      default: '#F5F5F5',
      paper: '#FFFFFF',
    },
    custom: {
      headingsUI: '#153145',
      highlightTextUI: '#006BA6',
      contentBackground: '#D8E5EA',
      primaryButtonUI: '#F8DF8E',
      primaryButtonHover: '#EACD70',
      secondaryButtonUI: '#FFFFFF',
      secondaryButtonHover: '#F0F0F0',
      secondaryButtonBorder: '#153145',
      paragraphText: '#6A6F81',
      formModuleUI: '#D5D5D5',
      selectedElements: '#007255',
      links: '#007255',
      followedLinks: '#008b68',
      uiAccent: '#D29F13',
      surface: '#FFFFFF',
      surfaceContrastText: '#1C3145',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          fontFamily: '"Open Sans", sans-serif',
          fontWeight: 700,
          fontSize: '16px',
          borderRadius: '4px',
          textTransform: 'none',
          padding: '16px 24px',
          '&.MuiButton-sizeMedium': {
            height: '56px',
          },
          '@media (max-width: 768px)': {
            height: '48px',
            width: '100%',
          },
        },
        containedPrimary: {
          backgroundColor: '#F8DF8E',
          color: '#153145',
          '&:hover': {
            backgroundColor: '#EACD70',
          },
        },
      },
    },
    MuiLink: {
      styleOverrides: {
        root: {
          color: '#007255',
          '&:visited': {
            color: '#008b68',
          },
        },
      },
    },
  },
});

export default DEFTheme;
