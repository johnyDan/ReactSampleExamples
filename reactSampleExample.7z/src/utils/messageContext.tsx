import React, { createContext, useState, useContext, ReactNode } from 'react';
import enMessages from '../config/messages/messages.en';
import esMessages from '../config/messages/messages.es';

type Messages = typeof enMessages;

interface MessageContextType {
  messages: Messages;
  language: 'en' | 'es';
  setLanguage: (lang: 'en' | 'es') => void;
  changeLanguage: (lang: 'en' | 'es') => void;
}

export const MessageContext = createContext<MessageContextType | undefined>(undefined);

export const MessageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Messages>(enMessages);

  const changeLanguage = (lang: 'en' | 'es') => {
    setLanguage(lang);
    document.documentElement.lang = lang;
  };

  const setLanguage = (lang: 'en' | 'es') => {
    setMessages(lang === 'en' ? enMessages : esMessages);
  };

  return (
    <MessageContext.Provider value={{ messages, setLanguage, changeLanguage }}>{children}</MessageContext.Provider>
  );
};

export const useMessages = () => {
  const context = useContext(MessageContext);
  if (context === undefined) {
    throw new Error('useMessages must be used within a MessageProvider');
  }
  return context;
};
