import { useSetRecoilState } from 'recoil';
import { loadingCountState } from '../state/atoms';

export const useLoadingSpinner = () => {
  const setLoadingState = useSetRecoilState(loadingCountState);

  const showLoadingSpinner = (message?: string) => {
    setLoadingState((prev) => ({
      count: prev.count + 1,
      message: message || prev.message || '',
    }));
  };

  const hideLoadingSpinner = (All?: boolean) => {
    setLoadingState((prev) => {
      const newCount = All ? 0 : Math.max(prev.count - 1, 0);
      const newMessage = newCount === 0 ? '' : prev.message;
      return {
        count: newCount,
        message: newMessage,
      };
    });
  };

  return { showLoadingSpinner, hideLoadingSpinner };
};
