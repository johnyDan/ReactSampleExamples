import dayjs, { Dayjs, ManipulateType } from 'dayjs';
import { FieldConfig } from '../types/formsConfigTypes';

const isWeekEnd = (date: Dayjs): boolean => {
  const day = date.day();
  return day === 0 || day === 6;
};

const isPublicHoliday = (date: Dayjs, holidays: string[]): boolean => {
  return holidays.some((holiday) => date.isSame(dayjs(holiday), 'day'));
};

const isSameOrAfter = (date1: Dayjs, date2: Dayjs) => {
  return date1.isSame(date2) || date1.isAfter(date2);
};

const isSameOrBefore = (date1: Dayjs, date2: Dayjs) => {
  return date1.isSame(date2) || date1.isBefore(date2);
};

const parseDateValue = (dateConfig: any): Dayjs => {
  let date = dayjs();

  if (typeof dateConfig === 'string') {
    date = dayjs(dateConfig);
  } else if (typeof dateConfig === 'object') {
    if (dateConfig.add) {
      const units = dateConfig.add;
      for (const unit in units) {
        date = date.add(units[unit], unit as ManipulateType);
      }
    }
    if (dateConfig.subtract) {
      const units = dateConfig.subtract;
      for (const unit in units) {
        date = date.subtract(units[unit], unit as ManipulateType);
      }
    }
  }

  return date;
};

const createDisableDateFunction = (conditions: string[], fieldConfig: FieldConfig): ((date: Dayjs) => boolean) => {
  const holidays = fieldConfig.additionalProps?.holidays || [];
  return (date: Dayjs) => {
    return conditions.some((conditionName) => {
      switch (conditionName) {
        case 'isWeekend':
          return isWeekEnd(date);
        case 'isPublicHoliday':
          return isPublicHoliday(date, holidays);
        default:
          return false;
      }
    });
  };
};

export { isWeekEnd, isPublicHoliday, createDisableDateFunction, parseDateValue, isSameOrAfter, isSameOrBefore };
