import React from 'react';
import { DatePicker, DatePickerProps } from '@mui/x-date-pickers/DatePicker';
import { Dayjs } from 'dayjs';
import { styled } from '@mui/material/styles';
import { PickersActionBarAction, pickersLayoutClasses } from '@mui/x-date-pickers';
import { Box, Typography } from '@mui/material';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

interface CustomDatePickerProps extends Omit<DatePickerProps<Dayjs>, 'actions' | 'slotProps'> {
  name: string;
  value: Dayjs | null;
  onChange: (date: Dayjs | null) => void;
  label?: string;
  actions?: Array<PickersActionBarAction>;
  error?: boolean;
  helperText?: string;
  errorMessage?: string;
}

const StyledDatePicker = styled(DatePicker)<{ error?: boolean }>(({ theme, error }) => ({
  '& .MuiInputBase-root': {
    fontFamily: theme.typography.fontFamily,
    fontSize: '18px',
    fontWeight: 600,
    color: theme.palette.custom.paragraphText,
  },
  '& .MuiInputLabel-root': {
    fontFamily: theme.typography.fontFamily,
    fontSize: '16px',
    fontWeight: 600,
    color: error ? theme.palette.error.main : theme.palette.primary.main,
    '&.MuiInputLabel-shrink': {
      transform: 'translate(14px, -9px) scale(0.75)',
      maxWidth: 'calc(133% - 30px)',
      textTransform: 'uppercase',
      fontWeight: 600,
      fontSize: 'calc(133% - 2px)',
      letterSpacing: '0.1em',
      backgroundColor: 'white',
      color: error ? theme.palette.error.main : theme.palette.custom.paragraphText,
    },
  },
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: theme.palette.custom.outline,
    borderWidth: '2px',
    borderRadius: '8px',
  },
  '& .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline': {
    borderColor: theme.palette.custom.outline,
  },
  '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
    borderColor: theme.palette.custom.outline,
    borderWidth: '2px',
  },
}));

const CustomDatePicker: React.FC<CustomDatePickerProps> = ({
  name,
  value,
  onChange,
  label = 'Date',
  actions = [],
  error = false,
  helperText,
  errorMessage,
  ...props
}) => {
  return (
    <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <StyledDatePicker
        label={label}
        value={value}
        onChange={onChange}
        error={error}
        slotProps={{
          textField: {
            name,
            error,
            helperText,
          },
          actionBar: {
            actions: [...actions],
          },
          layout: {
            sx: {
              [`.${pickersLayoutClasses.contentWrapper}`]: {
                maxHeight: '285px',
              },
              [`.${pickersLayoutClasses.actionBar}`]: {
                justifyContent: 'space-between',
              },
            },
          },
        }}
        {...props}
      />
      {error && errorMessage && (
        <Typography
          color="error"
          sx={{ gap: 0, fontSize: '16px', fontWeight: 600, display: 'flex', alignItems: 'center' }}>
          <HighlightOffIcon style={{ marginRight: '4px', fontSize: 16 }} />
          {errorMessage}
        </Typography>
      )}
    </Box>
  );
};

export default CustomDatePicker;
