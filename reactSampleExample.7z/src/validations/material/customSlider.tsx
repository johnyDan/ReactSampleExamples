import React from 'react';
import { Slider, styled } from '@mui/material';

const StyledSlider = styled(Slider)(({ theme }) => ({
  '& .MuiSlider-thumb': {
    height: 24,
    width: 24,
    backgroundColor: theme.palette.custom.selectedElements,
    '&:focus, &:hover, &.Mui-active, &.Mui-focusVisible': {
      boxShadow: 'inherit',
    },
  },
  '& .MuiSlider-track': {
    height: 4,
    backgroundColor: theme.palette.custom.selectedElements,
  },
  '& .MuiSlider-rail': {
    height: 4,
    opacity: 0.5,
    backgroundColor: theme.palette.custom.paragraphText,
  },
  '& .MuiSlider-mark': {
    backgroundColor: '#bfbfbf',
    height: 30,
    width: 1,
    '&.MuiSlider-markActive': {
      opacity: 1,
      backgroundColor: '#bfbfbf',
    },
  },
}));

interface Mark {
  value: number;
  label: string;
}

interface CustomSliderProps {
  value: number;
  onChange: (event: Event, newValue: number | number[]) => void;
  min?: number;
  max?: number;
  step?: number;
  marks?: Mark[];
}

const CustomSlider: React.FC<CustomSliderProps> = ({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  marks = [
    { value: 0, label: '' },
    { value: 33, label: '' },
    { value: 66, label: '' },
    { value: 100, label: '' },
  ],
}) => {
  return (
    <StyledSlider
      aria-label="Custom slider"
      value={value}
      onChange={onChange}
      min={min}
      max={max}
      step={step}
      marks={marks}
    />
  );
};

export default CustomSlider;
