import React from 'react';
import { Checkbox, CheckboxProps, FormControlLabel, Typography, Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import CustomCheckboxIcon from '../../styles/icons/customCheckboxIcon';

interface CustomCheckboxProps extends CheckboxProps {
  label: string;
  subLabel?: string;
}

const StyledFormControlLabel = styled(FormControlLabel)<{ disabled?: boolean }>(() => ({
  margin: 0,
  alignItems: 'flex-start',
}));

const LabelContainer = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
});

const LabelText = styled(Typography)<{ disabled?: boolean }>(({ theme, disabled }) => ({
  fontFamily: theme.typography.fontFamily,
  fontWeight: 600,
  fontSize: '18px',
  color: disabled ? theme.palette.custom.disabled : theme.palette.primary.main,
  lineHeight: '24px',
}));

const SubLabel = styled(Typography)<{ disabled?: boolean }>(({ theme, disabled }) => ({
  fontFamily: theme.typography.fontFamily,
  fontWeight: 400,
  fontSize: '16px',
  color: disabled ? theme.palette.custom.disabled : theme.palette.custom.paragraphText,
  // marginTop: '4px',
  lineHeight: '20px',
}));

const StyledCheckbox = styled(Checkbox)(() => ({
  '&.MuiCheckbox-root': {
    padding: 0,
    marginRight: '8px',
    width: '24px',
    height: '24px',
  },
  '& .MuiSvgIcon-root': {
    fontSize: 24,
    borderRadius: '8px',
  },
  '&:not(.Mui-checked):not(.Mui-disabled) .MuiSvgIcon-root': {
    color: '#FFFFFF',
    border: '2px solid #D5D5D5',
  },
  '&.Mui-checked:not(.Mui-disabled) .MuiSvgIcon-root': {
    color: '#FFFFFF',
    border: '2px solid #00505C',
  },
  '&.Mui-disabled:not(.Mui-checked) .MuiSvgIcon-root': {
    color: '#F5F5F5',
    border: '2px solid #D5D5D5',
  },
  '&.Mui-disabled.Mui-checked .MuiSvgIcon-root': {
    color: '#F5F5F5',
    border: '2px solid #D5D5D5',
  },
}));

const CustomCheckbox: React.FC<CustomCheckboxProps> = ({ label, subLabel, ...props }) => {
  return (
    <StyledFormControlLabel
      disabled={props.disabled}
      control={
        <StyledCheckbox
          {...props}
          icon={<CustomCheckboxIcon />}
          checkedIcon={<CustomCheckboxIcon isChecked />}
        />
      }
      label={
        <LabelContainer>
          <LabelText disabled={props.disabled}>{label}</LabelText>
          {subLabel && <SubLabel disabled={props.disabled}>{subLabel}</SubLabel>}
        </LabelContainer>
      }
    />
  );
};

export default CustomCheckbox;
