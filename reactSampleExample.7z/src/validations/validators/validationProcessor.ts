import { customValidations, CustomValidationNames } from '../validators/customValidationRules';
import { RegisterOptions } from 'react-hook-form';

type NumericValidationKeys = 'minLength' | 'maxLength' | 'min' | 'max';

export function validationProcessor(fieldValidations: any): RegisterOptions {
  const processedValidations: RegisterOptions = {};

  // Handle 'required'
  if (fieldValidations.required !== undefined) {
    if (typeof fieldValidations.required === 'string') {
      processedValidations.required = fieldValidations.required;
    } else if (typeof fieldValidations.required === 'object') {
      processedValidations.required = fieldValidations.required.message;
    }
  }

  // Handle 'minLength' and 'maxLength'
  const numericValidationKeys: NumericValidationKeys[] = ['minLength', 'maxLength', 'min', 'max'];
  numericValidationKeys.forEach((key) => {
    if (fieldValidations[key] !== undefined) {
      processedValidations[key] = fieldValidations[key];
    }
  });

  // Handle 'pattern'
  if (fieldValidations.pattern) {
    const patternValue = fieldValidations.pattern.value;
    processedValidations.pattern = {
      value: new RegExp(patternValue),
      message: fieldValidations.pattern.message,
    };
  }

  // Handle 'validate' (custom validations)
  if (fieldValidations.validate) {
    const validateFunctions: { [key: string]: (value: any) => boolean | string } = {};

    fieldValidations.validate.forEach((cv: any) => {
      const validationFnFactory = customValidations[cv.name as CustomValidationNames];
      if (validationFnFactory) {
        const validationFn = validationFnFactory(cv.params || {});

        validateFunctions[cv.name] = (value: any) => {
          const isValid = validationFn(value);
          return isValid || cv.message;
        };
      } else {
        console.error(`Validation function "${cv.name}" not found.`);
      }
    });

    processedValidations.validate = validateFunctions;
  }

  return processedValidations;
}
