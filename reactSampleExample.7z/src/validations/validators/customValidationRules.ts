import dayjs from 'dayjs';
import { isPublicHoliday, isWeekEnd, parseDateValue } from '../utils/dateUtility';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);

export type CustomValidationNames =
  | 'noNumbers'
  | 'isValidDate'
  | 'isBeforeDate'
  | 'isPositive'
  | 'hasTwoDecimalPlaces'
  | 'isNotWeekendOrHoliday'
  | 'isWithinDateRange';

export const customValidations: Record<CustomValidationNames, (params?: any) => (value: any) => boolean> = {
  noNumbers: () => {
    return (value: string): boolean => {
      return /^[A-Za-z]+$/.test(value);
    };
  },
  isValidDate: () => {
    return (value: string): boolean => {
      const date = new Date(value);
      return !isNaN(date.getTime());
    };
  },
  isBeforeDate: (params: { compareDate: string }) => {
    return (value: string): boolean => {
      const inputDate = new Date(value);
      let compareDate: Date;

      if (params.compareDate === 'today') {
        compareDate = new Date();
      } else {
        compareDate = new Date(params.compareDate);
      }

      return inputDate < compareDate;
    };
  },
  isNotWeekendOrHoliday: (params?: any) => {
    return (value: string): boolean => {
      const date = dayjs(value);
      const holidays = params?.holidays || [];
      return !isWeekEnd(date) && !isPublicHoliday(date, holidays);
    };
  },
  isWithinDateRange: (params?: any) => {
    return (value: string): boolean => {
      const date = dayjs(value);
      const minDate = params?.minDate ? parseDateValue(params.minDate) : dayjs();
      const maxDate = params?.maxDate ? parseDateValue(params.maxDate) : dayjs().add(1, 'month');
      return date.isSameOrAfter(minDate, 'day') && date.isSameOrBefore(maxDate, 'day');
    };
  },

  isPositive: () => {
    return (value: string): boolean => {
      const amount = parseFloat(value);
      return amount >= 0;
    };
  },
  hasTwoDecimalPlaces: () => {
    return (value: string): boolean => {
      return /^\d+(\.\d{1,2})?$/.test(value);
    };
  },
};
