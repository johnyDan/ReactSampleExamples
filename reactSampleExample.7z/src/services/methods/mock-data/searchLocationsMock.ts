export const searchLocationsMock = [
  {
    locationId: 'ChIJPwoIH3K35YgRLAX_J9oQs0o',
    name: 'FIS',
    address: 'Riverside Avenue, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJGbI7pC-55YgRG42hc2KAs9M',
    name: 'Fishweir Brewing Company',
    address: 'Edgewood Avenue South, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJCT41iUC45YgRJtXS7bP8hzA',
    name: 'Fishweir Elementary School',
    address: 'Herschel Street, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJ4QdiK0e45YgRsE40AoWZnwg',
    name: 'Fishweir Park',
    address: 'Valencia Road, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJRW0Yhc7O5YgR8GATkEQrXQM',
    name: "Fisherman's Dock - Mandarin",
    address: 'San Jose Boulevard, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJVZWhhyG35YgRTZqa0FoTs5Y',
    name: "McDonald's",
    address: 'East State Street, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJG85pOFq15YgRdJNvP2gty2I',
    name: "McDonald's",
    address: 'Town Center Parkway, Jacksonville, FL, USA',
  },
  {
    locationId: 'ChIJA9j-0y015IgR3iAd5-byjDY',
    name: "McDonald's",
    address: 'Baymeadows Road, Jacksonville, FL, USA',
  },
];
