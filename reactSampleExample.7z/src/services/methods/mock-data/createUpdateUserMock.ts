export const createUpdateUserMockFailed = {
  error: {
    code: 400,
    errors: [
      {
        reason: 'Accounts[0].RoutingNumber',
        message: 'The account must provide a valid routing number.',
      },
      {
        reason: 'Addresses[0].Country',
        message: 'The country provided must be a valid country code of 2 characters.',
      },
      {
        reason: 'AccountHolders[0].SsnTin',
        message: 'The SSN/TIN must be 9 numeric characters (no hyphens)',
      },
      {
        reason: 'AccountHolders[0].BirthDate',
        message: 'The date of birth must be in the format yyyy-mm-dd and must be a date from the past 150 years',
      },
    ],
  },
  apiVersion: '3.0.0',
  id: 'c9ecfc0b3c844307998f2ab6738c0fd8',
};

export const createOrUpdateCustomerSuccess = {
  data: {
    item: {
      email: '11223301@gmailid.com',
      phoneNumber: '2243451234',
      accountHolders: [
        {
          firstName: 'firsttest01',
          middleInitial: 't',
          lastName: 'lasttest01',
          ssnTin: '778123456',
          birthDate: '1994-08-09',
        },
      ],
      accounts: [
        {
          number: '112201',
          type: 'Checking',
          name: 'Checking',
          routingNumber: '053000196',
          index: 0,
          metadata: {},
        },
        {
          number: '112202',
          type: 'Checking',
          name: 'Checking',
          routingNumber: '053000196',
          index: 1,
          metadata: {},
        },
      ],
      addresses: [
        {
          line1: '11 West 42nd Street',
          line2: 'Floor 1',
          city: 'New York',
          zip: '10036',
          state: 'NY',
          country: 'US',
        },
      ],
      metadata: {},
    },
    kind: 'Customer',
    lang: 'en-US',
  },
  apiVersion: '3.0.0',
  id: '7282397f87f342d1abf6243c55e19be8',
};
