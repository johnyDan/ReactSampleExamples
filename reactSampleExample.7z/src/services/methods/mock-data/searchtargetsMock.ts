export const searchTargetsMock = [
  {
    targetId: 1757,
    name: "McDonalds, Inc. (McDonald's)",
    type: 'deposit',
  },
  {
    targetId: 4788,
    name: 'San Antonio Independent School District (SAISD)',
    type: 'deposit',
  },
  {
    targetId: 17206,
    name: 'Jbk Management LLC (McDonalds)',
    type: 'deposit',
  },
  {
    targetId: 59605,
    name: 'Arch Fellow LLC (McDonalds)',
    type: 'deposit',
  },
  {
    targetId: 21734,
    name: 'City of Thomson - McDuffie County',
    type: 'deposit',
  },
  {
    targetId: 58622,
    name: 'Fort McDowell Casino (AZ)',
    type: 'deposit',
  },
  {
    targetId: 48495,
    name: 'McDonald Heating, Air Conditioning and Plumbing, Inc.',
    type: 'deposit',
  },

  {
    targetId: 42044,
    name: 'Fidelity National Information Services Inc. (FIS)',
    type: 'deposit',
  },

  {
    targetId: 57359,
    name: "Kings Fish and Wings (King's Fish and Wings)",
    type: 'deposit',
  },
  {
    targetId: 46480,
    name: 'Red Fish Blue Fish Pensacola Beach',
    type: 'deposit',
  },
  {
    targetId: 19353,
    name: 'Fishbeck, Thompson, Carr & Huber, Inc. (FTCH)',
    type: 'deposit',
  },
  {
    targetId: 17156,
    name: 'Thermo Fisher Scientific Inc.',
    type: 'deposit',
  },
  {
    targetId: 29786,
    name: 'Acumen Fiscal Agent',
    type: 'deposit',
  },
  {
    targetId: 41736,
    name: 'Fiserv, Inc.',
    type: 'deposit',
  },
  {
    targetId: 4908,
    name: 'Fisher Auto Parts Store',
    type: 'deposit',
  },
  {
    targetId: 23725,
    name: 'Shucks Fish House - Downtown',
    type: 'deposit',
  },
  {
    targetId: 33907,
    name: 'The Fish Market',
    type: 'deposit',
  },
  {
    targetId: 60247,
    name: 'Walmart - (Wal-Mart Stores, Inc) (Walmart Supercenter)',
    type: 'deposit',
  },
  {
    targetId: 38997,
    name: 'Walman Optical',
    type: 'deposit',
  },
  {
    targetId: 5829,
    name: 'Archdiocese of New Orleans',
    type: 'deposit',
  },

  {
    targetId: 40921,
    name: 'DailyPay, Inc. (DailyPay Corporate Employee Payroll)',
    type: 'deposit',
  },
  {
    targetId: 40923,
    name: 'DailyPay, Inc.',
    type: 'deposit',
  },
  {
    targetId: 65,
    name: 'Target (Target Brands, Inc.)',
    type: 'deposit',
  },
  {
    targetId: 9034,
    name: 'Marietta Daily Journal',
    type: 'deposit',
  },
  {
    targetId: 63221,
    name: 'DailyBooth',
    type: 'deposit',
  },
  {
    targetId: 21116,
    name: 'Fresh Daily Inc.',
    type: 'deposit',
  },
  {
    targetId: 19166,
    name: 'The Daily Nonpareil',
    type: 'deposit',
  },
  {
    targetId: 62194,
    name: 'theDailyMuse',
    type: 'deposit',
  },
  {
    targetId: 706,
    name: "Iowa Public Employees' Retirement System (IPERS)",
    type: 'deposit',
  },
];
