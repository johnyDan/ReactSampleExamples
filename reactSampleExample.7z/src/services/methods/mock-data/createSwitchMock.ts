export const createSwitchMock: any = {
  1757: {
    data: {
      item: {
        index: 77,
        type: 'Deposit',
        targetId: 1757,
        name: "McDonalds, Inc. (McDonald's)",
        accountHolderIndex: 0,
        values: {
          accounts: [],
          fields: {
            Custom_SSN4: null,
            'Custom_Employee/ID': null,
            'Custom_Company/MailingAddress': {
              line1: null,
              line2: null,
              line3: null,
              city: null,
              state: null,
              zip: null,
            },
          },
        },
        ux: {
          accounts: {
            limit: 5,
            maxChecking: 5,
            maxSavings: 5,
            choices: [
              { index: 0, label: 'Free Checking *7890' },
              { index: 1, label: 'Free Checking *1234' },
            ],
            fields: [
              {
                key: 'splitType',
                label: 'Type',
                type: 'select',
                required: false,
                selections: [
                  { key: 'remainder', label: 'Remainder' },
                  { key: 'currency', label: '$ Amount' },
                  { key: 'percentage', label: 'Percentage' },
                ],
              },
              {
                key: 'splitAmount',
                label: 'Percent or Fixed Amount',
                type: 'textbox',
                required: false,
                regex: '^(1-9\\\\d*\\\\.\\\\d2|(100(.0)?|(0(\\\\.1-9))|(1-90-9?(\\\\.\\\\d)?)))$',
                validationMessage: 'Must be an amount with 2 decimal places or a whole percentage',
              },
            ],
          },
          fields: [
            { key: 'Custom_SSN4', label: 'SSN - Last 4', type: 'textbox', required: true },
            { key: 'Custom_Employee/ID', label: 'Employee ID Number', type: 'textbox', required: false },
            {
              key: 'Custom_Company/MailingAddress',
              label: "Company's Mailing Address",
              type: 'composite',
              required: true,
              fields: [
                { key: 'line1', label: 'Line1', type: 'textbox', required: true },
                { key: 'line2', label: 'Line2', type: 'textbox', required: false },
                { key: 'line3', label: 'Line3', type: 'textbox', required: false },
                { key: 'city', label: 'City', type: 'textbox', required: true },
                {
                  key: 'state',
                  label: 'State',
                  type: 'textbox',
                  required: true,
                  regex:
                    '^(A[AEKLPRSZ]|C[AOT]|D[CE]|F[LM]|G[AU]|HI|I[ADLN]|K[SY]|LA|M[ADEINOPST]|N[CDEHJMVY]|O[HKR]|P[ARW]|RI|S[CD]|T[NX]|U[TM]|V[AIT]|W[AIVY])$',
                  validationMessage: 'Must be a valid 2 character state code',
                },
                {
                  key: 'zip',
                  label: 'Zip Code',
                  type: 'textbox',
                  required: true,
                  regex: '^\\d{5}(-\\d{4})?$',
                  validationMessage: 'Must be in the format 00000 or 00000-0000',
                },
              ],
            },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              Custom_SSN4: 'This field is required',
              line1: 'This field is required',
              city: 'This field is required',
              state: 'This field is required',
              zip: 'This field is required',
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'be2bb1d2300c462fbdd62e8009bed1ef',
  },

  42044: {
    data: {
      item: {
        index: 68,
        type: 'Deposit',
        targetId: 42044,
        name: 'Fidelity National Information Services Inc. (FIS)',
        accountHolderIndex: 0,
        values: {
          accounts: [],
          fields: {
            'Custom_Amount (in dollars)': null,
            'Custom_or Percentage of Pay (1 - 100)': null,
            'Custom_Work Location': null,
            'Custom_Employee ID': null,
            'Custom_Last 4 of SSN': null,
          },
        },
        ux: {
          accounts: {
            limit: 1,
            maxChecking: 1,
            maxSavings: 1,
            choices: [{ index: 0, label: 'Free Checking *7890' }],
            fields: [],
          },
          fields: [
            { key: 'Custom_Amount (in dollars)', label: 'Amount (in dollars)', type: 'textbox', required: false },
            {
              key: 'Custom_or Percentage of Pay (1 - 100)',
              label: 'or Percentage of Pay (1 - 100)',
              type: 'textbox',
              required: false,
            },
            { key: 'Custom_Work Location', label: 'Work Location', type: 'textbox', required: true },
            { key: 'Custom_Employee ID', label: 'Employee ID', type: 'textbox', required: false },
            { key: 'Custom_Last 4 of SSN', label: 'Last 4 of SSN', type: 'textbox', required: true },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              'Custom_Work Location': 'This field is required',
              'Custom_Last 4 of SSN': 'This field is required',
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'e2fbca772acb4ecdbb1c1473efd76611',
  },

  40921: {
    data: {
      item: {
        index: 151,
        type: 'Deposit',
        targetId: 40921,
        name: 'DailyPay, Inc. (DailyPay Corporate Employee Payroll)',
        accountHolderIndex: 0,
        values: { accounts: [], fields: { Custom_SSN4: null, 'Custom_Employee/ID': null } },
        ux: {
          accounts: {
            limit: 5,
            maxChecking: 5,
            maxSavings: 5,
            choices: [{ index: 0, label: 'Free Checking *7890' }],
            fields: [
              {
                key: 'splitType',
                label: 'Type',
                type: 'select',
                required: false,
                selections: [
                  { key: 'remainder', label: 'Remainder' },
                  { key: 'currency', label: '$ Amount' },
                  { key: 'percentage', label: 'Percentage' },
                ],
              },
              {
                key: 'splitAmount',
                label: 'Percent or Fixed Amount',
                type: 'textbox',
                required: false,
                regex: '^(1-9\\\\d*\\\\.\\\\d2|(100(.0)?|(0(\\\\.1-9))|(1-90-9?(\\\\.\\\\d)?)))$',
                validationMessage: 'Must be an amount with 2 decimal places or a whole percentage',
              },
            ],
          },
          fields: [
            { key: 'Custom_SSN4', label: 'SSN - Last 4', type: 'textbox', required: true },
            { key: 'Custom_Employee/ID', label: 'Employee ID Number', type: 'textbox', required: false },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: { Custom_SSN4: 'This field is required' },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'afc494297fb14ba29471951d6ab01a0a',
  },

  0: {
    data: {
      item: {
        index: 1,
        type: 'Deposit',
        targetId: 40921,
        name: 'Testing Company Inc',
        accountHolderIndex: 0,
        values: { accounts: [], fields: { Custom_SSN4: null, 'Custom_Employee/ID': null } },
        ux: {
          accounts: {
            limit: 5,
            maxChecking: 5,
            maxSavings: 5,
            choices: [{ index: 0, label: 'Free Checking *7890' }],
            fields: [
              {
                key: 'splitType',
                label: 'Type',
                type: 'select',
                required: false,
                selections: [
                  { key: 'remainder', label: 'Remainder' },
                  { key: 'currency', label: '$ Amount' },
                  { key: 'percentage', label: 'Percentage' },
                ],
              },
              {
                key: 'splitAmount',
                label: 'Percent or Fixed Amount',
                type: 'textbox',
                required: false,
                regex: '^(1-9\\\\d*\\\\.\\\\d2|(100(.0)?|(0(\\\\.1-9))|(1-90-9?(\\\\.\\\\d)?)))$',
                validationMessage: 'Must be an amount with 2 decimal places or a whole percentage',
              },
            ],
          },
          fields: [
            { key: 'Custom_SSN4', label: 'SSN - Last 4', type: 'textbox', required: true },
            { key: 'Custom_Employee/ID', label: 'Employee ID Number', type: 'textbox', required: false },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: { Custom_SSN4: 'This field is required' },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'afc494297fb14ba29471951d6ab01a0a',
  },

  ChIJ4QdiK0e45YgRsE40AoWZnwg: {
    data: {
      item: {
        index: 153,
        type: 'Deposit',
        targetId: 0,
        locationId: 'ChIJ4QdiK0e45YgRsE40AoWZnwg',
        name: 'Fishweir Park',
        accountHolderIndex: 0,
        values: { accounts: [], fields: { category: 0, Custom_SSN4: null, 'Custom_Employee/ID': null } },
        ux: {
          accounts: {
            limit: 5,
            maxChecking: 5,
            maxSavings: 5,
            choices: [{ index: 0, label: 'Free Checking *7890' }],
            fields: [
              {
                key: 'splitType',
                label: 'Type',
                type: 'select',
                required: false,
                selections: [
                  { key: 'remainder', label: 'Remainder' },
                  { key: 'currency', label: '$ Amount' },
                  { key: 'percentage', label: 'Percentage' },
                ],
              },
              {
                key: 'splitAmount',
                label: 'Percent or Fixed Amount',
                type: 'textbox',
                required: false,
                regex: '^(1-9\\\\d*\\\\.\\\\d2|(100(.0)?|(0(\\\\.1-9))|(1-90-9?(\\\\.\\\\d)?)))$',
                validationMessage: 'Must be an amount with 2 decimal places or a whole percentage',
              },
            ],
          },
          fields: [
            {
              key: 'category',
              label: 'Type',
              type: 'select',
              required: true,
              selections: [
                { key: '1', label: 'Payroll' },
                { key: '2', label: 'Pension' },
                { key: '7', label: 'Retirement' },
                { key: '13', label: 'Child Support' },
                { key: '4', label: 'Investment' },
                { key: '6', label: 'Insurance' },
                { key: '12', label: 'State/County Benefits' },
                { key: '9', label: 'Federal Benefit' },
                { key: '3', label: 'Annuity' },
                { key: '11', label: 'Military' },
                { key: '8', label: 'Mutual Fund' },
                { key: '14', label: 'Restitution' },
                { key: '5', label: 'Social Security' },
                { key: '10', label: 'VA' },
              ],
            },
            {
              key: 'Custom_SSN4',
              label: 'SSN - Last 4',
              type: 'textbox',
              required: true,
              regex: '^(?!0{4})[0-9]{4}$',
              validationMessage: 'The value entered is not a valid last 4 digits of an SSN',
            },
            { key: 'Custom_Employee/ID', label: 'ID Number', type: 'textbox', required: false },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              Custom_SSN4: 'This field is required',
              category: 'The field is required and must match one of the provided categories.',
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: '0470889827884b828772c98c3dd6f2e8',
  },

  manual: {
    data: {
      item: {
        index: 155,
        type: 'Deposit',
        targetId: 0,
        accountHolderIndex: 0,
        values: {
          accounts: [],
          fields: {
            name: null,
            phoneNumber: null,
            website: null,
            mailingAddress: { line1: null, line2: null, line3: null, city: null, state: null, zip: null },
            category: 0,
            Custom_SSN4: null,
            'Custom_Employee/ID': null,
          },
        },
        ux: {
          accounts: {
            limit: 5,
            maxChecking: 5,
            maxSavings: 5,
            choices: [{ index: 0, label: 'Free Checking *7890' }],
            fields: [
              {
                key: 'splitType',
                label: 'Type',
                type: 'select',
                required: false,
                selections: [
                  { key: 'remainder', label: 'Remainder' },
                  { key: 'currency', label: '$ Amount' },
                  { key: 'percentage', label: 'Percentage' },
                ],
              },
              {
                key: 'splitAmount',
                label: 'Percent or Fixed Amount',
                type: 'textbox',
                required: false,
                regex: '^(1-9\\\\d*\\\\.\\\\d2|(100(.0)?|(0(\\\\.1-9))|(1-90-9?(\\\\.\\\\d)?)))$',
                validationMessage: 'Must be an amount with 2 decimal places or a whole percentage',
              },
            ],
          },
          fields: [
            {
              key: 'category',
              label: 'Type',
              type: 'select',
              required: true,
              selections: [
                { key: '1', label: 'Payroll' },
                { key: '2', label: 'Pension' },
                { key: '7', label: 'Retirement' },
                { key: '13', label: 'Child Support' },
                { key: '4', label: 'Investment' },
                { key: '6', label: 'Insurance' },
                { key: '12', label: 'State/County Benefits' },
                { key: '9', label: 'Federal Benefit' },
                { key: '3', label: 'Annuity' },
                { key: '11', label: 'Military' },
                { key: '8', label: 'Mutual Fund' },
                { key: '14', label: 'Restitution' },
                { key: '5', label: 'Social Security' },
                { key: '10', label: 'VA' },
              ],
            },
            { key: 'name', label: 'Name', type: 'textbox', required: true },
            {
              key: 'mailingAddress',
              label: 'Mailing Address',
              type: 'composite',
              required: true,
              fields: [
                { key: 'line1', label: 'Line1', type: 'textbox', required: true },
                { key: 'line2', label: 'Line2', type: 'textbox', required: false },
                { key: 'line3', label: 'Line3', type: 'textbox', required: false },
                { key: 'city', label: 'City', type: 'textbox', required: true },
                {
                  key: 'state',
                  label: 'State',
                  type: 'textbox',
                  required: true,
                  regex:
                    '^(A[AEKLPRSZ]|C[AOT]|D[CE]|F[LM]|G[AU]|HI|I[ADLN]|K[SY]|LA|M[ADEINOPST]|N[CDEHJMVY]|O[HKR]|P[ARW]|RI|S[CD]|T[NX]|U[TM]|V[AIT]|W[AIVY])$',
                  validationMessage: 'Must be a valid 2 character state code',
                },
                {
                  key: 'zip',
                  label: 'Zip Code',
                  type: 'textbox',
                  required: true,
                  regex: '^\\d{5}(-\\d{4})?$',
                  validationMessage: 'Must be in the format 00000 or 00000-0000',
                },
              ],
            },
            { key: 'website', label: 'Website', type: 'textbox', required: false },
            { key: 'phoneNumber', label: 'Phone Number', type: 'textbox', required: false },
            {
              key: 'Custom_SSN4',
              label: 'SSN - Last 4',
              type: 'textbox',
              required: true,
              regex: '^(?!0{4})[0-9]{4}$',
              validationMessage: 'The value entered is not a valid last 4 digits of an SSN',
            },
            { key: 'Custom_Employee/ID', label: 'ID Number', type: 'textbox', required: false },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              Custom_SSN4: 'This field is required',
              category: 'The field is required and must match one of the provided categories.',
              name: 'This field is required',
              mailingAddress: {
                line1: 'This field is required',
                city: 'This field is required',
                state: 'This field is required',
                zip: 'This field is required',
              },
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'b0b3548399764d21b397efe6a9dee8db',
  },

  31261: {
    data: {
      item: {
        index: 3,
        type: 'Deposit',
        targetId: 31261,
        name: 'Amazon (Payroll)',
        accountHolderIndex: 0,
        values: {},
        ux: {
          fields: [
            {
              key: 'instructions',
              label: 'Instructions',
              type: 'html',
              body: '<p>Click <a href="https://app.clickswitch.com/web?accessKey=ak_test_TwnJdVZed8z1cglX1lZxQViMYq9yoG1m93TT0jg11v2hH5I2ZvEhYBnHdUYX7hQx&targetId=e481bc9d-274d-422b-0973-08d96291198c">here</a> to get started!</p>',
            },
          ],
        },
        state: {
          status: 'Ready',
          actions: ['HTTP-PUT', 'Complete'],
          validation: { accounts: [], fields: {}, overall: [] },
        },
        metadata: {},
        workflowInstanceId:
          'ak_test_TwnJdVZed8z1cglX1lZxQViMYq9yoG1m93TT0jg11v2hH5I2ZvEhYBnHdUYX7hQx                                                                                                                                                                                        ',
        workflowEmbedUrl:
          'https://app.clickswitch.com/web?accessKey=ak_test_TwnJdVZed8z1cglX1lZxQViMYq9yoG1m93TT0jg11v2hH5I2ZvEhYBnHdUYX7hQx&targetId=e481bc9d-274d-422b-0973-08d96291198c',
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'd3a0d7387d594600a9d7302b464fb398',
  },

  4981: {
    data: {
      item: {
        index: 160,
        type: 'Deposit',
        targetId: 4981,
        name: 'Uber Technologies Inc. / UBER',
        accountHolderIndex: 0,
        values: {},
        ux: {
          fields: [
            {
              key: 'instructions',
              label: 'Instructions',
              type: 'html',
              body: '<p><strong></strong></p><p><strong>UBER</strong>&nbsp;requires you to access your online account to switch your direct deposit.&nbsp; Please login to your online account to complete your switch.</p><p><strong><a href="https://login.uber.com/login" target="_blank">Click here to log into your UBER account</a>.<br /></strong></p><p>To update your information over the phone, please call&nbsp;<strong>(877) 223-0823</strong>.</p><p><strong></strong></p>',
            },
          ],
        },
        state: {
          status: 'Ready',
          actions: ['HTTP-PUT', 'Cancel', 'Complete'],
          validation: { accounts: [], fields: {}, overall: [] },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: '6ea510b7caac46fab50531fb408169c7',
  },

  65: {
    data: {
      item: {
        index: 166,
        type: 'Deposit',
        targetId: 65,
        name: 'Target (Target Brands, Inc.)',
        accountHolderIndex: 0,
        values: {
          accounts: [],
          fields: {
            Custom_SSN4: null,
            'Custom_Employee/ID': null,
          },
        },
        ux: {
          accounts: {
            limit: 5,
            maxChecking: 5,
            maxSavings: 5,
            choices: [
              {
                index: 0,
                label: 'Free Checking *7890',
              },
            ],
            fields: [
              {
                key: 'splitType',
                label: 'Type',
                type: 'select',
                required: false,
                selections: [
                  {
                    key: 'remainder',
                    label: 'Remainder',
                  },
                  {
                    key: 'currency',
                    label: '$ Amount',
                  },
                  {
                    key: 'percentage',
                    label: 'Percentage',
                  },
                ],
              },
              {
                key: 'splitAmount',
                label: 'Percent or Fixed Amount',
                type: 'textbox',
                required: false,
                regex: '^(1-9\\\\d*\\\\.\\\\d2|(100(.0)?|(0(\\\\.1-9))|(1-90-9?(\\\\.\\\\d)?)))$',
                validationMessage: 'Must be an amount with 2 decimal places or a whole percentage',
              },
            ],
          },
          fields: [
            {
              key: 'Custom_SSN4',
              label: 'SSN - Last 4',
              type: 'textbox',
              required: true,
            },
            {
              key: 'Custom_Employee/ID',
              label: 'Employee ID Number',
              type: 'textbox',
              required: false,
            },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Print', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              Custom_SSN4: 'This field is required',
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: '0e032616ee2c41b89dee0b2377969556',
  },

  4788: {
    data: {
      item: {
        index: 167,
        type: 'Deposit',
        targetId: 4788,
        name: 'San Antonio Independent School District (SAISD)',
        accountHolderIndex: 0,
        values: {
          accounts: [],
          fields: {
            Custom_EmployeeID: null,
            Custom_SocialSecurityNumber: null,
            Custom_SchoolName: null,
            Custom_LOC: null,
            Custom_IsMonthly: 'False',
            Custom_IsBiWeekly: 'False',
          },
        },
        ux: {
          accounts: {
            limit: 1,
            maxChecking: 1,
            maxSavings: 1,
            choices: [
              {
                index: 0,
                label: 'Free Checking *7890',
              },
            ],
            fields: [],
          },
          fields: [
            {
              key: 'Custom_EmployeeID',
              label: 'Employee ID #',
              type: 'textbox',
              required: false,
            },
            {
              key: 'Custom_SocialSecurityNumber',
              label: 'OR Social Security Number',
              type: 'textbox',
              required: false,
            },
            {
              key: 'Custom_SchoolName',
              label: 'School Name',
              type: 'textbox',
              required: true,
            },
            {
              key: 'Custom_LOC',
              label: 'LOC #',
              type: 'textbox',
              required: true,
            },
            {
              key: 'Custom_IsMonthly',
              label: 'Payroll Type is Monthly?',
              type: 'checkbox',
              required: false,
            },
            {
              key: 'Custom_IsBiWeekly',
              label: 'Or Payroll Type is Bi-Weekly?',
              type: 'checkbox',
              required: false,
            },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              Custom_SchoolName: 'This field is required',
              Custom_LOC: 'This field is required',
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: 'e4d051d85f30407eac0fcf9a73b672f6',
  },

  706: {
    data: {
      item: {
        index: 168,
        type: 'Deposit',
        targetId: 706,
        name: "Iowa Public Employees' Retirement System (IPERS)",
        accountHolderIndex: 0,
        values: {
          accounts: [],
          fields: {
            Custom_PolicyAccountNumber: null,
            'Custom_Insured/DOB': null,
          },
        },
        ux: {
          accounts: {
            limit: 1,
            maxChecking: 1,
            maxSavings: 1,
            choices: [
              {
                index: 0,
                label: 'Free Checking *7890',
              },
            ],
            fields: [],
          },
          fields: [
            {
              key: 'Custom_PolicyAccountNumber',
              label: 'Member Policy Number',
              type: 'textbox',
              required: true,
            },
            {
              key: 'Custom_Insured/DOB',
              label: 'Date of Birth',
              type: 'textbox',
              required: true,
            },
          ],
        },
        state: {
          status: 'Incomplete',
          actions: ['HTTP-PUT', 'Cancel'],
          validation: {
            accounts: [],
            fields: {
              Custom_PolicyAccountNumber: 'This field is required',
              'Custom_Insured/DOB': 'This field is required',
            },
            overall: ['At least one account must be selected'],
          },
        },
        metadata: {},
      },
      kind: 'switch',
      lang: 'en-US',
    },
    apiVersion: '3.0.0',
    context: 'testing',
    id: '402163598c5e4a7c81f9e26341fd1ef1',
  },
};
