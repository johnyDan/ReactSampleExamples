import { apiRequest } from '../apiUtils';
import { API_ENDPOINTS } from '../apiEndpoints';
import { ApiResponse } from '../apiTypes';
import { actionsMock, statusesMock } from './mock-data/statusActionsMock';

interface TargetType {
  id: string;
  label: string;
  plural: string;
  recipient: string;
  help: string;
}

interface SwitchStatus {
  id: string;
  label: string;
  help: string;
}

interface SwitchAction {
  id: string;
  label: string;
  help: string;
}

export const getTargetTypes = (params: any): Promise<ApiResponse<TargetType[]>> =>
  apiRequest('get', API_ENDPOINTS.TYPES.TARGET_TYPES, null, params);

export const getSwitchStatuses = (): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(statusesMock);
      }, 1000);
    });
  } else {
    return apiRequest('get', API_ENDPOINTS.TYPES.SWITCH_STATUSES, null);
  }
};

export const getSwitchActions = (): Promise<any> => {
  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(actionsMock);
      }, 1000);
    });
  } else {
    return apiRequest('get', API_ENDPOINTS.TYPES.SWITCH_ACTIONS, null);
  }
};
