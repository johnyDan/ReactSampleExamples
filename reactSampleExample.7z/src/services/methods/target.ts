import { apiRequest } from '../apiUtils';
import { API_ENDPOINTS } from '../apiEndpoints';
import { ApiResponse } from '../apiTypes';
import { searchTargetsMock } from './mock-data/searchtargetsMock';
import { useRecoilValue } from 'recoil';
import { userState } from '@/state/atoms';
import { apiContext } from '../apiContext';
import { searchLocationsMock } from './mock-data/searchLocationsMock';

interface CustomerKey {
  customerKey?: string;
}

interface Target {
  targetId: string;
  name: string;
  type: string;
}

interface Location {
  locationId: string;
  name: string;
  address: string;
}

interface SearchTargetsParams extends CustomerKey {
  type: 'deposit' | 'payment';
  name: string;
  category?: number;
  customer?: string;
}

interface SearchLocationsParams extends CustomerKey {
  type: 'deposit' | 'payment';
  name: string;
  category?: number;
  customer?: string;
}

export const searchTargets = (name: string): Promise<any> => {
  const params: SearchTargetsParams = {
    name: name,
    type: 'deposit',
    customer: apiContext.getCustomerKey(),
  };

  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    let matchedTargets = searchTargetsMock.filter((item) => item.name.toLocaleLowerCase().includes(params.name));
    return Promise.resolve({
      data: {
        currentItemCount: matchedTargets.length,
        items: matchedTargets,
        kind: 'types#targets',
        lang: 'en-US',
      },
    });
  } else {
    return apiRequest('get', API_ENDPOINTS.TARGET.SEARCH, null, params);
  }
};

export const searchLocations = (name: string): Promise<any> => {
  const params: SearchLocationsParams = {
    name: name,
    type: 'deposit',
    customer: apiContext.getCustomerKey(),
  };

  if (import.meta.env.VITE_MOCK_API_MODE === 'true') {
    let matchedTargets = searchLocationsMock.filter((item) => item.name.toLocaleLowerCase().includes(params.name));
    return Promise.resolve({
      data: {
        currentItemCount: matchedTargets.length,
        items: matchedTargets,
        kind: 'types#targets',
        lang: 'en-US',
      },
    });
  } else {
    return apiRequest('get', API_ENDPOINTS.TARGET.LOCATIONS, null, params);
  }
};
