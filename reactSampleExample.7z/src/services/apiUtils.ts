import api from './api';

export const apiRequest = async <T>(
  method: 'get' | 'post' | 'put' | 'delete',
  url: string,
  data?: T | null,
  params?: Record<string, any>,
  options?: {
    headers?: Record<string, string>;
  }
): Promise<any> => {
  try {
    let config: any = options ? options : {};

    if (method === 'get' || method === 'delete') {
      config.params = params;
      config.data = data;
    } else {
      config = data;
    }

    const response = await api[method](url, config);
    return response.data;
  } catch (error) {
    console.error(`API ${method.toUpperCase()} request failed:`, error);
    throw error;
  }
};
