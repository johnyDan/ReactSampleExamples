export interface ApiResponse<T> {
  data: T;
  status: number;
  message?: string;
}

export type CustomerKey = string;

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface Webhook {
  id: string;
  url: string;
  events: string[];
}
