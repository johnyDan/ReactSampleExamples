export const API_ENDPOINTS = {
  TYPES: {
    TARGET_TYPES: '/types/targets',
    SWITCH_STATUSES: '/types/switch/statuses',
    SWITCH_ACTIONS: '/types/switch/actions',
  },
  EMPLOYEE: {
    BASE: '/employees',
    AUTH: '/auth',
  },
  CUSTOMER: {
    BASE: '/customers',
    AUTH: '/auth',
  },
  TARGET: {
    SEARCH: '/targets',
    LOCATIONS: '/locations',
  },
  SWITCH: {
    BASE: '/switches',
    ACTION: '/action',
  },
  WEBHOOK: '/webhooks',
};
