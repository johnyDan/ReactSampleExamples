import React, { useState, useRef, useEffect, ChangeEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRecoilState, useRecoilValue } from 'recoil';
import {
  Typography,
  Box,
  Grid,
  TextField,
  InputAdornment,
  List,
  ListItem,
  Paper,
  styled,
  Theme,
  IconButton,
  Link,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { hasExistingSwitchesState, selectedCompanyState, switchCreationState } from '@/state/atoms';
import InfoBox from '@/components/common/infoBox';
import NavigationButtons from '@/components/layout/navigationButtons';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import { searchLocations, searchTargets } from '@/services/methods/target';
import InstructionsBox from '@/components/common/instructionsBox';
import { useForm } from 'react-hook-form';

interface SearchResult {
  targetId?: number;
  locationId?: string;
  name: string;
  type?: string;
  address?: string;
  manualSetup?: boolean;
}

const StyledPaper = styled(Paper)(({ theme }: { theme: Theme }) => ({
  position: 'absolute',
  top: '100%',
  left: 0,
  width: '100%',
  maxHeight: 300,
  overflowY: 'auto',
  marginTop: theme.spacing(1),
  boxShadow: theme.shadows[6],
}));

const StyledListItem = styled(ListItem)(({ theme }: { theme: Theme }) => ({
  '&:hover': {
    backgroundColor: theme.palette.action.hover,
  },
  cursor: 'pointer',
}));

const CompanySearch: React.FC = () => {
  // State variables
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [selectedResult, setSelectedResult] = useState<SearchResult | null>(null);
  const [locationsFetched, setLocationsFetched] = useState<boolean>(false);
  const searchBoxRef = useRef<HTMLDivElement>(null);

  // Recoil states
  const [companyState, setCompanyState] = useRecoilState(selectedCompanyState);
  const [switchCreation, setSwitchCreation] = useRecoilState(switchCreationState);
  const hasExistingSwitches = useRecoilValue(hasExistingSwitchesState);

  const navigate = useNavigate();

  // React Hook Form
  const {
    handleSubmit,
    formState: { errors },
    setError,
    clearErrors,
  } = useForm();

  // Handlers
  const handleSearch = async (term: string): Promise<void> => {
    setLocationsFetched(false);
    try {
      const response = await searchTargets(term);
      if (response.data && response.data.items && response.data.items.length > 0) {
        setResults(response.data.items);
        setErrorMessage('');
      } else {
        setResults([]);
        setErrorMessage('No results found');
      }
    } catch (error: unknown) {
      console.error('Error searching targets:', error);
      setResults([]);
      setErrorMessage('An error occurred while searching');
    }
    setShowDropdown(true);
  };

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>): void => {
    const newTerm = event.target.value;
    setSearchTerm(newTerm);
    setSelectedResult(null);
    setLocationsFetched(false);
    setResults([]);
    setErrorMessage('');
    clearErrors('company'); // clear the form error
  };

  const handleSelectResult = (result: SearchResult): void => {
    setSelectedResult(result);
    setShowDropdown(false);
    setErrorMessage('');
    clearErrors('company'); // clear the form error
    // Update the selected company state
    setCompanyState({
      name: result.name,
      targetId: result.targetId || null,
      locationId: result.locationId || null,
      manualSetup: result.manualSetup || false,
    });
    // Reset the switch creation state
    setSwitchCreation({
      switchId: null,
      switchData: null,
      step: 'create',
      isEditing: false,
      workflowEmbedUrl: null,
      error: null,
    });
  };

  const handleSearchIconClick = (): void => {
    if (searchTerm) {
      handleSearch(searchTerm);
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setSelectedResult(null);
    setResults([]);
    setLocationsFetched(false);
    setErrorMessage('');
    clearErrors('company'); // clear the form error
  };

  const handleSeeMoreResults = async () => {
    try {
      const response = await searchLocations(searchTerm);
      if (response.data && response.data.items && response.data.items.length > 0) {
        const locationResults = response.data.items;
        setResults((prevResults) => [...prevResults, ...locationResults]);
        setErrorMessage('');
      } else {
        setErrorMessage('No results found');
      }
      setLocationsFetched(true);
    } catch (error: unknown) {
      console.error('Error searching locations:', error);
      setErrorMessage('An error occurred while searching Locations');
    }
    setShowDropdown(true);
  };

  const handleManualSetup = () => {
    const manualResult: SearchResult = {
      name: searchTerm || 'Manual Deposit Setup',
      manualSetup: true,
    };
    handleSelectResult(manualResult);
  };

  const handleBack = () => {
    setSwitchCreation({
      switchId: null,
      switchData: null,
      step: 'create',
      isEditing: false,
      workflowEmbedUrl: null,
      error: null,
    });
    navigate('/');
  };

  const onSubmit = () => {
    navigate('/switch-management/create');
  };

  const handleContinue = handleSubmit(() => {
    if (!selectedResult) {
      setError('company', { type: 'manual', message: 'Please select an Employer or payroll provider' });
    } else {
      onSubmit();
    }
  });

  // useEffects
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchBoxRef.current && !searchBoxRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchTerm) {
        handleSearch(searchTerm);
      } else {
        setResults([]);
        setShowDropdown(false);
        setErrorMessage('');
        setLocationsFetched(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  // Return JSX
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', minHeight: '90vh', boxSizing: 'border-box' }}>
      <Grid
        container
        spacing={4}
        sx={{ p: { xs: 2, sm: 4 }, justifyContent: 'space-between', flexGrow: 1, overflowY: 'auto' }}>
        {/* Left side content */}
        <Grid
          item
          xs={12}
          md={5}
          sx={{ display: 'flex', gap: 2, flexDirection: 'column' }}>
          <Typography variant="h2">Setup your direct deposit</Typography>
          <Typography
            variant="body2"
            color="custom.paragraphText">
            You can easily setup direct deposit and skip the HR paperwork.
          </Typography>
          <Typography
            variant="body2"
            color="custom.paragraphText">
            Step 1 of 3
          </Typography>
          <Box sx={{ display: { xs: 'none', sm: 'block' }, mt: 2, overflow: 'auto' }}>
            <InfoBox
              title="Learn how you're protected"
              bodyText={[
                'Connecting your direct deposit only allows access to update your direct deposit to your Bank account.',
                'It does not allow access to income, paystubs, timesheets, name, address and contact information.',
              ]}
            />
          </Box>
        </Grid>

        {/* Right side content */}
        <Grid
          item
          xs={12}
          md={6}
          sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <Typography
            variant="h4"
            mb={2}
            gutterBottom>
            Who pays you?
          </Typography>

          {/* Search Box */}
          <Box
            ref={searchBoxRef}
            sx={{ position: 'relative', width: '100%' }}>
            <TextField
              fullWidth
              variant="outlined"
              placeholder="Employer or payroll provider"
              value={selectedResult ? selectedResult.name : searchTerm}
              onChange={handleInputChange}
              error={!!errors.company}
              helperText={errors.company ? (errors.company.message as string) : ''}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton onClick={handleSearchIconClick}>
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                ),
                endAdornment:
                  searchTerm || selectedResult ? (
                    <InputAdornment position="end">
                      <IconButton onClick={clearSearch}>
                        <HighlightOffIcon />
                      </IconButton>
                    </InputAdornment>
                  ) : null,
              }}
            />
            {showDropdown && (results.length > 0 || errorMessage || !locationsFetched) && (
              <StyledPaper>
                <List>
                  {errorMessage && results.length === 0 ? (
                    <>
                      <ListItem>
                        <Typography color="error">{errorMessage}</Typography>
                      </ListItem>
                      <ListItem key={'manual-setup'}>
                        <Link
                          component="button"
                          variant="body2"
                          underline="always"
                          onClick={handleManualSetup}>
                          Not here? Create a new depositor
                        </Link>
                      </ListItem>
                    </>
                  ) : (
                    <>
                      {results.map((result) => (
                        <StyledListItem
                          key={result.targetId || result.locationId}
                          onClick={() => handleSelectResult(result)}>
                          <Box
                            sx={{
                              display: 'flex',
                              flexDirection: 'column',
                              alignItems: 'flex-start',
                              width: '100%',
                            }}>
                            <Box
                              sx={{
                                display: 'flex',
                                justifyContent: 'flex-start',
                                alignItems: 'center',
                                width: '100%',
                              }}
                              gap={1}>
                              <Typography variant="body2">{result.name}</Typography>
                              {!result.address && (
                                <IconButton sx={{ p: 0 }}>
                                  <CheckCircleOutlineRoundedIcon />
                                </IconButton>
                              )}
                            </Box>
                            {result.address && (
                              <Typography
                                variant="caption"
                                color="textSecondary">
                                {result.address}
                              </Typography>
                            )}
                          </Box>
                        </StyledListItem>
                      ))}
                      {!locationsFetched && (
                        <ListItem key={'see-more'}>
                          <Link
                            component="button"
                            variant="body2"
                            underline="always"
                            onClick={handleSeeMoreResults}>
                            See more results
                          </Link>
                        </ListItem>
                      )}
                      {locationsFetched && (
                        <ListItem key={'manual-setup'}>
                          <Link
                            component="button"
                            variant="body2"
                            underline="always"
                            onClick={handleManualSetup}>
                            Not here? Create a new depositor
                          </Link>
                        </ListItem>
                      )}
                    </>
                  )}
                </List>
              </StyledPaper>
            )}
            {selectedResult && (
              <Grid container>
                <Grid
                  item
                  xs={12}
                  sx={{ mt: 2 }}>
                  <Typography
                    variant="h5"
                    gutterBottom>
                    Selected Company:
                  </Typography>
                  {!selectedResult.manualSetup && (
                    <Typography
                      variant="body1"
                      gutterBottom>
                      Name: {selectedResult.name}
                    </Typography>
                  )}
                  {selectedResult.targetId && (
                    <Typography
                      variant="body1"
                      gutterBottom>
                      Target ID: {selectedResult.targetId}
                    </Typography>
                  )}
                  {selectedResult.locationId && (
                    <>
                      <Typography
                        variant="body1"
                        gutterBottom>
                        Location ID: {selectedResult.locationId}
                      </Typography>
                      <Typography
                        variant="body1"
                        gutterBottom>
                        Address: {selectedResult.address}
                      </Typography>
                    </>
                  )}
                  {selectedResult.type && (
                    <Typography
                      variant="body1"
                      gutterBottom>
                      Type: {selectedResult.type}
                    </Typography>
                  )}
                  {selectedResult.manualSetup && (
                    <Typography
                      variant="body1"
                      gutterBottom>
                      You have chosen to manually set up your depositor.
                    </Typography>
                  )}
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{ mt: 2 }}>
                  <InstructionsBox text="To proceed, select Continue; this will create a new deposit switch." />
                </Grid>
              </Grid>
            )}
          </Box>
        </Grid>
      </Grid>

      {/* Navigation Buttons */}
      <Box
        sx={{
          position: 'sticky',
          bottom: 0,
          backgroundColor: 'background.paper',
          p: 2,
          zIndex: 1000,
        }}>
        <NavigationButtons
          items={[
            {
              type: 'button',
              label: 'Back',
              onClick: handleBack,
              variant: 'secondary',
              index: 1,
              mobileIndex: 2,
              buttonPosition: 'left',
            },
            {
              type: 'button',
              label: 'Continue',
              onClick: handleContinue,
              variant: 'primary',
              index: 2,
              mobileIndex: 1,
              buttonPosition: 'right',
            },
          ]}
        />
      </Box>
    </Box>
  );
};

export default CompanySearch;
