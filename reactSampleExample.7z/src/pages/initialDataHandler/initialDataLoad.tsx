import { userState, switchStatusesState, switchActionsState } from '@/state/atoms';
import { useState, useEffect } from 'react';
import { useSetRecoilState, useRecoilValue } from 'recoil';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';
import { getSwitchActions, getSwitchStatuses } from '@/services/methods/types';
import { getCustomer } from '@/services/methods/customer';
import { useUserData } from './useUserData';
import { useNavigate } from 'react-router-dom';
import { apiContext } from '@/services/apiContext';

export function InitialDataLoad({ children }: { children: React.ReactNode }) {
  const setUserData = useSetRecoilState(userState);
  const currentUserData = useRecoilValue(userState);
  const setSwitchStatuses = useSetRecoilState(switchStatusesState);
  const setSwitchActions = useSetRecoilState(switchActionsState);
  const [hasData, setHasData] = useState(false);
  const [registrationRequired, setRegistrationRequired] = useState(false);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();
  const { userData, isLoading: userDataLoading, error: userDataError } = useUserData();
  const navigate = useNavigate();

  const processUserData = async (data: any) => {
    if (!data?.customerKey) {
      setHasData(false);
      return;
    }
    setUserData(userData);
    try {
      showLoadingSpinner('Loading application data...');
      const customerResponse = await getCustomer(data.customerKey);
      if (customerResponse?.data?.item) {
        const customerData = {
          customerKey: data.customerKey,
          ...customerResponse.data.item,
        };
        apiContext.setCustomerKey(data.customerKey);
        setUserData(customerData);
        const [statusesResponse, actionsResponse]: any = await Promise.all([getSwitchStatuses(), getSwitchActions()]);
        setSwitchStatuses(statusesResponse.data.items);
        setSwitchActions(actionsResponse.data.items);
        setHasData(true);
        navigate('/');
      } else {
        setRegistrationRequired(true);
      }
    } catch (error: any) {
      console.error('Error fetching initial data:', error);
      if (error.response?.status === 404) {
        setRegistrationRequired(true);
      } else {
        setHasData(false);
      }
    } finally {
      hideLoadingSpinner();
    }
  };

  const handleRegistrationSuccess = async (registeredData: any) => {
    try {
      showLoadingSpinner('Loading application data...');
      setUserData(registeredData);

      const [statusesResponse, actionsResponse]: any = await Promise.all([getSwitchStatuses(), getSwitchActions()]);

      setSwitchStatuses(statusesResponse.data.items);
      setSwitchActions(actionsResponse.data.items);

      setRegistrationRequired(false);
      setHasData(true);
      navigate('/');
    } catch (error) {
      console.error('Error loading data after registration:', error);
      setHasData(false);
    } finally {
      hideLoadingSpinner();
    }
  };

  useEffect(() => {
    if (userData) {
      processUserData(userData);
    }
  }, [userData]);

  if (userDataLoading) {
    return <div>Loading user data...</div>;
  }

  if (userDataError) {
    return <div>Error: {userDataError}</div>;
  }

  if (registrationRequired) {
    return (
      <RegistrationPage
        initialData={currentUserData}
        onRegistrationSuccess={handleRegistrationSuccess}
      />
    );
  }

  if (!hasData) {
    return <div>No user data found. Unable to load the application.</div>;
  }

  return <>{children}</>;
}
