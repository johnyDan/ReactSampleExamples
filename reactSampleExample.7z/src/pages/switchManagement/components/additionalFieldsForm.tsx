import React, { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import { Box } from '@mui/material';
import FormField from '@/validations/core/formField';
import { FormConfig, FieldConfig } from '../utils/convertApiResponseToFormConfig';

interface AdditionalFieldsFormProps {
  formConfig: FormConfig;
}

type ProcessedField =
  | {
      type: 'field';
      fieldName: string;
      fieldConfig: FieldConfig;
    }
  | {
      type: 'radioGroup';
      fieldName: string;
      options: { label: string; value: string }[];
      variationType: 'variation1' | 'variation2';
      fields: { [key: string]: FieldConfig };
    };

const AdditionalFieldsForm: React.FC<AdditionalFieldsFormProps> = ({ formConfig }) => {
  const methods = useFormContext();
  const { watch, setValue, register, getValues } = methods;

  const fieldPrefix = 'fields.';
  const processedFields: ProcessedField[] = [];
  const processedFieldNames = new Set<string>();
  const fieldKeys = Object.keys(formConfig.fields);
  let i = 0;

  while (i < fieldKeys.length) {
    const key1 = fieldKeys[i];
    const field1 = formConfig.fields[key1];

    if (processedFieldNames.has(key1)) {
      i += 1;
      continue;
    }

    // Look ahead to the next field
    if (i + 1 < fieldKeys.length) {
      const key2 = fieldKeys[i + 1];
      const field2 = formConfig.fields[key2];

      // Check for Variation 1 (Both fields are text inputs)
      const isVariation1 =
        (field2.label.startsWith('OR ') || field2.label.startsWith('or ') || key2.includes('_or')) &&
        field1.inputType === 'text' &&
        field2.inputType === 'text';

      // Check for Variation 2 (Both fields are checkboxes)
      const isVariation2 =
        (field2.label.startsWith('Or ') || key2.includes('_Is')) &&
        field1.inputType === 'checkbox' &&
        field2.inputType === 'checkbox';

      if (isVariation1 || isVariation2) {
        // Create a radio group with field1 and field2
        const radioGroupField: ProcessedField = {
          type: 'radioGroup',
          fieldName: `radioOption_${i}`, // Unique field name for the radio group
          options: [
            { label: field1.label.replace(/^(OR |or |Or )/i, ''), value: key1 },
            { label: field2.label.replace(/^(OR |or |Or )/i, ''), value: key2 },
          ],
          variationType: isVariation1 ? 'variation1' : 'variation2',
          fields: {
            [key1]: field1,
            [key2]: field2,
          },
        };

        processedFields.push(radioGroupField);
        processedFieldNames.add(key1);
        processedFieldNames.add(key2);

        i += 2; // Skip the next field since we've processed it
        continue;
      }
    }

    // Process the field as usual
    processedFields.push({
      type: 'field',
      fieldName: key1,
      fieldConfig: field1,
    });
    processedFieldNames.add(key1);

    i += 1;
  }

  // useEffect to handle setting default values for radio options
  useEffect(() => {
    processedFields.forEach((fieldItem) => {
      if (fieldItem.type === 'radioGroup') {
        const fieldName = `${fieldPrefix}${fieldItem.fieldName}`;
        const currentValue = getValues(fieldName);
        if (!currentValue) {
          // Determine which option is selected based on the existing form data
          if (fieldItem.variationType === 'variation1') {
            // For variation1, check which of the fields has a value
            for (const option of fieldItem.options) {
              const optionFieldName = `${fieldPrefix}${option.value}`;
              const optionValue = getValues(optionFieldName);
              if (optionValue !== undefined && optionValue !== null && optionValue !== '') {
                setValue(fieldName, option.value);
                break;
              }
            }
          } else if (fieldItem.variationType === 'variation2') {
            // For variation2, check which of the fields is true
            for (const option of fieldItem.options) {
              const optionFieldName = `${fieldPrefix}${option.value}`;
              const optionValue = getValues(optionFieldName);
              if (optionValue) {
                setValue(fieldName, option.value);
                break;
              }
            }
          }
        }
      }
    });
  }, [processedFields, getValues, setValue]);

  // useEffect to handle resetting values when radio option changes
  useEffect(() => {
    processedFields.forEach((fieldItem) => {
      if (fieldItem.type === 'radioGroup') {
        const fieldName = `${fieldPrefix}${fieldItem.fieldName}`;
        const selectedOption = watch(fieldName);

        if (selectedOption) {
          Object.keys(fieldItem.fields).forEach((key) => {
            const fieldKey = `${fieldPrefix}${key}`;

            if (fieldItem.variationType === 'variation2') {
              // For variation2, set the value to true if key matches selectedOption, else false
              setValue(fieldKey, key === selectedOption);
            } else if (fieldItem.variationType === 'variation1') {
              // For variation1, reset unselected options to an empty string
              if (key !== selectedOption) {
                setValue(fieldKey, '');
              }
            }
          });
        }
      }
    });
  }, [processedFields, watch, setValue]);

  return (
    <Box>
      {processedFields.map((fieldItem) => {
        if (fieldItem.type === 'radioGroup') {
          const selectedOption = watch(`${fieldPrefix}${fieldItem.fieldName}`);

          return (
            <React.Fragment key={fieldItem.fieldName}>
              {/* Render the radio group */}
              <FormField
                fieldName={`${fieldPrefix}${fieldItem.fieldName}`}
                fieldConfig={{
                  inputType: 'radio',
                  label: 'Please select an option',
                  options: fieldItem.options,
                  validations: { required: 'This field is required' },
                }}
              />

              {fieldItem.variationType === 'variation1' &&
                fieldItem.options.map((option) => {
                  if (selectedOption === option.value) {
                    const fieldConfig = fieldItem.fields[option.value];
                    return (
                      <Box
                        key={option.value}
                        sx={{ mb: 2, mt: 2 }}>
                        <FormField
                          key={option.value}
                          fieldName={`${fieldPrefix}${option.value}`}
                          fieldConfig={fieldConfig}
                        />
                      </Box>
                    );
                  }
                  return null;
                })}

              {fieldItem.variationType === 'variation2' && (
                // Register the fields to ensure they're included in the form data
                <>
                  {Object.keys(fieldItem.fields).map((key) => (
                    <input
                      key={key}
                      type="hidden"
                      {...register(`${fieldPrefix}${key}`)}
                    />
                  ))}
                </>
              )}
            </React.Fragment>
          );
        } else if (fieldItem.type === 'field') {
          // Render individual fields with prefixed field names
          return (
            <Box
              key={fieldItem.fieldName}
              sx={{ mb: 2, mt: 2 }}>
              <FormField
                key={fieldItem.fieldName}
                fieldName={`${fieldPrefix}${fieldItem.fieldName}`}
                fieldConfig={fieldItem.fieldConfig}
              />
            </Box>
          );
        }
        return null;
      })}
    </Box>
  );
};

export default AdditionalFieldsForm;
