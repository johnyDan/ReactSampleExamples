import React from 'react';
import { useFormContext, useFieldArray } from 'react-hook-form';
import { Box, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import CustomButton from '@/validations/material/customButton';
import FormField from '@/validations/core/formField';
import { FormConfig } from '../utils/convertApiResponseToFormConfig';

interface AccountsFormProps {
  formConfig: FormConfig;
  uxAccounts: any;
}

const AccountsForm: React.FC<AccountsFormProps> = ({ formConfig, uxAccounts }) => {
  const methods = useFormContext();
  const { control, watch } = methods;

  const accounts = formConfig.fields.accounts;
  if (!accounts) {
    return null;
  }

  const accountsFields = useFieldArray({
    control,
    name: 'accounts',
  });

  const accountValues = watch('accounts') || [];

  const handleAddAccount = () => {
    accountsFields.append({ index: '', fields: {} });
  };

  const handleRemoveAccount = (index: number) => {
    accountsFields.remove(index);
  };

  const canAddAccount = uxAccounts.limit > 1 && uxAccounts.choices.length > 1;

  return (
    <>
      {accountsFields.fields.map((item, index) => {
        const selectedIndices = accountValues.filter((_, idx) => idx !== index).map((account: any) => account.index);

        const availableChoices = accounts.fields!.index.options.filter(
          (option) => !selectedIndices.includes(option.value)
        );

        return (
          <Box
            key={item.id}
            sx={{ mb: 2, p: 2, border: '1px solid #ccc', borderRadius: '8px' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Box sx={{ flexGrow: 1 }}>
                {/* Account Dropdown with filtered options */}
                <FormField
                  fieldName={`accounts.${index}.index`}
                  fieldConfig={{
                    ...accounts.fields!.index,
                    options: availableChoices,
                  }}
                />
              </Box>
              {/* Show delete button only if more than one account */}
              {accountsFields.fields.length > 1 && index !== 0 && (
                <IconButton onClick={() => handleRemoveAccount(index)}>
                  <DeleteIcon />
                </IconButton>
              )}
            </Box>

            {/* Render additional account fields with conditional logic */}
            {Object.entries(accounts.fields!).map(([subKey, subFieldConfig]) => {
              if (subKey !== 'index') {
                // Conditional Rendering Logic
                if (subKey === 'splitAmount') {
                  const splitTypeValue = watch(`accounts.${index}.fields.splitType`);
                  if (splitTypeValue === 'remainder') {
                    // Do not render 'splitAmount' when 'splitType' is 'remainder'
                    return null;
                  }
                }

                return (
                  <Box
                    key={subKey}
                    sx={{ mt: 2 }}>
                    <FormField
                      fieldName={`accounts.${index}.fields.${subKey}`}
                      fieldConfig={subFieldConfig}
                    />
                  </Box>
                );
              }
              return null;
            })}
          </Box>
        );
      })}

      {canAddAccount &&
        accountsFields.fields.length < uxAccounts.choices.length &&
        accountsFields.fields.length < uxAccounts.limit && (
          <Box>
            <CustomButton
              variant="secondary"
              onClick={handleAddAccount}>
              Add Account
            </CustomButton>
          </Box>
        )}
    </>
  );
};

export default AccountsForm;
