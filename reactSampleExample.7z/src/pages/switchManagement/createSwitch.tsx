import React, { useEffect, useState } from 'react';
import { useRecoilState, useRecoilValue } from 'recoil';
import { useNavigate } from 'react-router-dom';
import { Typography, Box } from '@mui/material';
import { selectedCompanyState, switchCreationState, currentStepState } from '../../state/atoms';
import { useForm, FormProvider } from 'react-hook-form';
import AccountsForm from './components/accountsForm';
import AdditionalFieldsForm from './components/additionalFieldsForm';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';
import NavigationButtons from '@/components/layout/navigationButtons';
import { FormConfig } from './utils/convertApiResponseToFormConfig';
import { fetchSwitchDataForCreateMode, fetchSwitchDataForEditMode, getHtmlField } from './utils/switchUtils';
import { performSwitchAction, updateSwitch } from '@/services/methods/switch';
import SwitchLayout from './components/switchLayout';
import HtmlContentDisplay from './utils/htmlContentDisplay';
import { filterFormData } from './utils/formUtils';

const CreateSwitch: React.FC = () => {
  const selectedCompany = useRecoilValue(selectedCompanyState);
  const [switchCreation, setSwitchCreation] = useRecoilState(switchCreationState);
  const [currentStep, setCurrentStep] = useRecoilState(currentStepState);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();

  const navigate = useNavigate();

  const [formConfig, setFormConfig] = useState<FormConfig | null>(null);

  const methods = useForm({
    defaultValues: {},
  });

  useEffect(() => {
    const fetchSwitchData = async () => {
      if (switchCreation.switchId) {
        // Edit Mode
        await fetchSwitchDataForEditMode(
          switchCreation,
          setSwitchCreation,
          methods,
          setFormConfig,
          showLoadingSpinner,
          hideLoadingSpinner
        );
      } else if (
        selectedCompany &&
        (selectedCompany.targetId || selectedCompany.locationId || selectedCompany.manualSetup)
      ) {
        // Create Mode
        await fetchSwitchDataForCreateMode(
          selectedCompany,
          setSwitchCreation,
          methods,
          setFormConfig,
          showLoadingSpinner,
          hideLoadingSpinner
        );
      }
    };

    fetchSwitchData();
  }, [switchCreation.switchId, selectedCompany, setSwitchCreation]);

  const handleBack = () => {
    if (currentStep === 1) {
      navigate('/company-search');
    } else if (currentStep === 2) {
      setCurrentStep(1);
    }
  };

  const handleContinue = methods.handleSubmit((data) => {
    const filteredFormData = filterFormData(data, formConfig!);

    console.log('form data ', filteredFormData);

    setSwitchCreation((prev) => ({
      ...prev,
      switchId: prev.switchData?.index || prev.switchId,
      switchData: {
        ...prev.switchData,
        values: filteredFormData,
      },
    }));

    if (currentStep === 1) {
      setCurrentStep(2);
    } else if (currentStep === 2) {
      navigate('/switch-management/verify');
    }
  });

  const handleSaveAndContinueLater = methods.handleSubmit(async (data) => {
    if (switchCreation.switchData) {
      const updateData = {
        type: switchCreation.switchData.type,
        accountHolderIndex: switchCreation.switchData.accountHolderIndex,
        targetId: switchCreation.switchData.targetId,
        values: data,
      };
      try {
        showLoadingSpinner('Updating Switch');
        const response = await updateSwitch(switchCreation.switchData.index, updateData, {
          context: 'testing',
        });
        hideLoadingSpinner();
        setSwitchCreation((prev) => ({
          ...prev,
          switchData: response.data.item,
        }));
        navigate('/');
      } catch (error) {
        hideLoadingSpinner(true);
        console.error('Error saving switch:', error);
      }
    }
  });

  const handleClose = (newSearch?: boolean) => {
    // Reset the Recoil states
    setSwitchCreation({
      switchId: null,
      switchData: null,
      step: 'create',
      isEditing: false,
      workflowEmbedUrl: null,
      error: null,
      switchKind: null,
    });
    setCurrentStep(1);
    navigate(newSearch ? '/company-search' : '/');
  };

  const handleMarkAsComplete = async () => {
    showLoadingSpinner('Submitting Switch');
    await performSwitchAction(
      switchCreation.switchData.index,
      { index: switchCreation.switchData.index, action: 'Complete' },
      { context: 'testing' },
      switchCreation.switchData
    );
    hideLoadingSpinner(true);
    handleClose();
  };

  if (switchCreation.error) {
    return <Typography color="error">{switchCreation.error}</Typography>;
  }

  const isEditMode = !!switchCreation.switchId;

  // Check for HTML content
  const htmlField = getHtmlField(switchCreation.switchData);

  // Handle the different cases

  // Case 1: workflowEmbedUrl is present
  if (switchCreation.workflowEmbedUrl) {
    const switchLayoutInfo = {
      staticInfo: {
        title: 'Setup your direct deposit',
        subtitle: 'Complete your switch',
        description: 'To complete your switch instantly, please provide your information for ' + selectedCompany.name,
        stepInfo: 'Step 2 of 2',
      },
      rightContent: (
        <iframe
          src={switchCreation.workflowEmbedUrl}
          width="100%"
          height="600px"
          style={{ border: 'none' }}
          title="ClickSwitch Workflow"
        />
      ),
      navigationButtons: (
        <NavigationButtons
          items={[
            {
              type: 'button',
              label: 'Close',
              onClick: handleClose,
              variant: 'secondary',
              index: 1,
              mobileIndex: 2,
              icon: <></>,
              buttonPosition: 'right',
            },
            {
              type: 'link',
              label: 'Add Another Deposit',
              onClick: () => handleClose(true),
              index: 2,
              mobileIndex: 1,
              buttonPosition: 'right',
            },
          ]}
        />
      ),
    };

    return <SwitchLayout {...switchLayoutInfo} />;
  }

  // Case 2: HTML content is present
  if (htmlField) {
    const switchLayoutInfo = {
      staticInfo: {
        title: 'Setup your direct deposit',
        subtitle: 'Complete your switch',
        description: 'To complete your switch, please follow the instructions provided for ' + selectedCompany.name,
        stepInfo: '',
      },
      rightContent: (
        <>
          <HtmlContentDisplay htmlString={htmlField.body} />
          <Typography
            variant="body2"
            color="text.secondary">
            When you have followed the above steps and this requested switch posts to your account, click the 'Mark as
            Complete' button below.
          </Typography>
        </>
      ),
      navigationButtons: (
        <NavigationButtons
          items={[
            {
              type: 'button',
              label: 'Mark as Complete',
              onClick: handleMarkAsComplete,
              variant: 'primary',
              index: 1,
              mobileIndex: 1,
              icon: <></>,
              buttonPosition: 'right',
            },
            {
              type: 'link',
              label: 'Add Another Deposit',
              onClick: () => handleClose(true),
              index: 2,
              mobileIndex: 2,
              buttonPosition: 'right',
            },
          ]}
        />
      ),
    };

    return <SwitchLayout {...switchLayoutInfo} />;
  }

  // Loading checks
  if (!switchCreation.switchData) {
    return <Typography>Loading...</Typography>;
  }

  if (
    !isEditMode &&
    (!selectedCompany || (!selectedCompany.targetId && !selectedCompany.locationId && !selectedCompany.manualSetup))
  ) {
    return <Typography>Loading...</Typography>;
  }

  if (!formConfig) {
    return <Typography>Loading...</Typography>;
  }

  // Case 3: actual form rendering
  const uxAccounts = switchCreation.switchData.ux.accounts;
  const companyName = selectedCompany.manualSetup ? '' : 'for ' + selectedCompany.name;
  const switchLayoutInfo = {
    staticInfo: {
      title: 'Setup your direct deposit',
      subtitle:
        currentStep === 1 ? `Select your Account ${companyName}` : `Personal Info for your switch ${companyName}`,
      description:
        currentStep === 1
          ? 'Where would you like your deposit to go?'
          : 'You might want to have an old paystub handy to help you answer.',
      stepInfo: `Step ${currentStep + 1} of 3`,
    },
    rightContent: (
      <FormProvider {...methods}>
        <>
          {currentStep === 1 && (
            <AccountsForm
              formConfig={formConfig}
              uxAccounts={uxAccounts}
            />
          )}
          {currentStep === 2 && <AdditionalFieldsForm formConfig={formConfig} />}
        </>
      </FormProvider>
    ),
    navigationButtons: (
      <NavigationButtons
        items={[
          {
            type: 'button',
            label: 'Back',
            onClick: handleBack,
            variant: 'secondary',
            index: 1,
            mobileIndex: 2,
            buttonPosition: 'left',
          },
          {
            type: 'link',
            label: 'Save & Continue Later',
            onClick: handleSaveAndContinueLater,
            index: 2,
            mobileIndex: 3,
            buttonPosition: 'right',
          },
          {
            type: 'button',
            label: 'Continue',
            onClick: handleContinue,
            variant: 'primary',
            index: 3,
            mobileIndex: 1,
            buttonPosition: 'right',
          },
        ]}
      />
    ),
  };

  return <SwitchLayout {...switchLayoutInfo} />;
};

export default CreateSwitch;
