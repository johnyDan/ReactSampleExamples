import { FormConfig } from '../utils/convertApiResponseToFormConfig';

export const filterFormData = (data: any, formConfig: FormConfig): FormData => {
  if (!formConfig.fields || !data.fields) {
    return data;
  }

  const validFieldNames = Object.keys(formConfig.fields);
  const filteredFields = Object.fromEntries(
    Object.entries(data.fields).filter(([key]) => validFieldNames.includes(key))
  );

  return {
    ...data,
    fields: filteredFields,
  };
};
