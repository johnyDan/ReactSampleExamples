import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSetRecoilState } from 'recoil';
import {
  Box,
  Typography,
  IconButton,
  List,
  ListItem,
  Divider,
  useTheme,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
} from '@mui/material';
import { getAllSwitches, getSwitchDetails, performSwitchAction } from '../../services/methods/switch';
import { hasExistingSwitchesState, switchCreationState } from '../../state/atoms';
import CustomButton from '@/validations/material/customButton';
import { useLoadingSpinner } from '@/utils/useLoadingSpinner';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import ArrowCircleRightOutlinedIcon from '@mui/icons-material/ArrowCircleRightOutlined';

interface Switch {
  index: number;
  name: string;
  values: any;
  ux: any;
  state: any;
  workflowEmbedUrl: string;
}

const SwitchDashboard: React.FC = () => {
  const [switches, setSwitches] = useState<Switch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogAction, setDialogAction] = useState<'delete' | 'submit' | null>(null);
  const [selectedSwitch, setSelectedSwitch] = useState<Switch | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const navigate = useNavigate();
  const theme = useTheme();
  const setSwitchCreation = useSetRecoilState(switchCreationState);
  const { showLoadingSpinner, hideLoadingSpinner } = useLoadingSpinner();
  const setHasExistingSwitches = useSetRecoilState(hasExistingSwitchesState);

  const getSplitTypeDisplay = (splitType: string, splitAmount: string) => {
    const BoldAmount = () => (
      <Box
        component="span"
        fontWeight="bold">
        {splitAmount}
      </Box>
    );

    switch (splitType) {
      case 'currency':
        return (
          <>
            $<BoldAmount /> of each check
          </>
        );
      case 'percentage':
        return (
          <>
            <BoldAmount />% of each check
          </>
        );
      case 'remainder':
        return 'Remainder of each check';
      default:
        return <BoldAmount />;
    }
  };

  const getAccountLabel = (accountIndex: string, switchData: any) => {
    const account = switchData.ux.accounts.choices.find(
      (choice: any) => choice.index.toString() === accountIndex.toString()
    );
    return account ? account.label : 'Unknown Account';
  };

  useEffect(() => {
    fetchSwitches();
  }, []);

  const fetchSwitches = async () => {
    try {
      showLoadingSpinner('Fetching existing direct deposits');
      const response = await getAllSwitches({ context: 'testing' });
      const switchItems = response.data.items;
      setHasExistingSwitches(switchItems.length > 0);

      if (switchItems.length === 0) {
        hideLoadingSpinner(true);
        navigate('/company-search');
        return;
      }

      // Fetch details for each switch
      const switchDetailsPromises = switchItems.map(async (switchItem: Switch) => {
        const switchIndex = switchItem.index;
        try {
          const switchDetailsResponse = await getSwitchDetails(switchIndex, {
            context: 'testing',
            contentType: 'application/json',
          });
          // The detailed switch data is assumed to be in switchDetailsResponse.data.item
          return switchDetailsResponse.data.item;
        } catch (err) {
          console.error(`Failed to fetch details for switch index ${switchIndex}`, err);
          return null; // or you can decide to handle this differently
        }
      });

      // Wait for all promises to resolve
      const detailedSwitches = await Promise.all(switchDetailsPromises);

      // Filter out any null responses due to errors
      const validSwitches = detailedSwitches.filter((switchItem) => switchItem !== null);

      hideLoadingSpinner();
      setSwitches(validSwitches as Switch[]);
      setLoading(false);
    } catch (err) {
      hideLoadingSpinner(true);
      setError('Failed to fetch switches. Please try again.');
      setLoading(false);
    }
  };

  const handleEdit = (switchIndex: number) => {
    setSwitchCreation((prev) => ({ ...prev, switchId: switchIndex }));
    navigate('/switch-management/create');
  };

  const handleDelete = (switchItem: Switch) => {
    setSelectedSwitch(switchItem);
    setDialogAction('delete');
    setOpenDialog(true);
  };

  const handleSubmit = (switchItem: Switch) => {
    setSelectedSwitch(switchItem);
    setDialogAction('submit');
    setOpenDialog(true);
  };

  const handleConfirmAction = async () => {
    if (!selectedSwitch) return;

    try {
      if (dialogAction === 'delete') {
        showLoadingSpinner('Deleting selected switch');
        await performSwitchAction(
          selectedSwitch.index,
          { index: selectedSwitch.index, action: 'Cancel' },
          { context: 'testing' }
        );
        hideLoadingSpinner();
      } else if (dialogAction === 'submit') {
        showLoadingSpinner('Submiting selected switch');
        await performSwitchAction(
          selectedSwitch.index,
          { index: selectedSwitch.index, action: 'Submit' },
          { context: 'testing' }
        );
        hideLoadingSpinner();
      }
      fetchSwitches();
      setOpenDialog(false);
    } catch (err) {
      hideLoadingSpinner(true);
      setError(`Failed to ${dialogAction} switch. Please try again.`);
    }
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedSwitch(null);
    setDialogAction(null);
  };

  const handlePdfView = async (switchIndex: number) => {
    try {
      const response = await getSwitchDetails(switchIndex, {
        context: 'testing',
        contentType: 'application/pdf',
      });
      const pdfBlob = new Blob([response.data], { type: 'application/pdf' });
      const pdfUrl = URL.createObjectURL(pdfBlob);
      setPdfUrl(pdfUrl);
      window.open(pdfUrl, '_blank');
    } catch (err) {
      setError('Failed to fetch PDF. Please try again.');
    }
  };

  if (loading) return <Typography></Typography>;
  if (error) return <Typography color="error">{error}</Typography>;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%', boxSizing: 'border-box' }}>
      <Grid
        container
        spacing={4}
        sx={{ flexGrow: 1, p: { xs: 2, sm: 4 }, justifyContent: 'center' }}>
        {switches && switches.length > 0 && (
          <Grid
            item
            xs={12}
            md={6}
            sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <Box sx={{ p: 1, gap: 2, display: 'flex', flexDirection: 'column' }}>
              <Typography variant="h2">Your direct deposits</Typography>
              <Typography
                variant="body2"
                gutterBottom>
                The following direct deposits were completed in the past 2 weeks or are currently in progress.
              </Typography>
              <Typography
                variant="body2"
                gutterBottom>
                To see direct deposits configured before that time, login to your employer's payroll system.
              </Typography>
            </Box>
            <List
              sx={{
                height: '50vh',
                overflowY: 'auto',
                '&::-webkit-scrollbar': {
                  width: '8px',
                },
                '&::-webkit-scrollbar-track': {
                  background: theme.palette.grey[300],
                  borderRadius: '4px',
                },
                '&::-webkit-scrollbar-thumb': {
                  backgroundColor: theme.palette.primary.main,
                  borderRadius: '4px',
                  border: '2px solid transparent',
                  backgroundClip: 'padding-box',
                  transition: 'background-color 0.3s ease',
                },
                '&::-webkit-scrollbar-thumb:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },

                scrollbarWidth: 'thin',
                scrollBehavior: 'smooth',
                scrollbarColor: `${theme.palette.primary.main} ${theme.palette.grey[300]}`,
              }}>
              {switches.map((switchItem: Switch, index) => (
                <React.Fragment key={index}>
                  <Divider sx={{ ml: 2, mr: 2 }} />
                  <ListItem
                    key={index}
                    sx={{
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      padding: 2,
                    }}>
                    <Grid
                      container
                      display="flex"
                      justifyContent="space-between"
                      width="100%"
                      mb={1}>
                      <Grid
                        item
                        xs={8}>
                        <Typography
                          variant="body2"
                          component="h2"
                          fontWeight={'bold'}
                          color="primary">
                          {switchItem.name}
                        </Typography>
                      </Grid>

                      <Grid
                        item
                        xs={4}
                        display="flex"
                        justifyContent="flex-end"
                        alignItems="flex-start">
                        <IconButton
                          size="small"
                          onClick={() => handleEdit(switchItem.index)}>
                          <EditOutlinedIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(switchItem)}>
                          <DeleteOutlineOutlinedIcon />
                        </IconButton>
                        {/* {switchItem.status === "Ready to Submit" && (
                          <IconButton size="small" onClick={() => handleSubmit(switchItem)}>
                            <ArrowCircleRightOutlinedIcon />
                          </IconButton>
                        )} */}
                        <IconButton
                          size="small"
                          onClick={() => handlePdfView(switchItem.index)}>
                          <VisibilityOutlinedIcon />
                        </IconButton>
                      </Grid>
                    </Grid>

                    {switchItem.values &&
                      switchItem.values.accounts &&
                      switchItem.values.accounts.length > 0 &&
                      switchItem.values.accounts.map((account: any, index: number) => (
                        <Box
                          key={index + 'test'}
                          mb={2}>
                          <Typography
                            variant="body2"
                            gutterBottom>
                            {getSplitTypeDisplay(account.fields?.splitType, account.fields?.splitAmount)}
                          </Typography>
                          <Typography
                            variant="body2"
                            gutterBottom>
                            Deposited into: {getAccountLabel(account.index, switchItem)}
                          </Typography>
                        </Box>
                      ))}

                    <Typography
                      variant="body2"
                      fontWeight={'bold'}
                      color="primary">
                      Status
                    </Typography>
                    <Typography variant="body2">{switchItem.state.status}</Typography>
                    {/* {switchItem.submittedDate && (
                      <Typography variant="body1" color="text.secondary">
                        Submitted Date: {switchItem.submittedDate}
                      </Typography>
                    )}
                    {switchItem.status === "Completed" && (
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 1, fontStyle: "italic" }}>
                        This may take a few pay cycles to reflect on your account.
                      </Typography>
                    )} */}
                  </ListItem>
                  {index == switches.length - 1 && <Divider sx={{ ml: 2, mr: 2 }} />}
                </React.Fragment>
              ))}
            </List>
            <Box p={2}>
              <CustomButton
                variant="primary"
                onClick={() => navigate('/company-search')}>
                Add another direct deposit
              </CustomButton>
            </Box>
            <Dialog
              open={openDialog}
              onClose={handleCloseDialog}>
              <DialogTitle>{dialogAction === 'delete' ? 'Confirm Deletion' : 'Confirm Submission'}</DialogTitle>
              <DialogContent>
                <Typography
                  variant="body2"
                  color="text.secondary">
                  {dialogAction === 'delete'
                    ? 'Are you sure you want to delete this switch?'
                    : 'Are you sure you want to submit this switch?'}
                </Typography>
              </DialogContent>
              <DialogActions sx={{ p: 3, justifyContent: 'space-between' }}>
                <CustomButton
                  variant="secondary"
                  onClick={handleCloseDialog}>
                  Cancel
                </CustomButton>
                <CustomButton
                  variant="primary"
                  onClick={handleConfirmAction}
                  autoFocus>
                  Confirm
                </CustomButton>
              </DialogActions>
            </Dialog>
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

export default SwitchDashboard;
