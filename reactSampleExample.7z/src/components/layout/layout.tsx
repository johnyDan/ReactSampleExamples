import React from 'react';
import { Box, Paper, Grid } from '@mui/material';
import Header from './header';

interface LayoutProps {
  children?: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: { xs: 'flex-start', md: 'center' },
        bgcolor: 'primary.main',
        minHeight: '100vh',
        width: '100vw',
        p: { xs: 2, md: 0 },
      }}>
      <Paper
        elevation={3}
        sx={{
          width: { xs: '95%', md: '95%', lg: '95%' },
          minHeight: { xs: '100vh', md: '100vh' },
          bgcolor: 'white',
          borderRadius: 2,
          boxShadow: 3,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
        <Grid
          container
          direction="column"
          sx={{
            flexGrow: 1,
            overflowY: 'auto',
          }}>
          <Header />
          <Box sx={{ p: 2 }}>{children}</Box>
        </Grid>
      </Paper>
    </Box>
  );
};

export default Layout;
