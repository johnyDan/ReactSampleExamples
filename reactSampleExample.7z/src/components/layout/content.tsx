import React from 'react';
import { Grid, Typography, Box } from '@mui/material';
import { Outlet } from 'react-router-dom';
import InfoBox from '../common/infoBox';

const Content: React.FC = () => {
  const bodyTextArray = [
    'Connecting your direct deposit only allows access to update your direct deposit to your Bank account.',
    'It does not allow access to income, paystubs, timesheets, name, address and contact information.',
  ];

  return (
    <Grid
      container
      spacing={2}
      sx={{ flexGrow: 1, p: { xs: 2, sm: 4 } }}>
      <Grid
        item
        xs={12}
        md={6}
        sx={{ display: 'flex', flexDirection: 'column' }}>
        <Typography variant="h2">Setup your direct deposit</Typography>
        <Typography
          variant="h4"
          color="custom.paragraphText">
          You can easily setup direct deposit and skip the HR paperwork.
        </Typography>
        <Box sx={{ mt: 2, flexGrow: 1, overflow: 'auto' }}>
          <InfoBox
            title="Learn how you're protected"
            bodyText={bodyTextArray}
          />
        </Box>
      </Grid>
      <Grid
        item
        xs={12}
        md={6}
        sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <Outlet />
      </Grid>
    </Grid>
  );
};

export default Content;
