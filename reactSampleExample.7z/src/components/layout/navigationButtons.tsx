// NavigationButtons.tsx
import React from 'react';
import { Box, Link as MuiLink, useMediaQuery, useTheme } from '@mui/material';
import CustomButton from '@/validations/material/customButton';
import WestIcon from '@mui/icons-material/West';
import EastIcon from '@mui/icons-material/East';

interface NavigationItem {
  type: 'button' | 'link';
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
  index: number; // Order on desktop
  mobileIndex?: number; // Order on mobile
  icon?: React.ReactNode | null;
  iconPosition?: 'left' | 'right';
  buttonPosition?: 'left' | 'right'; // Only considered on desktop
}

interface NavigationButtonsProps {
  items: NavigationItem[];
}

const NavigationButtons: React.FC<NavigationButtonsProps> = ({ items }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const sortItems = (items: NavigationItem[]) => {
    return items.sort((a, b) => {
      const indexA = isMobile ? (a.mobileIndex !== undefined ? a.mobileIndex : a.index) : a.index;
      const indexB = isMobile ? (b.mobileIndex !== undefined ? b.mobileIndex : b.index) : b.index;
      return indexA - indexB;
    });
  };

  const renderItem = (item: NavigationItem) => {
    const defaultIcon =
      item.buttonPosition === 'left' ? <WestIcon /> : item.buttonPosition === 'right' ? <EastIcon /> : <EastIcon />;

    // Use default icon if icon is not specified and the item is a button
    const icon =
      item.type === 'button'
        ? item.icon !== undefined
          ? item.icon // Use specified icon (can be null, ToDo : refine this)
          : defaultIcon // Use default icon if icon is undefined
        : undefined;

    const iconPosition = item.iconPosition ?? (item.buttonPosition === 'left' ? 'left' : 'right');

    if (item.type === 'button') {
      return (
        <CustomButton
          key={item.label}
          variant={item.variant || 'primary'}
          onClick={item.onClick}
          icon={icon}
          iconPosition={iconPosition}
          sx={{
            width: { xs: '100%', md: 'auto' },
          }}>
          {item.label}
        </CustomButton>
      );
    } else if (item.type === 'link') {
      return (
        <MuiLink
          key={item.label}
          component="button"
          variant="body2"
          onClick={item.onClick}
          sx={{
            mt: { xs: 2, md: 0 },
            textAlign: { xs: 'center', md: 'left' },
          }}>
          {item.label}
        </MuiLink>
      );
    }
    return null;
  };

  if (isMobile) {
    // On mobile, ignore buttonPosition and render all items in order
    const sortedItems = sortItems(items);
    return (
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'stretch',
          gap: 2,
          mt: 'auto',
          p: 2,
        }}>
        {sortedItems.map((item) => renderItem(item))}
      </Box>
    );
  } else {
    // On desktop, separate items into left and right sections
    const leftItems = sortItems(items.filter((item) => item.buttonPosition === 'left'));
    const rightItems = sortItems(items.filter((item) => item.buttonPosition === 'right'));

    let justifyContentValue: string;
    if (leftItems.length > 0 && rightItems.length > 0) {
      justifyContentValue = 'space-between';
    } else if (leftItems.length > 0 && rightItems.length === 0) {
      justifyContentValue = 'flex-start';
    } else if (leftItems.length === 0 && rightItems.length > 0) {
      justifyContentValue = 'flex-end';
    } else {
      justifyContentValue = 'center';
    }

    return (
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: justifyContentValue,
          alignItems: 'center',
          gap: 2,
          mt: 'auto',
          p: 2,
        }}>
        {/* Left Section */}
        {leftItems.length > 0 && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              gap: 2,
            }}>
            {leftItems.map((item) => renderItem(item))}
          </Box>
        )}

        {/* Right Section */}
        {rightItems.length > 0 && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              gap: 2,
            }}>
            {rightItems.map((item) => renderItem(item))}
          </Box>
        )}
      </Box>
    );
  }
};

export default NavigationButtons;
